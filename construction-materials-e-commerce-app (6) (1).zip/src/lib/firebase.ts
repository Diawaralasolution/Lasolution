import { initializeApp, getApps, deleteApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, deleteDoc, onSnapshot, writeBatch, enableNetwork, disableNetwork } from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile } from 'firebase/auth';
import type { User as FirebaseUser } from 'firebase/auth';
import { useStore } from '../store/useStore';

// ============================================================
// CONFIG
// ============================================================
const HARDCODED_CONFIG = {
  apiKey: "AIzaSyCnp4WgkMQX199YnInusgixjGgBcuLoNbU",
  authDomain: "llucent-puppy-43f034.firebaseapp.com",
  projectId: "llucent-puppy-43f034",
  storageBucket: "llucent-puppy-43f034.firebasestorage.app",
  messagingSenderId: "982760311113",
  appId: "1:982760311113:web:81cd907d828394d2d1b298",
};

function getConfig() {
  if (HARDCODED_CONFIG.apiKey && HARDCODED_CONFIG.projectId) return { ...HARDCODED_CONFIG };
  try {
    const s = useStore.getState().firebaseConfig;
    if (s?.apiKey && s?.projectId) return { apiKey: s.apiKey, authDomain: s.authDomain, projectId: s.projectId, storageBucket: s.storageBucket, messagingSenderId: s.messagingSenderId, appId: s.appId };
  } catch {}
  return null;
}

let _db: any = null;
let _auth: any = null;
let _initialized = false;

function ensureInit() {
  if (_initialized) return;
  const config = getConfig();
  if (!config) return;
  try {
    const existing = getApps();
    if (existing.length > 0) existing.forEach(a => { try { deleteApp(a); } catch {} });
    const app = initializeApp(config);
    _db = getFirestore(app);
    _auth = getAuth(app);
    _initialized = true;
    console.log('✅ Firebase initialisé');
  } catch (e) {
    console.warn('Firebase init error:', e);
  }
}

export function getDb() { ensureInit(); return _db; }
export function getAuthInstance() { ensureInit(); return _auth; }
export function isConfigured() { const c = getConfig(); return !!(c?.apiKey && c?.projectId); }
export function reinitFirebase() { _initialized = false; _db = null; _auth = null; ensureInit(); }

// ============================================================
// AUTH
// ============================================================
export async function firebaseSignUp(email: string, password: string, displayName: string): Promise<FirebaseUser | null> {
  const auth = getAuthInstance();
  if (!auth) return null;
  try {
    const r = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(r.user, { displayName });
    return r.user;
  } catch (e: any) { throw new Error(getAuthError(e.code)); }
}

export async function firebaseSignIn(email: string, password: string): Promise<FirebaseUser | null> {
  const auth = getAuthInstance();
  if (!auth) return null;
  try { const r = await signInWithEmailAndPassword(auth, email, password); return r.user; }
  catch (e: any) { throw new Error(getAuthError(e.code)); }
}

export async function firebaseSignOut(): Promise<void> {
  const auth = getAuthInstance();
  if (auth) await signOut(auth);
}

export function onAuthChange(cb: (user: FirebaseUser | null) => void): () => void {
  const auth = getAuthInstance();
  if (!auth) return () => {};
  return onAuthStateChanged(auth, cb);
}

function getAuthError(code: string): string {
  const m: Record<string, string> = {
    'auth/email-already-in-use': 'Cet email est déjà utilisé',
    'auth/invalid-email': 'Email invalide',
    'auth/weak-password': 'Mot de passe trop faible (min 6 caractères)',
    'auth/user-not-found': 'Aucun compte avec cet email',
    'auth/wrong-password': 'Mot de passe incorrect',
    'auth/too-many-requests': 'Trop de tentatives. Réessayez plus tard',
  };
  return m[code] || 'Erreur d\'authentification';
}

// ============================================================
// FIRESTORE — WRITE (avec debounce anti-boucle)
// ============================================================
type CollectionName = 'orders' | 'clients' | 'products' | 'documents' | 'cashRecords' | 'users' | 'settings' | 'reviews' | 'technicians' | 'technicianReviews' | 'appointments';

// Flag pour éviter les boucles : onSnapshot met à jour le store → le store déclenche syncToFirestore → qui re-déclenche onSnapshot
let _writingTo: Record<string, boolean> = {};
let _writeTimers: Record<string, any> = {};

export function syncToFirestore(collectionName: CollectionName, data: any[]): void {
  const db = getDb();
  if (!db || !data || data.length === 0) return;

  // Debounce 3s par collection
  if (_writeTimers[collectionName]) clearTimeout(_writeTimers[collectionName]);
  _writeTimers[collectionName] = setTimeout(async () => {
    _writingTo[collectionName] = true;
    try {
      const batch = writeBatch(db);
      const ref = collection(db, collectionName);
      data.forEach(item => {
        const id = item.id?.toString() || item._docId || Math.random().toString(36).substring(2);
        batch.set(doc(ref, id), JSON.parse(JSON.stringify(item)));
      });
      await batch.commit();
    } catch (e) {
      console.warn(`⚠️ Sync ${collectionName} failed:`, e);
    }
    // Attendre 1s avant de réactiver les listeners pour éviter la boucle
    setTimeout(() => { _writingTo[collectionName] = false; }, 1000);
  }, 3000);
}

export async function saveDocToFirestore(collectionName: CollectionName, id: string, data: any): Promise<void> {
  const db = getDb();
  if (!db) return;
  try { await setDoc(doc(db, collectionName, id), JSON.parse(JSON.stringify(data))); }
  catch (e) { console.warn('Save failed:', e); }
}

export async function deleteDocFromFirestore(collectionName: CollectionName, id: string): Promise<void> {
  const db = getDb();
  if (!db || !id) return;
  try {
    _writingTo[collectionName] = true;
    await deleteDoc(doc(db, collectionName, id.toString()));
  } catch (e) {
    console.warn(`Delete ${collectionName}/${id} failed:`, e);
  } finally {
    setTimeout(() => { _writingTo[collectionName] = false; }, 1000);
  }
}

// ============================================================
// FIRESTORE — REALTIME LISTENERS (onSnapshot)
// ============================================================
export function listenToCollection(collectionName: CollectionName, onData: (data: any[]) => void, onError?: (err: any) => void): () => void {
  const db = getDb();
  if (!db) return () => {};

  const ref = collection(db, collectionName);
  return onSnapshot(ref, (snapshot) => {
    // Ignorer si on vient d'écrire (anti-boucle)
    if (_writingTo[collectionName]) return;
    const data = snapshot.docs.map(d => ({ ...d.data(), _docId: d.id }));
    onData(data);
  }, (err) => {
    console.warn(`❌ Listener ${collectionName} error:`, err);
    if (onError) onError(err);
  });
}

// ============================================================
// NETWORK — Reconnexion auto
// ============================================================
export function setupNetworkHandlers() {
  const db = getDb();
  if (!db) return;

  window.addEventListener('online', () => {
    console.log('🟢 Réseau rétabli — reconnexion Firebase');
    enableNetwork(db).catch(() => {});
    useStore.getState().setNotification({ message: '🟢 Connexion rétablie', type: 'success' });
  });

  window.addEventListener('offline', () => {
    console.log('🔴 Réseau perdu — mode hors-ligne');
    disableNetwork(db).catch(() => {});
    useStore.getState().setNotification({ message: '🔴 Mode hors-ligne — les données seront synchronisées au retour du réseau', type: 'info' });
  });
}

// ============================================================
// IMAGES — Compression pour stockage dans Firestore (pas besoin de Storage payant)
// ============================================================

/**
 * Compresse une image (File ou base64) en JPEG < 400ko pour Firestore.
 * Retourne un data URL compressé qui fonctionne sur tous les appareils.
 */
export function compressImage(imageData: string | File, maxWidth = 600, quality = 0.6): Promise<string> {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      console.error('Image compression timeout');
      resolve(typeof imageData === 'string' ? imageData : '');
    }, 30000);

    const finish = (value: string) => {
      clearTimeout(timeout);
      resolve(value);
    };

    // Si c'est déjà une URL HTTP → ne pas compresser
    if (typeof imageData === 'string' && (imageData.startsWith('http') || imageData.startsWith('/images/'))) {
      finish(imageData);
      return;
    }

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let w = img.width;
      let h = img.height;

      // Redimensionner si trop large
      if (w > maxWidth) {
        h = Math.round((h * maxWidth) / w);
        w = maxWidth;
      }

      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) { finish(typeof imageData === 'string' ? imageData : ''); return; }

      ctx.drawImage(img, 0, 0, w, h);

      // Compresser en JPEG
      let result = canvas.toDataURL('image/jpeg', quality);

      // Si encore trop gros (>400ko), réduire plus
      if (result.length > 400000) {
        result = canvas.toDataURL('image/jpeg', 0.3);
      }
      if (result.length > 400000) {
        canvas.width = Math.round(w * 0.5);
        canvas.height = Math.round(h * 0.5);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        result = canvas.toDataURL('image/jpeg', 0.3);
      }

      finish(result);
    };

    img.onerror = () => {
      console.error('Image load failed during compression');
      finish(typeof imageData === 'string' ? imageData : '');
    };

    if (imageData instanceof File) {
      const reader = new FileReader();
      reader.onload = () => { img.src = reader.result as string; };
      reader.onerror = () => {
        console.error('FileReader failed during image compression');
        finish('');
      };
      reader.readAsDataURL(imageData);
    } else {
      img.src = imageData;
    }
  });
}

/**
 * Compresse et retourne l'image prête pour Firestore
 */
export async function uploadProductImage(_productId: number, imageData: string | File): Promise<string> {
  return compressImage(imageData, 500, 0.55);
}

export async function uploadLogo(imageData: string | File): Promise<string> {
  return compressImage(imageData, 300, 0.7);
}

export async function uploadHeroImage(imageData: string | File): Promise<string> {
  return compressImage(imageData, 800, 0.5);
}

export async function uploadCategoryImage(_categoryId: string, imageData: string | File): Promise<string> {
  return compressImage(imageData, 400, 0.5);
}
