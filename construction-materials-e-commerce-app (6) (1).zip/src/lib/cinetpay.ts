// ============================================================
// CINETPAY — Intégration paiement Mobile Money
// ============================================================
// 👉 Pour utiliser CinetPay :
// 1. Créez un compte sur https://cinetpay.com
// 2. Récupérez votre API Key et Site ID depuis le dashboard
// 3. Remplacez les valeurs ci-dessous
// ============================================================

const CINETPAY_CONFIG = {
  apiKey: 'VOTRE_API_KEY_CINETPAY',
  siteId: '000000', // Votre Site ID
  notifyUrl: 'https://votre-site.com/api/notify', // URL de notification
  returnUrl: '', // Sera défini dynamiquement
};

export const isCinetPayConfigured = CINETPAY_CONFIG.apiKey !== 'VOTRE_API_KEY_CINETPAY';

export interface PaymentData {
  amount: number;
  orderId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  description: string;
}

// Charger le SDK CinetPay dynamiquement
function loadCinetPaySDK(): Promise<void> {
  return new Promise((resolve, reject) => {
    if ((window as any).CinetPay) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.cinetpay.com/seamless/main.js';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Impossible de charger CinetPay'));
    document.head.appendChild(script);
  });
}

// Ouvrir le guichet de paiement CinetPay
export async function initCinetPayPayment(data: PaymentData): Promise<string> {
  if (!isCinetPayConfigured) {
    // Mode démo — simuler un paiement réussi
    return new Promise((resolve) => {
      setTimeout(() => resolve('SUCCESS'), 1500);
    });
  }

  await loadCinetPaySDK();

  return new Promise((resolve, reject) => {
    const CinetPay = (window as any).CinetPay;
    if (!CinetPay) {
      reject(new Error('SDK CinetPay non chargé'));
      return;
    }

    CinetPay.setConfig({
      apikey: CINETPAY_CONFIG.apiKey,
      site_id: CINETPAY_CONFIG.siteId,
      notify_url: CINETPAY_CONFIG.notifyUrl,
      return_url: window.location.href,
      mode: 'PRODUCTION', // ou 'SANDBOX' pour les tests
    });

    CinetPay.getCheckout({
      transaction_id: data.orderId + '-' + Date.now(),
      amount: data.amount,
      currency: 'XAF',
      channels: 'ALL',
      description: data.description,
      customer_name: data.customerName,
      customer_surname: '',
      customer_email: data.customerEmail || 'client@batimarket.ga',
      customer_phone_number: data.customerPhone,
      customer_address: 'Port-Gentil',
      customer_city: 'Port-Gentil',
      customer_country: 'GA',
      customer_state: 'GA',
      customer_zip_code: '00225',
    });

    CinetPay.waitResponse(function (data: any) {
      if (data.status === 'REFUSED') {
        reject(new Error('Paiement refusé'));
      } else if (data.status === 'ACCEPTED') {
        resolve('SUCCESS');
      } else {
        resolve(data.status || 'PENDING');
      }
    });

    CinetPay.onError(function (data: any) {
      reject(new Error(data.message || 'Erreur de paiement'));
    });
  });
}

// Méthodes de paiement disponibles
export const paymentMethods = [
  { id: 'mtn', name: 'MTN Mobile Money', icon: '📱', desc: 'Paiement via MTN MoMo', online: true },
  { id: 'moov', name: 'Moov Money', icon: '💰', desc: 'Paiement via Moov Money', online: true },
  { id: 'orange', name: 'Orange Money', icon: '🍊', desc: 'Paiement via Orange Money', online: true },
  { id: 'wave', name: 'Wave', icon: '🌊', desc: 'Paiement via Wave', online: true },
  { id: 'card', name: 'Carte Bancaire', icon: '💳', desc: 'Visa, Mastercard', online: true },
  { id: 'cod', name: 'Paiement à la livraison', icon: '🚚', desc: 'Payez en espèces à la réception', online: false },
];
