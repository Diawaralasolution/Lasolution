export interface ShippingZone {
  id: string;
  name: string;
  description: string;
  price: number;
  estimatedDays: string;
  cities: string[];
}

export const shippingZones: ShippingZone[] = [
  {
    id: 'pg-centre',
    name: 'Port-Gentil Centre',
    description: 'Centre-ville, Grand Village, Chapuis',
    price: 2000,
    estimatedDays: '24h',
    cities: ['Centre-ville', 'Grand Village', 'Chapuis', 'Ntchengué'],
  },
  {
    id: 'pg-nord',
    name: 'Port-Gentil Nord',
    description: 'Quartier Nord, Balise, Aviation',
    price: 3000,
    estimatedDays: '24h',
    cities: ['Quartier Nord', 'Balise', 'Aviation', 'Matanda'],
  },
  {
    id: 'pg-sud',
    name: 'Port-Gentil Sud',
    description: 'Quartier Sud, Sogara, Cap Lopez',
    price: 3000,
    estimatedDays: '24h',
    cities: ['Quartier Sud', 'Sogara', 'Cap Lopez', 'Nouvelle Cité'],
  },
  {
    id: 'pg-peripherie',
    name: 'Périphérie Port-Gentil',
    description: 'Zones périphériques, camps pétroliers',
    price: 5000,
    estimatedDays: '24-48h',
    cities: ['Zone industrielle', 'Camp pétrolier', 'Ozouri'],
  },
  {
    id: 'libreville',
    name: 'Libreville',
    description: 'Livraison à Libreville par cargo',
    price: 25000,
    estimatedDays: '3-5 jours',
    cities: ['Libreville', 'Owendo', 'Akanda', 'Ntoum'],
  },
  {
    id: 'interieur',
    name: 'Intérieur du Gabon',
    description: 'Lambaréné, Franceville, Mouila, Oyem',
    price: 35000,
    estimatedDays: '5-7 jours',
    cities: ['Lambaréné', 'Franceville', 'Mouila', 'Oyem', 'Tchibanga', 'Makokou', 'Koulamoutou'],
  },
  {
    id: 'retrait',
    name: 'Retrait en magasin',
    description: 'Venez chercher votre commande à notre dépôt à Port-Gentil',
    price: 0,
    estimatedDays: 'Immédiat',
    cities: [],
  },
];

export const FREE_SHIPPING_THRESHOLD = 150000; // FCFA

export function getShippingPrice(zoneId: string, subtotal: number): number {
  if (subtotal >= FREE_SHIPPING_THRESHOLD) return 0;
  const zone = shippingZones.find(z => z.id === zoneId);
  return zone?.price || 0;
}

export function getShippingZoneName(zoneId: string): string {
  const zone = shippingZones.find(z => z.id === zoneId);
  return zone?.name || '';
}
