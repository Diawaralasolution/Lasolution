export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  category: string;
  subcategory: string;
  images: string[];
  stock: number;
  rating: number;
  reviews: number;
  featured: boolean;
  badge?: string;
  specs?: Record<string, string>;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  count: number;
  image: string;
  color: string;
  background?: string;
}

export const categories: Category[] = [
  { id: 'construction', name: 'Construction', icon: '🏗️', count: 12, image: '/images/ciment.jpg', color: 'from-orange-500 to-amber-600' },
  { id: 'plomberie', name: 'Plomberie', icon: '🔧', count: 10, image: '/images/robinet.jpg', color: 'from-blue-500 to-cyan-600' },
  { id: 'electricite', name: 'Électricité', icon: '⚡', count: 10, image: '/images/cable-electrique.jpg', color: 'from-yellow-500 to-orange-500' },
  { id: 'quincaillerie', name: 'Quincaillerie', icon: '🔩', count: 12, image: '/images/vis-coffret.jpg', color: 'from-gray-600 to-gray-800' },
  { id: 'outillage', name: 'Outillage', icon: '🛠️', count: 8, image: '/images/perceuse.jpg', color: 'from-red-500 to-rose-600' },
  { id: 'carrelage', name: 'Carrelage', icon: '◼️', count: 7, image: '/images/peinture.jpg', color: 'from-stone-500 to-zinc-700' },
  { id: 'menuiserie', name: 'Menuiserie', icon: '🪵', count: 8, image: '/images/perceuse.jpg', color: 'from-amber-700 to-orange-900' },
  { id: 'peinture', name: 'Peinture & Finition', icon: '🎨', count: 9, image: '/images/peinture.jpg', color: 'from-purple-500 to-indigo-600' },
];

const img = {
  ciment: '/images/ciment.jpg',
  fer: '/images/fer-beton.jpg',
  robinet: '/images/robinet.jpg',
  cable: '/images/cable-electrique.jpg',
  vis: '/images/vis-coffret.jpg',
  perceuse: '/images/perceuse.jpg',
  peinture: '/images/peinture.jpg',
  tableau: '/images/tableau-electrique.jpg',
  meuleuse: '/images/meuleuse.jpg',
  chauffe: '/images/chauffe-eau.jpg',
};

export const products: Product[] = [
  { id: 1, name: 'Ciment Portland CEM II 42.5 - 50kg', description: 'Ciment haute résistance pour béton, fondations, dalles et travaux courants.', price: 8500, oldPrice: 9500, category: 'construction', subcategory: 'Ciment & Béton', images: [img.ciment], stock: 500, rating: 4.8, reviews: 234, featured: true, badge: 'Promo', specs: { Poids: '50 kg', Type: 'CEM II 42.5' } },
  { id: 2, name: 'Fer à béton HA 12mm - Barre 12m', description: 'Barre d’acier nervurée haute adhérence pour béton armé.', price: 6200, category: 'construction', subcategory: 'Acier', images: [img.fer], stock: 350, rating: 4.6, reviews: 178, featured: true, specs: { Diamètre: '12 mm', Longueur: '12 m' } },
  { id: 3, name: 'Bloc béton creux 20x20x40', description: 'Agglo creux pour murs porteurs et cloisons.', price: 650, category: 'construction', subcategory: 'Blocs', images: [img.ciment], stock: 3000, rating: 4.5, reviews: 89, featured: false },
  { id: 4, name: 'Brique rouge pleine', description: 'Brique de construction pour maçonnerie et finitions.', price: 450, category: 'construction', subcategory: 'Briques', images: [img.ciment], stock: 5000, rating: 4.3, reviews: 62, featured: false },
  { id: 5, name: 'Sable lavé 0/4 - Tonne', description: 'Sable lavé pour mortier, béton et crépissage.', price: 35000, category: 'construction', subcategory: 'Agrégats', images: [img.ciment], stock: 120, rating: 4.4, reviews: 54, featured: false },
  { id: 6, name: 'Gravier concassé 5/15 - Tonne', description: 'Gravier calibré pour béton et drainage.', price: 42000, category: 'construction', subcategory: 'Agrégats', images: [img.ciment], stock: 90, rating: 4.4, reviews: 45, featured: false },
  { id: 7, name: 'Béton prêt à l’emploi 25MPa', description: 'Béton prêt pour dalle et fondations.', price: 95000, category: 'construction', subcategory: 'Béton', images: [img.ciment], stock: 30, rating: 4.7, reviews: 34, featured: true },
  { id: 8, name: 'Treillis soudé ST25', description: 'Treillis acier pour dallage béton.', price: 28000, category: 'construction', subcategory: 'Acier', images: [img.fer], stock: 80, rating: 4.6, reviews: 72, featured: false },
  { id: 9, name: 'Fil d’attache recuit 1kg', description: 'Fil recuit pour ligature de ferraillage.', price: 2500, category: 'construction', subcategory: 'Accessoires', images: [img.fer], stock: 200, rating: 4.5, reviews: 65, featured: false },
  { id: 10, name: 'Planche de coffrage 4m', description: 'Planche robuste pour coffrage béton.', price: 7000, category: 'construction', subcategory: 'Coffrage', images: [img.perceuse], stock: 120, rating: 4.4, reviews: 37, featured: false },
  { id: 11, name: 'Pointe acier 70mm - 1kg', description: 'Pointes acier pour coffrage et menuiserie.', price: 2200, category: 'construction', subcategory: 'Fixation', images: [img.vis], stock: 180, rating: 4.4, reviews: 51, featured: false },
  { id: 12, name: 'Chaux hydraulique 25kg', description: 'Chaux pour enduits, mortiers et assainissement.', price: 6800, category: 'construction', subcategory: 'Liants', images: [img.ciment], stock: 70, rating: 4.2, reviews: 22, featured: false },

  { id: 13, name: 'Robinet mitigeur cuisine inox', description: 'Mitigeur moderne avec bec orientable, cartouche céramique.', price: 45000, oldPrice: 55000, category: 'plomberie', subcategory: 'Robinetterie', images: [img.robinet], stock: 45, rating: 4.7, reviews: 123, featured: true, badge: 'Best-seller' },
  { id: 14, name: 'Tube PVC évacuation Ø100 - 4m', description: 'Tube PVC rigide pour eaux usées.', price: 12500, category: 'plomberie', subcategory: 'Tuyauterie', images: [img.robinet], stock: 200, rating: 4.4, reviews: 67, featured: false },
  { id: 15, name: 'Tube PVC pression Ø25 - 6m', description: 'Tube pression pour alimentation eau.', price: 8500, category: 'plomberie', subcategory: 'Tuyauterie', images: [img.robinet], stock: 160, rating: 4.5, reviews: 55, featured: false },
  { id: 16, name: 'Coude PVC Ø100 90°', description: 'Raccord coude pour évacuation.', price: 1800, category: 'plomberie', subcategory: 'Raccords', images: [img.robinet], stock: 300, rating: 4.4, reviews: 42, featured: false },
  { id: 17, name: 'Té PVC Ø100', description: 'Raccord té pour évacuation sanitaire.', price: 2500, category: 'plomberie', subcategory: 'Raccords', images: [img.robinet], stock: 240, rating: 4.4, reviews: 39, featured: false },
  { id: 18, name: 'Colle PVC 250ml', description: 'Colle spéciale raccord PVC pression et évacuation.', price: 3500, category: 'plomberie', subcategory: 'Consommables', images: [img.robinet], stock: 180, rating: 4.6, reviews: 74, featured: false },
  { id: 19, name: 'Lavabo céramique blanc', description: 'Lavabo mural en céramique avec trop-plein.', price: 35000, category: 'plomberie', subcategory: 'Sanitaire', images: [img.robinet], stock: 35, rating: 4.5, reviews: 31, featured: false },
  { id: 20, name: 'WC complet sortie horizontale', description: 'Pack WC avec réservoir, abattant et mécanisme.', price: 65000, category: 'plomberie', subcategory: 'Sanitaire', images: [img.robinet], stock: 25, rating: 4.6, reviews: 46, featured: true },
  { id: 21, name: 'Chauffe-eau électrique 100L', description: 'Chauffe-eau mural vertical 100 litres.', price: 125000, oldPrice: 145000, category: 'plomberie', subcategory: 'Eau chaude', images: [img.chauffe], stock: 20, rating: 4.6, reviews: 91, featured: true, badge: '-14%' },
  { id: 22, name: 'Flexible inox 50cm', description: 'Flexible sanitaire inox tressé.', price: 2500, category: 'plomberie', subcategory: 'Flexibles', images: [img.robinet], stock: 250, rating: 4.3, reviews: 44, featured: false },

  { id: 23, name: 'Câble électrique H07V-U 2.5mm² - 100m', description: 'Fil rigide cuivre pour circuits prises.', price: 28000, category: 'electricite', subcategory: 'Câbles', images: [img.cable], stock: 150, rating: 4.5, reviews: 145, featured: true },
  { id: 24, name: 'Câble électrique 1.5mm² - 100m', description: 'Fil cuivre pour circuits éclairage.', price: 19000, category: 'electricite', subcategory: 'Câbles', images: [img.cable], stock: 180, rating: 4.5, reviews: 96, featured: false },
  { id: 25, name: 'Tableau électrique 4 rangées', description: 'Coffret pré-équipé pour installation domestique.', price: 85000, oldPrice: 95000, category: 'electricite', subcategory: 'Tableaux', images: [img.tableau], stock: 30, rating: 4.8, reviews: 87, featured: true, badge: 'Promo' },
  { id: 26, name: 'Disjoncteur 16A', description: 'Disjoncteur modulaire 16 ampères.', price: 4500, category: 'electricite', subcategory: 'Protection', images: [img.tableau], stock: 160, rating: 4.4, reviews: 61, featured: false },
  { id: 27, name: 'Interrupteur différentiel 30mA 40A', description: 'Protection différentielle habitation.', price: 22000, category: 'electricite', subcategory: 'Protection', images: [img.tableau], stock: 80, rating: 4.6, reviews: 52, featured: false },
  { id: 28, name: 'Prise murale 2P+T blanche', description: 'Prise encastrable avec terre.', price: 2500, category: 'electricite', subcategory: 'Appareillage', images: [img.cable], stock: 300, rating: 4.3, reviews: 81, featured: false },
  { id: 29, name: 'Interrupteur double va-et-vient', description: 'Interrupteur encastrable blanc.', price: 3500, category: 'electricite', subcategory: 'Appareillage', images: [img.cable], stock: 260, rating: 4.3, reviews: 74, featured: false },
  { id: 30, name: 'Gaine ICTA Ø20 - rouleau 50m', description: 'Gaine flexible pour câblage électrique.', price: 18500, category: 'electricite', subcategory: 'Gaines', images: [img.cable], stock: 90, rating: 4.4, reviews: 39, featured: false },
  { id: 31, name: 'Ampoule LED 12W E27', description: 'Ampoule LED basse consommation lumière blanche.', price: 1800, category: 'electricite', subcategory: 'Éclairage', images: [img.cable], stock: 400, rating: 4.5, reviews: 121, featured: false },
  { id: 32, name: 'Projecteur LED extérieur 50W', description: 'Projecteur IP65 pour extérieur.', price: 18000, category: 'electricite', subcategory: 'Éclairage', images: [img.tableau], stock: 70, rating: 4.6, reviews: 48, featured: true },

  { id: 33, name: 'Coffret vis à bois inox 1000 pcs', description: 'Assortiment de vis inox pour bois et menuiserie.', price: 18500, category: 'quincaillerie', subcategory: 'Visserie', images: [img.vis], stock: 80, rating: 4.7, reviews: 156, featured: true, badge: 'Top vente' },
  { id: 34, name: 'Chevilles nylon + vis - 200 pcs', description: 'Kit de fixation murale polyvalent.', price: 7500, category: 'quincaillerie', subcategory: 'Fixation', images: [img.vis], stock: 140, rating: 4.4, reviews: 73, featured: false },
  { id: 35, name: 'Charnière porte 100mm', description: 'Charnière acier pour porte bois.', price: 1500, category: 'quincaillerie', subcategory: 'Ferrures', images: [img.vis], stock: 220, rating: 4.2, reviews: 38, featured: false },
  { id: 36, name: 'Serrure à encastrer', description: 'Serrure porte intérieure avec clés.', price: 9500, category: 'quincaillerie', subcategory: 'Serrurerie', images: [img.vis], stock: 75, rating: 4.5, reviews: 63, featured: false },
  { id: 37, name: 'Cadenas haute sécurité 70mm', description: 'Cadenas laiton avec anse acier trempé.', price: 15000, category: 'quincaillerie', subcategory: 'Serrurerie', images: [img.vis], stock: 120, rating: 4.4, reviews: 98, featured: false },
  { id: 38, name: 'Poignée de porte aluminium', description: 'Poignée design avec rosace.', price: 8500, category: 'quincaillerie', subcategory: 'Poignées', images: [img.vis], stock: 100, rating: 4.3, reviews: 35, featured: false },
  { id: 39, name: 'Équerre de fixation 60x60', description: 'Équerre métal galvanisé.', price: 500, category: 'quincaillerie', subcategory: 'Fixation', images: [img.vis], stock: 500, rating: 4.1, reviews: 25, featured: false },
  { id: 40, name: 'Rivet pop aluminium - boîte', description: 'Rivets aluminium pour tôles et profilés.', price: 6500, category: 'quincaillerie', subcategory: 'Rivets', images: [img.vis], stock: 90, rating: 4.3, reviews: 34, featured: false },
  { id: 41, name: 'Chaîne acier galvanisé 5mm', description: 'Chaîne métallique au mètre.', price: 2500, category: 'quincaillerie', subcategory: 'Chaînes', images: [img.vis], stock: 120, rating: 4.2, reviews: 22, featured: false },
  { id: 42, name: 'Mastic silicone transparent', description: 'Silicone sanitaire et menuiserie.', price: 3500, category: 'quincaillerie', subcategory: 'Étanchéité', images: [img.vis], stock: 180, rating: 4.5, reviews: 54, featured: false },
  { id: 43, name: 'Ruban téflon plomberie', description: 'Ruban PTFE pour raccords filetés.', price: 800, category: 'quincaillerie', subcategory: 'Étanchéité', images: [img.robinet], stock: 300, rating: 4.6, reviews: 88, featured: false },
  { id: 44, name: 'Colle contact multi-usage', description: 'Colle pour bois, cuir, stratifié.', price: 4500, category: 'quincaillerie', subcategory: 'Colles', images: [img.vis], stock: 110, rating: 4.4, reviews: 41, featured: false },

  { id: 45, name: 'Perceuse-visseuse sans fil 18V', description: 'Perceuse professionnelle avec batteries et chargeur.', price: 75000, oldPrice: 89000, category: 'outillage', subcategory: 'Électroportatif', images: [img.perceuse], stock: 40, rating: 4.9, reviews: 312, featured: true, badge: '-16%' },
  { id: 46, name: 'Meuleuse angulaire 125mm 1200W', description: 'Meuleuse puissante pour coupe et ponçage.', price: 42000, category: 'outillage', subcategory: 'Électroportatif', images: [img.meuleuse], stock: 35, rating: 4.6, reviews: 189, featured: false },
  { id: 47, name: 'Marteau arrache-clou', description: 'Marteau manche fibre antichoc.', price: 6500, category: 'outillage', subcategory: 'Main', images: [img.perceuse], stock: 150, rating: 4.4, reviews: 76, featured: false },
  { id: 48, name: 'Tournevis isolés - jeu 6 pièces', description: 'Jeu de tournevis pour électricité.', price: 12000, category: 'outillage', subcategory: 'Main', images: [img.perceuse], stock: 80, rating: 4.6, reviews: 52, featured: false },
  { id: 49, name: 'Pince multiprise 250mm', description: 'Pince réglable pour plomberie et mécanique.', price: 8500, category: 'outillage', subcategory: 'Pinces', images: [img.perceuse], stock: 90, rating: 4.5, reviews: 63, featured: false },
  { id: 50, name: 'Mètre ruban 5m', description: 'Mètre robuste avec blocage automatique.', price: 3500, category: 'outillage', subcategory: 'Mesure', images: [img.perceuse], stock: 200, rating: 4.4, reviews: 99, featured: false },
  { id: 51, name: 'Niveau à bulle 60cm', description: 'Niveau aluminium pour chantier.', price: 6500, category: 'outillage', subcategory: 'Mesure', images: [img.perceuse], stock: 100, rating: 4.5, reviews: 69, featured: false },
  { id: 52, name: 'Échelle aluminium 6 marches', description: 'Échelle légère et stable.', price: 55000, category: 'outillage', subcategory: 'Accès', images: [img.perceuse], stock: 25, rating: 4.6, reviews: 33, featured: false },

  { id: 53, name: 'Carrelage sol 60x60 gris - carton', description: 'Carrelage grès cérame moderne pour sol.', price: 18500, category: 'carrelage', subcategory: 'Sol', images: [img.peinture], stock: 120, rating: 4.5, reviews: 82, featured: true },
  { id: 54, name: 'Carrelage mural 30x60 blanc - carton', description: 'Faïence murale pour salle de bain et cuisine.', price: 14500, category: 'carrelage', subcategory: 'Mur', images: [img.peinture], stock: 140, rating: 4.4, reviews: 67, featured: false },
  { id: 55, name: 'Colle carrelage 25kg', description: 'Mortier colle pour carrelage intérieur/extérieur.', price: 8500, category: 'carrelage', subcategory: 'Colles', images: [img.ciment], stock: 90, rating: 4.6, reviews: 75, featured: false },
  { id: 56, name: 'Joint carrelage blanc 5kg', description: 'Joint poudre hydrofuge pour carrelage.', price: 6000, category: 'carrelage', subcategory: 'Joints', images: [img.peinture], stock: 80, rating: 4.3, reviews: 39, featured: false },
  { id: 57, name: 'Croisillons carrelage 2mm - sachet', description: 'Croisillons pour pose régulière.', price: 1500, category: 'carrelage', subcategory: 'Accessoires', images: [img.peinture], stock: 250, rating: 4.2, reviews: 44, featured: false },
  { id: 58, name: 'Plinthe carrelage gris', description: 'Plinthe assortie au carrelage sol.', price: 2500, category: 'carrelage', subcategory: 'Plinthes', images: [img.peinture], stock: 300, rating: 4.2, reviews: 25, featured: false },
  { id: 59, name: 'Coupe-carreaux manuel 60cm', description: 'Coupe-carreaux pour pose professionnelle.', price: 42000, category: 'carrelage', subcategory: 'Outillage', images: [img.meuleuse], stock: 22, rating: 4.7, reviews: 31, featured: false },

  { id: 60, name: 'Contreplaqué 18mm 250x125', description: 'Panneau contreplaqué pour menuiserie.', price: 32000, category: 'menuiserie', subcategory: 'Panneaux', images: [img.perceuse], stock: 45, rating: 4.5, reviews: 52, featured: true },
  { id: 61, name: 'MDF 16mm 244x122', description: 'Panneau MDF pour mobilier et agencement.', price: 28000, category: 'menuiserie', subcategory: 'Panneaux', images: [img.perceuse], stock: 50, rating: 4.4, reviews: 46, featured: false },
  { id: 62, name: 'Bois rouge raboté 4m', description: 'Lame bois rabotée pour charpente légère.', price: 9500, category: 'menuiserie', subcategory: 'Bois', images: [img.perceuse], stock: 100, rating: 4.3, reviews: 38, featured: false },
  { id: 63, name: 'Tasseau bois 30x40 - 3m', description: 'Tasseau sec pour ossature et finition.', price: 2500, category: 'menuiserie', subcategory: 'Bois', images: [img.perceuse], stock: 200, rating: 4.2, reviews: 29, featured: false },
  { id: 64, name: 'Porte isoplane 204x83', description: 'Porte intérieure prête à peindre.', price: 45000, category: 'menuiserie', subcategory: 'Portes', images: [img.perceuse], stock: 30, rating: 4.4, reviews: 21, featured: false },
  { id: 65, name: 'Vernis bois transparent 1L', description: 'Vernis de protection finition brillante.', price: 8500, category: 'menuiserie', subcategory: 'Finition bois', images: [img.peinture], stock: 70, rating: 4.5, reviews: 47, featured: false },
  { id: 66, name: 'Colle à bois 500ml', description: 'Colle forte pour assemblage bois.', price: 4500, category: 'menuiserie', subcategory: 'Colles', images: [img.vis], stock: 90, rating: 4.6, reviews: 58, featured: false },
  { id: 67, name: 'Papier abrasif assortiment', description: 'Feuilles abrasives grains variés.', price: 3500, category: 'menuiserie', subcategory: 'Ponçage', images: [img.peinture], stock: 140, rating: 4.3, reviews: 64, featured: false },

  { id: 68, name: 'Peinture acrylique mat blanc 15L', description: 'Peinture intérieure professionnelle, très couvrante.', price: 32000, oldPrice: 38000, category: 'peinture', subcategory: 'Peinture intérieure', images: [img.peinture], stock: 60, rating: 4.5, reviews: 201, featured: true, badge: '-16%' },
  { id: 69, name: 'Peinture façade extérieure 15L', description: 'Peinture résistante aux intempéries.', price: 45000, category: 'peinture', subcategory: 'Peinture extérieure', images: [img.peinture], stock: 45, rating: 4.6, reviews: 85, featured: false },
  { id: 70, name: 'Sous-couche universelle 10L', description: 'Primaire d’accrochage avant peinture.', price: 22000, category: 'peinture', subcategory: 'Préparation', images: [img.peinture], stock: 75, rating: 4.4, reviews: 55, featured: false },
  { id: 71, name: 'Enduit de rebouchage 5kg', description: 'Enduit prêt à l’emploi pour fissures et trous.', price: 8500, category: 'peinture', subcategory: 'Enduits', images: [img.peinture], stock: 90, rating: 4.4, reviews: 78, featured: false },
  { id: 72, name: 'Rouleau peinture pro 250mm', description: 'Rouleau polyamide anti-goutte.', price: 4500, category: 'peinture', subcategory: 'Accessoires', images: [img.peinture], stock: 200, rating: 4.2, reviews: 134, featured: false },
  { id: 73, name: 'Bac à peinture 15L', description: 'Bac plastique pour rouleau et pinceau.', price: 3500, category: 'peinture', subcategory: 'Accessoires', images: [img.peinture], stock: 120, rating: 4.2, reviews: 44, featured: false },
  { id: 74, name: 'Pinceau plat 50mm', description: 'Pinceau pour finition et angles.', price: 1800, category: 'peinture', subcategory: 'Accessoires', images: [img.peinture], stock: 200, rating: 4.1, reviews: 50, featured: false },
  { id: 75, name: 'Ruban de masquage 50m', description: 'Ruban adhésif pour protection des bords.', price: 2500, category: 'peinture', subcategory: 'Protection', images: [img.peinture], stock: 160, rating: 4.3, reviews: 72, featured: false },
  { id: 76, name: 'Solvant White Spirit 1L', description: 'Solvant de nettoyage pour peintures glycéro.', price: 3000, category: 'peinture', subcategory: 'Solvants', images: [img.peinture], stock: 110, rating: 4.2, reviews: 37, featured: false },
];

export const testimonials = [
  { id: 1, name: 'Jean-Pierre Ndong', role: 'Entrepreneur BTP', content: 'Catalogue complet et livraison rapide à Port-Gentil.', rating: 5, avatar: '👷' },
  { id: 2, name: 'Marie-Claire Obame', role: 'Architecte d\'intérieur', content: 'Très bon choix en peinture, carrelage et finitions.', rating: 5, avatar: '👩‍💼' },
  { id: 3, name: 'Patrick Moussavou', role: 'Plombier professionnel', content: 'Les produits plomberie sont disponibles et bien détaillés.', rating: 4, avatar: '👨‍🔧' },
  { id: 4, name: 'Sylvie Nzé', role: 'Particulier', content: 'J\'ai trouvé facilement tous les matériaux pour mes travaux.', rating: 5, avatar: '👩' },
];