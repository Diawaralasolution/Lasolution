import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Product, Category, categories as initialCategories, products as initialProducts } from '../data/products';

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  createdAt: string;
  totalSpent: number;
  orderCount: number;
}

export interface GeoLocation {
  lat: number;
  lng: number;
  label?: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  shipping: number;
  shippingZone: string;
  tvaRate: number;
  tvaAmount: number;
  discountType?: 'percent' | 'amount';
  discountValue?: number;
  discountAmount?: number;
  depositType?: 'percent' | 'amount';
  depositValue?: number;
  depositAmount?: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered';
  date: string;
  paymentMethod: string;
  address: string;
  phone: string;
  clientName: string;
  clientEmail: string;
  geo?: GeoLocation;
  statusStamp?: string;
}

export interface DocumentRecord {
  id: string;
  type: 'facture' | 'proforma' | 'devis';
  orderId?: string;
  date: string;
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  clientAddress: string;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  shippingZone: string;
  tvaRate: number;
  tvaAmount: number;
  total: number;
  paymentMethod: string;
  status: 'draft' | 'sent' | 'converted';
  convertedTo?: string;
}

export interface CashRecord {
  id: string;
  date: string;
  time: string;
  type: 'in' | 'out';
  label: string;
  amount: number;
  orderId?: string;
  method: string;
}

export interface Subcategory {
  id: string;
  categoryId: string;
  name: string;
}

export interface ProductReview {
  id: string;
  productId: number;
  userName: string;
  userEmail: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Technician {
  id: string;
  name: string;
  trade: string;
  city: string;
  zone: string;
  experience: number;
  phone: string;
  whatsapp: string;
  photo: string;
  description: string;
  specialties: string[];
  gallery: string[];
  hours: string;
  status: 'available' | 'busy';
  active: boolean;
  contactCount: number;
}

export interface TechnicianReview {
  id: string;
  technicianId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface AppointmentRequest {
  id: string;
  technicianId: string;
  clientName: string;
  phone: string;
  message: string;
  date: string;
  status: 'pending' | 'confirmed' | 'done';
}

export interface CompanyInfo {
  name: string;
  logo: string;
  slogan: string;
  description: string;
  // Hero / En-tête page d'accueil
  heroTitle1: string;
  heroTitle2: string;
  heroTitle3: string;
  heroBadge: string;
  heroImage: string;
  heroBtnText1: string;
  heroBtnText2: string;
  heroStat1Value: string;
  heroStat1Label: string;
  heroStat2Value: string;
  heroStat2Label: string;
  heroStat3Value: string;
  heroStat3Label: string;
  heroPromoText: string;
  heroPromoPercent: string;
  heroQualityText: string;
  heroQualitySub: string;
  trustBadge1Title: string;
  trustBadge1Desc: string;
  trustBadge2Title: string;
  trustBadge2Desc: string;
  trustBadge3Title: string;
  trustBadge3Desc: string;
  trustBadge4Title: string;
  trustBadge4Desc: string;
  topBarText: string;
  // Contact
  address: string;
  city: string;
  country: string;
  phone: string;
  whatsapp: string;
  email: string;
  website: string;
  hours: string;
  rccm: string;
  ncc: string;
  capital: string;
  bankName: string;
  bankAccount: string;
  bankBic: string;
  mobileMoney: string;
  facebook: string;
  instagram: string;
  tiktok: string;
  linkedin: string;
  twitter: string;
  gpsLat: string;
  gpsLng: string;
  conditionsFacture: string;
  conditionsProforma: string;
  conditionsDevis: string;
  privacy: string;
  paymentMethods: string; // legacy — kept for compat
  customPaymentMethods: PaymentMethodItem[];
}

export interface PaymentMethodItem {
  id: string;
  name: string;
  icon: string;
  desc: string;
  online: boolean;
  enabled: boolean;
}

export const defaultPaymentMethods: PaymentMethodItem[] = [
  { id: 'airtel', name: 'Airtel Money', icon: '📱', desc: 'Paiement via Airtel Money', online: true, enabled: true },
  { id: 'mtn', name: 'MTN Mobile Money', icon: '💛', desc: 'Paiement via MTN MoMo', online: true, enabled: false },
  { id: 'moov', name: 'Moov Money', icon: '💰', desc: 'Paiement via Moov Money', online: true, enabled: false },
  { id: 'card', name: 'Carte Bancaire', icon: '💳', desc: 'Visa, Mastercard', online: true, enabled: true },
  { id: 'transfer', name: 'Virement Bancaire', icon: '🏦', desc: 'Virement BGFI / UGB', online: false, enabled: true },
  { id: 'cod', name: 'Paiement à la livraison', icon: '🚚', desc: 'Payez en espèces à la réception', online: false, enabled: true },
];

export const defaultCompanyInfo: CompanyInfo = {
  name: '',
  logo: '',
  slogan: '',
  description: '',
  heroTitle1: '',
  heroTitle2: '',
  heroTitle3: '',
  heroBadge: '',
  heroImage: '',
  heroBtnText1: '',
  heroBtnText2: '',
  heroStat1Value: '',
  heroStat1Label: '',
  heroStat2Value: '',
  heroStat2Label: '',
  heroStat3Value: '',
  heroStat3Label: '',
  heroPromoText: '',
  heroPromoPercent: '',
  heroQualityText: '',
  heroQualitySub: '',
  trustBadge1Title: '',
  trustBadge1Desc: '',
  trustBadge2Title: '',
  trustBadge2Desc: '',
  trustBadge3Title: '',
  trustBadge3Desc: '',
  trustBadge4Title: '',
  trustBadge4Desc: '',
  topBarText: '',
  address: '',
  city: '',
  country: '',
  phone: '',
  whatsapp: '',
  email: '',
  website: '',
  hours: '',
  rccm: '',
  ncc: '',
  capital: '',
  bankName: '',
  bankAccount: '',
  bankBic: '',
  mobileMoney: '',
  facebook: '',
  instagram: '',
  tiktok: '',
  linkedin: '',
  twitter: '',
  gpsLat: '',
  gpsLng: '',
  conditionsFacture: '',
  conditionsProforma: '',
  conditionsDevis: '',
  privacy: '',
  paymentMethods: '',
  customPaymentMethods: [],
};

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export const defaultFirebaseConfig: FirebaseConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'admin' | 'user';
  status: 'active' | 'disabled';
  createdAt: string;
  password: string; // simple hash for local mode
}

export type Page = 'home' | 'catalog' | 'product' | 'cart' | 'checkout' | 'account' | 'admin' | 'orders' | 'documents' | 'technicians';

interface StoreState {
  currentPage: Page;
  pageHistory: Page[];
  selectedProductId: number | null;
  selectedCategory: string;
  setPage: (page: Page) => void;
  goBack: () => void;
  setSelectedProduct: (id: number | null) => void;
  setSelectedCategory: (cat: string) => void;

  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  setCart: (items: CartItem[]) => void;
  getCartTotal: () => number;
  getCartCount: () => number;

  searchQuery: string;
  setSearchQuery: (q: string) => void;
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;

  isLoggedIn: boolean;
  user: { name: string; email: string; phone: string; role: 'admin' | 'user' } | null;
  userAccounts: UserAccount[];
  login: (name: string, email: string, phone: string, role?: 'admin' | 'user') => void;
  register: (name: string, email: string, phone: string, password: string) => string | null; // returns error or null
  loginWithPassword: (email: string, password: string) => string | null;
  logout: () => void;
  isAdmin: () => boolean;
  addUserAccount: (account: UserAccount) => void;
  updateUserAccount: (id: string, data: Partial<UserAccount>) => void;
  deleteUserAccount: (id: string) => void;

  orders: Order[];
  addOrder: (order: Order) => void;
  updateOrder: (id: string, data: Partial<Order>) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  deleteOrder: (orderId: string) => void;

  documents: DocumentRecord[];
  addDocument: (doc: DocumentRecord) => void;
  updateDocument: (id: string, data: Partial<DocumentRecord>) => void;
  deleteDocument: (id: string) => void;

  cashRecords: CashRecord[];
  addCashRecord: (record: CashRecord) => void;
  deleteCashRecord: (id: string) => void;

  clients: Client[];
  addClient: (client: Client) => void;
  updateClient: (id: string, data: Partial<Client>) => void;
  deleteClient: (id: string) => void;

  stockProducts: Product[];
  updateStock: (productId: number, newStock: number) => void;
  updateProductPrice: (productId: number, newPrice: number) => void;
  updateProductImage: (productId: number, imageDataUrl: string) => void;
  updateProductField: (productId: number, data: Partial<Product>) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (productId: number) => void;

  customCategories: Category[];
  addCategory: (cat: Category) => void;
  updateCategory: (id: string, data: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  customSubcategories: Subcategory[];
  addSubcategory: (sub: Subcategory) => void;
  updateSubcategory: (id: string, data: Partial<Subcategory>) => void;
  deleteSubcategory: (id: string) => void;

  productReviews: ProductReview[];
  addProductReview: (review: ProductReview) => void;
  deleteProductReview: (id: string) => void;

  technicians: Technician[];
  technicianReviews: TechnicianReview[];
  appointments: AppointmentRequest[];
  addTechnician: (tech: Technician) => void;
  updateTechnician: (id: string, data: Partial<Technician>) => void;
  deleteTechnician: (id: string) => void;
  incrementTechnicianContact: (id: string) => void;
  addTechnicianReview: (review: TechnicianReview) => void;
  deleteTechnicianReview: (id: string) => void;
  addAppointment: (request: AppointmentRequest) => void;
  updateAppointment: (id: string, data: Partial<AppointmentRequest>) => void;
  deleteAppointment: (id: string) => void;

  companyInfo: CompanyInfo;
  updateCompanyInfo: (data: Partial<CompanyInfo>) => void;

  firebaseConfig: FirebaseConfig;
  updateFirebaseConfig: (data: Partial<FirebaseConfig>) => void;

  darkMode: boolean;
  toggleDarkMode: () => void;
  showMobileMenu: boolean;
  setShowMobileMenu: (show: boolean) => void;
  showCart: boolean;
  setShowCart: (show: boolean) => void;
  notification: { message: string; type: 'success' | 'error' | 'info' } | null;
  setNotification: (n: { message: string; type: 'success' | 'error' | 'info' } | null) => void;
  newOrderCount: number;
  clearNewOrders: () => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
}

const defaultClients: Client[] = [];

const defaultSubcategories: Subcategory[] = [
  { id: 'sub-ciment', categoryId: 'construction', name: 'Ciment & Béton' },
  { id: 'sub-acier', categoryId: 'construction', name: 'Acier' },
  { id: 'sub-blocs', categoryId: 'construction', name: 'Blocs & Briques' },
  { id: 'sub-robinet', categoryId: 'plomberie', name: 'Robinetterie' },
  { id: 'sub-tuyaux', categoryId: 'plomberie', name: 'Tuyauterie' },
  { id: 'sub-sanitaire', categoryId: 'plomberie', name: 'Sanitaire' },
  { id: 'sub-cables', categoryId: 'electricite', name: 'Câbles' },
  { id: 'sub-protection', categoryId: 'electricite', name: 'Protection' },
  { id: 'sub-visserie', categoryId: 'quincaillerie', name: 'Visserie' },
  { id: 'sub-serrurerie', categoryId: 'quincaillerie', name: 'Serrurerie' },
  { id: 'sub-sol', categoryId: 'carrelage', name: 'Sol' },
  { id: 'sub-mur', categoryId: 'carrelage', name: 'Mur' },
  { id: 'sub-bois', categoryId: 'menuiserie', name: 'Bois' },
  { id: 'sub-panneaux', categoryId: 'menuiserie', name: 'Panneaux' },
  { id: 'sub-peinture-int', categoryId: 'peinture', name: 'Peinture intérieure' },
  { id: 'sub-finition', categoryId: 'peinture', name: 'Finition' },
];

const defaultTechnicians: Technician[] = [
  { id: 'TECH-001', name: 'Jean Mavoungou', trade: 'Électricien', city: 'Port-Gentil', zone: 'Centre-ville', experience: 8, phone: '+241 07 00 00 03', whatsapp: '24107000003', photo: '', description: 'Électricien qualifié pour installation, dépannage et rénovation.', specialties: ['Tableau électrique', 'Câblage', 'Éclairage'], gallery: [], hours: 'Lun-Sam 8h-18h', status: 'available', active: true, contactCount: 0 },
  { id: 'TECH-002', name: 'Patrick Nze', trade: 'Plombier', city: 'Port-Gentil', zone: 'Grand Village', experience: 10, phone: '+241 07 00 00 02', whatsapp: '24107000002', photo: '', description: 'Plomberie sanitaire, raccords, fuites et installation chauffe-eau.', specialties: ['Sanitaire', 'PVC', 'Chauffe-eau'], gallery: [], hours: 'Lun-Sam 7h-18h', status: 'available', active: true, contactCount: 0 },
  { id: 'TECH-003', name: 'Marc Ondo', trade: 'Maçon', city: 'Port-Gentil', zone: 'Cap Lopez', experience: 12, phone: '+241 07 00 00 01', whatsapp: '24107000001', photo: '', description: 'Travaux de maçonnerie, dalle, mur, crépissage et fondations.', specialties: ['Fondations', 'Dalles', 'Crépis'], gallery: [], hours: 'Lun-Sam 7h-17h', status: 'busy', active: true, contactCount: 0 },
  { id: 'TECH-004', name: 'Alain Mbina', trade: 'Menuisier', city: 'Port-Gentil', zone: 'Sogara', experience: 7, phone: '+241 07 00 00 05', whatsapp: '24107000005', photo: '', description: 'Menuiserie bois, portes, placards, pose et réparations.', specialties: ['Portes', 'Placards', 'Bois'], gallery: [], hours: 'Lun-Sam 8h-17h', status: 'available', active: true, contactCount: 0 },
];

const notify = (set: any, message: string, type: 'success' | 'error' | 'info' = 'success') => {
  set({ notification: { message, type } });
  setTimeout(() => set({ notification: null }), 3000);
};

const deleteRemote = (collectionName: string, id: string | number) => {
  import('../lib/firebase')
    .then(({ deleteDocFromFirestore }) => deleteDocFromFirestore(collectionName as any, String(id)))
    .catch(() => {});
};

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // ===== NAVIGATION =====
      currentPage: 'home',
      pageHistory: [],
      selectedProductId: null,
      selectedCategory: 'all',
      setPage: (page) => {
        const current = get().currentPage;
        const history = get().pageHistory;
        // Don't push same page twice
        if (current !== page) {
          set({ currentPage: page, pageHistory: [...history, current], showMobileMenu: false });
        }
        window.scrollTo(0, 0);
      },
      goBack: () => {
        const history = get().pageHistory;
        if (history.length > 0) {
          const prev = history[history.length - 1];
          set({ currentPage: prev, pageHistory: history.slice(0, -1), showMobileMenu: false });
        } else {
          set({ currentPage: 'home', showMobileMenu: false });
        }
        window.scrollTo(0, 0);
      },
      setSelectedProduct: (id) => set({ selectedProductId: id }),
      setSelectedCategory: (cat) => set({ selectedCategory: cat }),

      // ===== PANIER =====
      cart: [],
      addToCart: (product, quantity = 1) => {
        const cart = get().cart;
        const existing = cart.find(item => item.product.id === product.id);
        if (existing) {
          set({ cart: cart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item) });
        } else {
          set({ cart: [...cart, { product, quantity }] });
        }
        notify(set, `${product.name} ajouté au panier`);
      },
      removeFromCart: (productId) => {
        set({ cart: get().cart.filter(item => item.product.id !== productId) });
        notify(set, 'Article retiré du panier', 'info');
      },
      updateQuantity: (productId, quantity) => {
        if (quantity <= 0) { get().removeFromCart(productId); return; }
        set({ cart: get().cart.map(item => item.product.id === productId ? { ...item, quantity } : item) });
      },
      clearCart: () => set({ cart: [] }),
      setCart: (items) => set({ cart: items }),
      getCartTotal: () => get().cart.reduce((s, i) => s + i.product.price * i.quantity, 0),
      getCartCount: () => get().cart.reduce((s, i) => s + i.quantity, 0),

      // ===== RECHERCHE & FILTRES =====
      searchQuery: '',
      setSearchQuery: (q) => set({ searchQuery: q }),
      priceRange: [0, 200000],
      setPriceRange: (range) => set({ priceRange: range }),
      sortBy: 'popular',
      setSortBy: (sort) => set({ sortBy: sort }),

      // ===== AUTHENTIFICATION =====
      isLoggedIn: false,
      user: null,
      userAccounts: [
        { id: 'ADMIN-001', name: 'Administrateur', email: 'admin@batimarket.ga', phone: '+241 00 00 00 00', role: 'admin', status: 'active', createdAt: '01/01/2026', password: 'admin123' },
      ],
      login: (name, email, phone, role = 'user') => {
        set({ isLoggedIn: true, user: { name, email, phone, role }, currentPage: 'home', showMobileMenu: false });
        notify(set, `Bienvenue ${name} !`);
      },
      register: (name, email, phone, password) => {
        const accounts = get().userAccounts;
        if (accounts.find(a => a.email.toLowerCase() === email.toLowerCase())) {
          return 'Cet email est déjà utilisé';
        }
        const newAccount: UserAccount = {
          id: 'USR-' + Date.now().toString(36).toUpperCase(),
          name, email, phone, role: 'user', status: 'active',
          createdAt: new Date().toLocaleDateString('fr-FR'),
          password,
        };
        set({ userAccounts: [...accounts, newAccount] });
        set({ isLoggedIn: true, user: { name, email, phone, role: 'user' }, currentPage: 'home', showMobileMenu: false });
        notify(set, `Compte créé ! Bienvenue ${name}`);
        return null;
      },
      loginWithPassword: (email, password) => {
        let account = get().userAccounts.find(a => a.email.toLowerCase() === email.toLowerCase());
        // Fallback admin — si le compte admin par défaut n'existe pas, le recréer
        if (!account && email.toLowerCase() === 'admin@batimarket.ga' && password === 'admin123') {
          const adminAccount = { id: 'ADMIN-001', name: 'Administrateur', email: 'admin@batimarket.ga', phone: '+241 00 00 00 00', role: 'admin' as const, status: 'active' as const, createdAt: '01/01/2026', password: 'admin123' };
          set({ userAccounts: [...get().userAccounts, adminAccount] });
          account = adminAccount;
        }
        if (!account) return 'Aucun compte avec cet email';
        if (account.password !== password) return 'Mot de passe incorrect';
        if (account.status === 'disabled') return 'Ce compte a été désactivé. Contactez l\'administrateur.';
        set({ isLoggedIn: true, user: { name: account.name, email: account.email, phone: account.phone, role: account.role }, currentPage: 'home', showMobileMenu: false });
        notify(set, `Bienvenue ${account.name} !`);
        return null;
      },
      logout: () => {
        set({ isLoggedIn: false, user: null, currentPage: 'home', showMobileMenu: false });
        notify(set, 'Déconnexion réussie', 'info');
      },
      isAdmin: () => get().user?.role === 'admin',
      addUserAccount: (account) => { set({ userAccounts: [...get().userAccounts, account] }); notify(set, 'Utilisateur ajouté'); },
      updateUserAccount: (id, data) => { set({ userAccounts: get().userAccounts.map(a => a.id === id ? { ...a, ...data } : a) }); notify(set, 'Utilisateur mis à jour'); },
      deleteUserAccount: (id) => { set({ userAccounts: get().userAccounts.filter(a => a.id !== id) }); deleteRemote('users', id); notify(set, 'Utilisateur supprimé', 'info'); },

      // ===== COMMANDES =====
      orders: [],
      addOrder: (order) => {
        set({ orders: [...get().orders, order], newOrderCount: get().newOrderCount + 1 });
        // Enregistrement automatique en caisse
        const now = new Date();
        get().addCashRecord({
          id: 'CASH-' + Date.now().toString(36).toUpperCase(),
          date: now.toLocaleDateString('fr-FR'),
          time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
          type: 'in',
          label: `Commande ${order.id} — ${order.clientName || 'Client'}`,
          amount: order.total,
          orderId: order.id,
          method: order.paymentMethod,
        });
        // Diminuer le stock
        order.items.forEach(item => {
          const sp = get().stockProducts;
          const idx = sp.findIndex(p => p.id === item.product.id);
          if (idx !== -1) {
            const updated = [...sp];
            updated[idx] = { ...updated[idx], stock: Math.max(0, updated[idx].stock - item.quantity) };
            set({ stockProducts: updated });
          }
        });
        // Créer/mettre à jour le client
        const clients = get().clients;
        const existing = clients.find(c => c.phone === order.phone || (order.clientEmail && c.email === order.clientEmail));
        if (existing) {
          set({ clients: clients.map(c => c.id === existing.id ? { ...c, totalSpent: c.totalSpent + order.total, orderCount: c.orderCount + 1 } : c) });
        } else if (order.clientName) {
          set({
            clients: [...clients, {
              id: 'CLI-' + Date.now().toString(36).toUpperCase(),
              name: order.clientName, phone: order.phone, email: order.clientEmail,
              address: order.address, city: '', createdAt: order.date,
              totalSpent: order.total, orderCount: 1,
            }]
          });
        }
      },
      updateOrder: (id, data) => {
        set({ orders: get().orders.map(o => (o.id === id || (o as any)._docId === id) ? { ...o, ...data } : o) });
        notify(set, 'Commande mise à jour');
      },
      updateOrderStatus: (orderId, status) => {
        set({ orders: get().orders.map(o => (o.id === orderId || (o as any)._docId === orderId) ? { ...o, status } : o) });
      },
      deleteOrder: (orderId) => {
        set({ orders: get().orders.filter(o => o.id !== orderId && (o as any)._docId !== orderId) });
        deleteRemote('orders', orderId);
        notify(set, 'Commande supprimée', 'info');
      },

      // ===== DOCUMENTS =====
      documents: [],
      addDocument: (doc) => set({ documents: [...get().documents, doc] }),
      updateDocument: (id, data) => {
        set({ documents: get().documents.map(d => d.id === id ? { ...d, ...data } : d) });
        notify(set, 'Document mis à jour');
      },
      deleteDocument: (id) => {
        set({ documents: get().documents.filter(d => d.id !== id) });
        deleteRemote('documents', id);
        notify(set, 'Document supprimé', 'info');
      },

      // ===== CAISSE =====
      cashRecords: [],
      addCashRecord: (record) => set({ cashRecords: [...get().cashRecords, record] }),
      deleteCashRecord: (id) => { set({ cashRecords: get().cashRecords.filter(r => r.id !== id) }); deleteRemote('cashRecords', id); notify(set, 'Opération supprimée', 'info'); },

      // ===== CLIENTS =====
      clients: defaultClients,
      addClient: (client) => { set({ clients: [...get().clients, client] }); notify(set, 'Client ajouté'); },
      updateClient: (id, data) => { set({ clients: get().clients.map(c => c.id === id ? { ...c, ...data } : c) }); notify(set, 'Client mis à jour'); },
      deleteClient: (id) => { set({ clients: get().clients.filter(c => c.id !== id) }); deleteRemote('clients', id); notify(set, 'Client supprimé', 'info'); },

      // ===== PRODUITS & STOCK =====
      stockProducts: [...initialProducts],
      updateStock: (productId, newStock) => { set({ stockProducts: get().stockProducts.map(p => p.id === productId ? { ...p, stock: newStock } : p) }); notify(set, 'Stock mis à jour'); },
      updateProductPrice: (productId, newPrice) => { set({ stockProducts: get().stockProducts.map(p => p.id === productId ? { ...p, price: newPrice } : p) }); notify(set, 'Prix mis à jour'); },
      updateProductImage: (productId, imageDataUrl) => { set({ stockProducts: get().stockProducts.map(p => p.id === productId ? { ...p, images: [imageDataUrl, ...p.images.slice(1)] } : p) }); notify(set, 'Image mise à jour'); },
      updateProductField: (productId, data) => { set({ stockProducts: get().stockProducts.map(p => p.id === productId ? { ...p, ...data } : p) }); },
      addProduct: (product) => { set({ stockProducts: [...get().stockProducts, product] }); notify(set, 'Produit ajouté'); },
      deleteProduct: (productId) => { set({ stockProducts: get().stockProducts.filter(p => p.id !== productId) }); deleteRemote('products', productId); notify(set, 'Produit supprimé', 'info'); },

      // ===== CATEGORIES =====
      customCategories: [...initialCategories],
      addCategory: (cat) => { set({ customCategories: [...get().customCategories, cat] }); notify(set, 'Catégorie ajoutée'); },
      updateCategory: (id, data) => { set({ customCategories: get().customCategories.map(c => c.id === id ? { ...c, ...data } : c) }); notify(set, 'Catégorie modifiée'); },
      deleteCategory: (id) => { set({ customCategories: get().customCategories.filter(c => c.id !== id) }); notify(set, 'Catégorie supprimée', 'info'); },

      // ===== SOUS-CATEGORIES =====
      customSubcategories: [...defaultSubcategories],
      addSubcategory: (sub) => { set({ customSubcategories: [...get().customSubcategories, sub] }); notify(set, 'Sous-catégorie ajoutée'); },
      updateSubcategory: (id, data) => { set({ customSubcategories: get().customSubcategories.map(s => s.id === id ? { ...s, ...data } : s) }); notify(set, 'Sous-catégorie modifiée'); },
      deleteSubcategory: (id) => { set({ customSubcategories: get().customSubcategories.filter(s => s.id !== id) }); notify(set, 'Sous-catégorie supprimée', 'info'); },

      // ===== AVIS PRODUITS =====
      productReviews: [],
      addProductReview: (review) => { set({ productReviews: [...get().productReviews, review] }); notify(set, 'Merci pour votre appréciation'); },
      deleteProductReview: (id) => { set({ productReviews: get().productReviews.filter(r => r.id !== id) }); deleteRemote('reviews', id); notify(set, 'Avis supprimé', 'info'); },

      // ===== TECHNICIENS =====
      technicians: [...defaultTechnicians],
      technicianReviews: [],
      appointments: [],
      addTechnician: (tech) => { set({ technicians: [...get().technicians, tech] }); notify(set, 'Technicien ajouté'); },
      updateTechnician: (id, data) => { set({ technicians: get().technicians.map(t => t.id === id ? { ...t, ...data } : t) }); notify(set, 'Technicien mis à jour'); },
      deleteTechnician: (id) => { set({ technicians: get().technicians.filter(t => t.id !== id) }); deleteRemote('technicians', id); notify(set, 'Technicien supprimé', 'info'); },
      incrementTechnicianContact: (id) => { set({ technicians: get().technicians.map(t => t.id === id ? { ...t, contactCount: (t.contactCount || 0) + 1 } : t) }); },
      addTechnicianReview: (review) => { set({ technicianReviews: [...get().technicianReviews, review] }); notify(set, 'Avis technicien ajouté'); },
      deleteTechnicianReview: (id) => { set({ technicianReviews: get().technicianReviews.filter(r => r.id !== id) }); deleteRemote('technicianReviews', id); notify(set, 'Avis technicien supprimé', 'info'); },
      addAppointment: (request) => { set({ appointments: [...get().appointments, request] }); notify(set, 'Demande de rendez-vous envoyée'); },
      updateAppointment: (id, data) => { set({ appointments: get().appointments.map(a => a.id === id ? { ...a, ...data } : a) }); notify(set, 'Rendez-vous mis à jour'); },
      deleteAppointment: (id) => { set({ appointments: get().appointments.filter(a => a.id !== id) }); deleteRemote('appointments', id); notify(set, 'Rendez-vous supprimé', 'info'); },

      // ===== ENTREPRISE =====
      companyInfo: { ...defaultCompanyInfo },
      updateCompanyInfo: (data) => {
        set({ companyInfo: { ...get().companyInfo, ...data } });
        notify(set, 'Informations enregistrées');
      },

      // ===== FIREBASE =====
      firebaseConfig: { ...defaultFirebaseConfig },
      updateFirebaseConfig: (data) => {
        set({ firebaseConfig: { ...get().firebaseConfig, ...data } });
        notify(set, 'Configuration Firebase enregistrée. Rechargez la page pour appliquer.');
      },

      // ===== UI =====
      darkMode: false,
      toggleDarkMode: () => set({ darkMode: !get().darkMode }),
      showMobileMenu: false,
      setShowMobileMenu: (show) => set({ showMobileMenu: show }),
      showCart: false,
      setShowCart: (show) => set({ showCart: show }),
      notification: null,
      setNotification: (n) => set({ notification: n }),
      newOrderCount: 0,
      clearNewOrders: () => set({ newOrderCount: 0 }),
      authMode: 'login' as const,
      setAuthMode: (mode) => set({ authMode: mode }),
    }),
    {
      name: 'batimarket-storage',
      version: 2, // Incrémentez pour forcer un reset si nécessaire
      partialize: (state) => ({
        cart: state.cart,
        orders: state.orders,
        documents: state.documents,
        cashRecords: state.cashRecords,
        clients: state.clients,
        stockProducts: state.stockProducts,
        customCategories: state.customCategories,
        customSubcategories: state.customSubcategories,
        productReviews: state.productReviews,
        technicians: state.technicians,
        technicianReviews: state.technicianReviews,
        appointments: state.appointments,
        companyInfo: state.companyInfo,
        firebaseConfig: state.firebaseConfig,
        userAccounts: state.userAccounts,
        darkMode: state.darkMode,
        isLoggedIn: state.isLoggedIn,
        user: state.user,
        newOrderCount: state.newOrderCount,
      }),
      migrate: (persistedState: any, version: number) => {
        // Migration v1 → v2 : mise à jour Gabon
        if (version < 2) {
          return {
            ...persistedState,
            companyInfo: { ...defaultCompanyInfo, ...(persistedState?.companyInfo || {}) },
            clients: persistedState?.clients?.length > 0 ? persistedState.clients : defaultClients,
          };
        }
        return persistedState;
      },
    }
  )
);
