import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import { CartItem, Order, DocumentRecord, useStore } from '../store/useStore';

export type DocumentType = 'facture' | 'proforma' | 'devis';

interface DocumentData {
  type: DocumentType;
  id: string;
  date: string;
  validUntil?: string;
  client: { name: string; phone: string; email: string; address: string };
  items: CartItem[];
  subtotal: number;
  shipping: number;
  shippingZone?: string;
  tvaRate: number;
  tvaAmount: number;
  discountAmount?: number;
  depositAmount?: number;
  total: number;
  paymentMethod?: string;
  notes?: string;
  statusStamp?: string; // "Payé Livré", "Livré Payé", "Payé Non Livré", "Livré Non Payé"
}

const C = {
  primary: [30, 58, 95] as [number, number, number],
  primaryDark: [20, 40, 66] as [number, number, number],
  secondary: [249, 115, 22] as [number, number, number],
  dark: [15, 23, 42] as [number, number, number],
  text: [51, 65, 85] as [number, number, number],
  gray: [100, 116, 139] as [number, number, number],
  light: [241, 245, 249] as [number, number, number],
  white: [255, 255, 255] as [number, number, number],
  green: [22, 163, 74] as [number, number, number],
  line: [203, 213, 225] as [number, number, number],
};

const fmtP = (n: number) => {
  const str = Math.round(n).toString();
  const formatted = str.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return formatted + ' FCFA';
};

function docTitle(t: DocumentType) {
  return t === 'facture' ? 'FACTURE' : t === 'proforma' ? 'FACTURE PROFORMA' : 'DEVIS';
}
function docPrefix(t: DocumentType) {
  return t === 'facture' ? 'FAC' : t === 'proforma' ? 'PRO' : 'DEV';
}

function fallbackLogo(doc: any, x: number, letter: string, size = 26) {
  doc.setFillColor(...C.secondary);
  doc.roundedRect(x, 8, size, size, 5, 5, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(Math.min(20, size - 6));
  doc.setTextColor(...C.white);
  doc.text(letter || 'B', x + size * 0.24, 8 + size * 0.62);
}

export async function generateDocument(data: DocumentData): Promise<void> {
  const co = useStore.getState().companyInfo; // Company info from store
  const doc = new jsPDF('p', 'mm', 'a4');
  const pw = doc.internal.pageSize.getWidth();
  const ph = doc.internal.pageSize.getHeight();
  const m = 15;
  const cw = pw - m * 2;
  let y = 0;
  let qrDataUrl = '';
  const websiteLink = co.website
    ? (co.website.startsWith('http') ? co.website : `https://${co.website}`)
    : '';
  if (websiteLink) {
    try {
      qrDataUrl = await QRCode.toDataURL(websiteLink, { width: 128, margin: 1, errorCorrectionLevel: 'M' });
    } catch (e) {
      console.warn('QR generation failed:', e);
    }
  }

  // ================================================================
  // HEADER BAND — Full-width blue bar
  // ================================================================
  doc.setFillColor(...C.primaryDark);
  doc.rect(0, 0, pw, 64, 'F');
  doc.setFillColor(...C.primary);
  doc.rect(0, 0, pw, 60, 'F');

  // Orange accent bar
  doc.setFillColor(...C.secondary);
  doc.rect(0, 60, pw, 1.5, 'F');

  // Logo — left side
  const logoSize = 36;
  if (co.logo) {
    try {
      doc.addImage(co.logo, 'JPEG', m, 8, logoSize, logoSize);
    }
    catch { fallbackLogo(doc, m, co.name[0] || 'B', logoSize); }
  } else {
    fallbackLogo(doc, m, co.name[0] || 'B', logoSize);
  }

  // Company info — CENTERED in the blue bar
  const centerX = pw / 2 - 16;
  const maxNameW = pw * 0.48;

  // Nom centré en haut
  doc.setFontSize(28);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...C.white);
  const normalizedName = (co.name || '').toUpperCase();
  const nameLines = normalizedName.includes('ETS DIAWARA') && normalizedName.includes('LA SOLUTION')
    ? ['ETS DIAWARA', 'LA SOLUTION']
    : doc.splitTextToSize(co.name, maxNameW).slice(0, 3);
  const nameStartY = 19;
  const nameLineGap = 12;
  nameLines.forEach((line: string, i: number) => {
    doc.text(line, centerX, nameStartY + i * nameLineGap, { align: 'center' });
  });
  const lastNameY = nameStartY + (nameLines.length - 1) * nameLineGap;

  // Slogan
  doc.setFontSize(11.4);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(180, 195, 215);
  const sloganY = lastNameY + 14;
  doc.text(co.slogan, centerX, sloganY, { align: 'center' });

  // RCCM + NIF
  doc.setFontSize(10);
  if (co.rccm) {
    doc.text(`RCCM: ${co.rccm}  •  NIF: ${co.ncc}`, centerX, sloganY + 8, { align: 'center' });
  }

  // Document type — right side
  const rightX = pw - m;
  const title = docTitle(data.type);
  doc.setFontSize(17);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...C.white);
  doc.text(title, rightX, 16, { align: 'right' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(180, 195, 215);
  doc.text(`N° ${data.id}`, rightX, 25, { align: 'right' });
  doc.text(`Date: ${data.date}`, rightX, 32, { align: 'right' });
  if (data.validUntil) doc.text(`Validité: ${data.validUntil}`, rightX, 39, { align: 'right' });

  y = Math.max(70, sloganY + 18);

  // ================================================================
  // COMPANY & CLIENT SIDE BY SIDE
  // ================================================================
  const boxW = (cw - 8) / 2;
  const boxH = 38;

  // — Émetteur
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(m, y, boxW, boxH, 2, 2, 'F');
  doc.setDrawColor(...C.line);
  doc.roundedRect(m, y, boxW, boxH, 2, 2, 'S');

  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...C.secondary);
  doc.text('DE :', m + 5, y + 7);
  doc.setFontSize(9);
  doc.setTextColor(...C.dark);
  doc.text(co.name, m + 5, y + 13);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(...C.text);
  doc.text(`${co.address}, ${co.city}`, m + 5, y + 18.5);
  doc.text(co.country, m + 5, y + 23);
  doc.text(`Tél: ${co.phone}`, m + 5, y + 27.5);
  doc.text(`Email: ${co.email}`, m + 5, y + 32);

  // — Client
  const cx = m + boxW + 8;
  doc.setFillColor(...C.primary);
  doc.roundedRect(cx, y, boxW, boxH, 2, 2, 'F');

  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...C.secondary);
  doc.text('FACTURER À :', cx + 5, y + 7);
  doc.setFontSize(9);
  doc.setTextColor(...C.white);
  doc.text(data.client.name || 'Client', cx + 5, y + 13);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(200, 215, 230);
  const addrLines = doc.splitTextToSize(data.client.address || '', boxW - 12);
  addrLines.forEach((line: string, i: number) => {
    doc.text(line, cx + 5, y + 18.5 + i * 4);
  });
  const addrEndY = y + 18.5 + addrLines.length * 4;
  if (data.client.phone) doc.text('Tél: ' + data.client.phone, cx + 5, addrEndY + 1);
  if (data.client.email) doc.text(data.client.email, cx + 5, addrEndY + 5.5);

  y += boxH + 8;

  // ================================================================
  // PAYMENT METHOD & TRANSPORT STRIP
  // ================================================================
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(m, y, cw, 10, 2, 2, 'F');
  doc.setDrawColor(...C.line);
  doc.roundedRect(m, y, cw, 10, 2, 2, 'S');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...C.text);

  if (data.paymentMethod) {
    doc.setFont('helvetica', 'bold');
    doc.text('Paiement:', m + 5, y + 6.5);
    doc.setFont('helvetica', 'normal');
    doc.text(data.paymentMethod, m + 28, y + 6.5);
  }

  if (data.shippingZone) {
    const tz = `Transport: ${data.shippingZone} — ${data.shipping === 0 ? 'Gratuit' : fmtP(data.shipping)}`;
    doc.text(tz, pw - m - 5, y + 6.5, { align: 'right' });
  }

  y += 15;

  // ================================================================
  // PRODUCTS TABLE — Professional with row numbers & clean design
  // ================================================================
  const tableData = data.items.map((item, i) => [
    String(i + 1),
    item.product.name,
    String(item.quantity),
    fmtP(item.product.price),
    fmtP(item.product.price * item.quantity),
  ]);

  autoTable(doc, {
    startY: y,
    head: [['N°', 'Désignation du produit', 'Qté', 'Prix unitaire', 'Montant']],
    body: tableData,
    foot: [[
      '', '', '', 'Sous-total HT', fmtP(data.subtotal),
    ]],
    styles: {
      fontSize: 7.5,
      cellPadding: { top: 3, bottom: 3, left: 4, right: 4 },
      textColor: C.text,
      lineColor: C.line,
      lineWidth: 0.2,
      font: 'helvetica',
    },
    headStyles: {
      fillColor: C.primary,
      textColor: C.white,
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: { top: 4, bottom: 4, left: 4, right: 4 },
    },
    footStyles: {
      fillColor: [248, 250, 252],
      textColor: C.dark,
      fontStyle: 'bold',
      fontSize: 8,
    },
    alternateRowStyles: {
      fillColor: [252, 252, 254],
    },
    columnStyles: {
      0: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      1: { cellWidth: 'auto' },
      2: { cellWidth: 16, halign: 'center' },
      3: { cellWidth: 32, halign: 'right' },
      4: { cellWidth: 32, halign: 'right', fontStyle: 'bold' },
    },
    margin: { left: m, right: m },
    theme: 'grid',
    tableLineColor: C.line,
    tableLineWidth: 0.2,
  });

  y = (doc as any).lastAutoTable.finalY + 6;

  // ================================================================
  // TOTALS — Right-aligned summary box
  // ================================================================
  const totX = pw - m - 90;
  const totW = 90;

  const drawLine = (label: string, value: string, opts?: { bold?: boolean; big?: boolean; green?: boolean; orange?: boolean }) => {
    const h = opts?.big ? 11 : 8;
    if (opts?.orange) {
      doc.setFillColor(...C.secondary);
      doc.roundedRect(totX, y, totW, h, 1.5, 1.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(opts?.big ? 10 : 8);
      doc.setTextColor(...C.white);
    } else {
      doc.setFillColor(248, 250, 252);
      doc.rect(totX, y, totW, h, 'F');
      doc.setDrawColor(...C.line);
      doc.line(totX, y + h, totX + totW, y + h);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', opts?.bold ? 'bold' : 'normal');
      if (opts?.green) doc.setTextColor(...C.green);
      else doc.setTextColor(...C.text);
    }
    const ty = y + (h / 2) + (opts?.big ? 3.5 : 2.5);
    doc.text(label, totX + 5, ty);
    const vw = doc.getTextWidth(value);
    doc.text(value, totX + totW - 5 - vw, ty);
    y += h + 1;
  };

  drawLine('Sous-total HT', fmtP(data.subtotal));
  if ((data.discountAmount || 0) > 0) {
    drawLine('Remise', '-' + fmtP(data.discountAmount || 0), { bold: true });
  }
  
  // Transport
  if (data.shipping > 0) {
    drawLine(
      data.shippingZone ? `Transport (${data.shippingZone})` : 'Frais de transport',
      fmtP(data.shipping)
    );
  }

  if (data.tvaRate > 0 && data.tvaAmount > 0) {
    drawLine(`TVA (${data.tvaRate}%)`, fmtP(data.tvaAmount));
  }
  y += 2;
  
  // Total
  const displayTotal = data.total;
  drawLine('TOTAL À PAYER', fmtP(displayTotal), { bold: true, big: true, orange: true });
  
  // Acompte
  if ((data.depositAmount || 0) > 0) {
    drawLine('Acompte versé', fmtP(data.depositAmount || 0), { bold: true, green: true });
    drawLine('Solde à payer', fmtP(Math.max(0, displayTotal - (data.depositAmount || 0))), { bold: true });
  }

  y += 4;

  // ================================================================
  // AMOUNT IN WORDS (for professionalism)
  // ================================================================
  doc.setFillColor(255, 251, 240);
  doc.roundedRect(m, y, cw, 9, 1.5, 1.5, 'F');
  doc.setDrawColor(251, 191, 36);
  doc.roundedRect(m, y, cw, 9, 1.5, 1.5, 'S');
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(180, 130, 0);
  doc.text('Arrêtée la présente ' + docTitle(data.type).toLowerCase() + ' à la somme de : ' + fmtP(displayTotal), m + 5, y + 6);

  y += 14;

  // ================================================================
  // NOTES
  // ================================================================
  if (data.notes) {
    doc.setFontSize(7);
    doc.setFont('helvetica', 'italic');
    doc.setTextColor(...C.gray);
    doc.text('Note: ' + data.notes, m, y, { maxWidth: cw });
    y += 8;
  }

  // ================================================================
  // CONDITIONS
  // ================================================================
  y = Math.max(y, 218);
  doc.setDrawColor(...C.line);
  doc.line(m, y, pw - m, y);
  y += 5;

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...C.primary);
  doc.text('CONDITIONS GÉNÉRALES', m, y);
  y += 4;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...C.gray);
  // Use custom conditions from company settings if available
  const customConds = co.conditionsFacture ? co.conditionsFacture.split('\n').filter(Boolean) : [];
  const qrSize = 30;
  const qrX = pw - m - qrSize;
  const qrY = y - 8;
  const conditionMaxWidth = qrDataUrl ? cw - qrSize - 8 : cw;
  if (qrDataUrl) {
    try {
      doc.addImage(qrDataUrl, 'PNG', qrX, qrY, qrSize, qrSize);
      doc.setFontSize(5.5);
      doc.setTextColor(...C.gray);
      doc.text('Scannez le lien', qrX + qrSize / 2, qrY + qrSize + 4, { align: 'center' });
    } catch (e) {
      console.warn('QR addImage failed:', e);
    }
  }
  const conds: Record<DocumentType, string[]> = {
    facture: customConds.length > 0 ? customConds : [
      `Paiement à réception sauf accord particulier.`,
      `Les marchandises livrées restent propriété de ${co.name} jusqu'au paiement intégral.`,
      `Toute réclamation doit être faite dans les 48 heures suivant la livraison.`,
      `En cas de litige, seuls les tribunaux de ${co.city} sont compétents.`,
    ],
    proforma: [
      'Ce document est une facture proforma à titre indicatif.',
      'Les prix sont susceptibles de variation selon la disponibilité.',
      'Validité : 15 jours à compter de la date d\'émission.',
      'La commande ne sera traitée qu\'après réception du paiement.',
      'Un acompte de 10% est requis à la commande.',
    ],
    devis: [
      'Ce devis est valable 30 jours à compter de sa date d\'émission.',
      'Pour acceptation, retourner signé avec la mention "Bon pour accord".',
      'Les délais de livraison sont estimatifs.',
      'Un acompte de 10% est requis à la commande, le solde à la livraison.',
    ],
  };
  conds[data.type].forEach(l => {
    doc.text('  •  ' + l, m, y, { maxWidth: conditionMaxWidth });
    y += 5;
  });

  // BANK DETAILS — SUPPRIMÉ

  // ================================================================
  // SIGNATURE ZONE
  // ================================================================
  y += 20;
  if (y < ph - 35) {
    const sigW = (cw - 10) / 2;
    // Émetteur
    doc.setDrawColor(...C.line);
    doc.setLineDashPattern([1, 1], 0);
    doc.rect(m, y, sigW, 18, 'S');
    doc.setLineDashPattern([], 0);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...C.gray);
    doc.text('Cachet et signature de l\'émetteur', m + sigW / 2, y + 15, { align: 'center' });

    // Client
    doc.setLineDashPattern([1, 1], 0);
    doc.rect(m + sigW + 10, y, sigW, 18, 'S');
    doc.setLineDashPattern([], 0);
    doc.text('Cachet et signature du client', m + sigW + 10 + sigW / 2, y + 15, { align: 'center' });
    doc.setFontSize(5.5);
    doc.setFont('helvetica', 'normal');
    doc.text('(Bon pour accord)', m + sigW + 10 + sigW / 2, y + 18, { align: 'center' });
  }

  // ================================================================
  // STATUS STAMP (Payé, Livré, etc.)
  // ================================================================
  if (data.statusStamp && data.type === 'facture') {
    const stampLines = data.statusStamp.split(' ');
    const stampText = stampLines.join(' ');
    doc.saveGraphicsState();
    doc.setGState(new (doc as any).GState({ opacity: 0.6 }));
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(28);
    doc.setTextColor(50, 180, 50); // green
    // Draw rotated text
    const cx = pw / 2;
    const cy = 185;
    // Rotate 35 degrees
    doc.text(stampText, cx, cy, { align: 'center', angle: 35 });
    doc.restoreGraphicsState();
  }

  // ================================================================
  // FOOTER
  // ================================================================
  const fy = ph - 10;
  doc.setFillColor(...C.primary);
  doc.rect(0, fy - 3, pw, 13, 'F');
  doc.setFillColor(...C.secondary);
  doc.rect(0, fy - 3, pw, 1.5, 'F');

  doc.setFontSize(6);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...C.white);
  doc.text(
    `${co.name}  •  ${co.address}, ${co.city}, ${co.country}  •  ${co.phone}  •  ${co.email}  •  ${co.website}`,
    pw / 2, fy + 2, { align: 'center' }
  );
  doc.setFontSize(5);
  doc.setTextColor(160, 175, 195);
  doc.text(
    `RCCM: ${co.rccm}  •  N° Contribuable: ${co.ncc}  •  Capital: ${co.capital}`,
    pw / 2, fy + 6, { align: 'center' }
  );

  // ================================================================
  // WATERMARK for Proforma / Devis
  // ================================================================
  if (data.type !== 'facture') {
    doc.setFontSize(46);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(235, 238, 242);
    doc.text(docTitle(data.type), pw / 2, 155, { align: 'center', angle: 35 });
  }

  // SAVE
  const fn = `${docPrefix(data.type)}-${data.id}-${data.date.replace(/\//g, '-')}.pdf`;
  doc.save(fn);
}

// ================================================================
// HELPERS
// ================================================================

function saveDocRecord(type: DocumentType, id: string, date: string, orderId: string | undefined, client: { name: string; phone: string; email: string; address: string }, items: CartItem[], subtotal: number, shipping: number, shippingZone: string, tvaRate: number, tvaAmount: number, total: number, paymentMethod: string) {
  const store = useStore.getState();
  const doc: DocumentRecord = {
    id: `${docPrefix(type)}-${id}`,
    type,
    orderId,
    date,
    clientName: client.name,
    clientPhone: client.phone,
    clientEmail: client.email,
    clientAddress: client.address,
    items: [...items],
    subtotal,
    shipping,
    shippingZone,
    tvaRate,
    tvaAmount,
    total,
    paymentMethod,
    status: 'draft',
  };
  // avoid duplicates
  const existing = store.documents.find(d => d.id === doc.id);
  if (!existing) store.addDocument(doc);
}

export function generateInvoiceFromOrder(order: Order, type: DocumentType = 'facture'): void {
  const validDate = new Date();
  validDate.setDate(validDate.getDate() + (type === 'devis' ? 30 : 15));
  const subtotal = order.items.reduce((s, i) => s + i.product.price * i.quantity, 0);

  generateDocument({
    type,
    id: order.id,
    date: order.date,
    validUntil: type !== 'facture' ? validDate.toLocaleDateString('fr-FR') : undefined,
    client: { name: order.clientName || 'Client', phone: order.phone, email: order.clientEmail || '', address: order.address },
    items: order.items,
    subtotal,
    shipping: order.shipping,
    shippingZone: order.shippingZone,
    tvaRate: order.tvaRate,
    tvaAmount: order.tvaAmount,
    discountAmount: order.discountAmount,
    depositAmount: order.depositAmount,
    total: order.total,
    paymentMethod: order.paymentMethod,
    statusStamp: order.statusStamp,
  });

  saveDocRecord(type, order.id, order.date, order.id,
    { name: order.clientName, phone: order.phone, email: order.clientEmail, address: order.address },
    order.items, subtotal, order.shipping, order.shippingZone, order.tvaRate, order.tvaAmount, order.total, order.paymentMethod);
}

export function generateFromCart(
  type: DocumentType,
  items: CartItem[],
  client: { name: string; phone: string; email: string; address: string },
  shipping: number,
  shippingZone: string,
  tvaRate: number,
  tvaAmount: number,
): void {
  const id = `${docPrefix(type)}-${Date.now().toString(36).toUpperCase()}`;
  const date = new Date().toLocaleDateString('fr-FR');
  const validDate = new Date();
  validDate.setDate(validDate.getDate() + (type === 'devis' ? 30 : 15));
  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const total = subtotal + shipping + tvaAmount;

  generateDocument({
    type, id, date,
    validUntil: validDate.toLocaleDateString('fr-FR'),
    client, items, subtotal, shipping, shippingZone, tvaRate, tvaAmount,
    total,
    discountAmount: 0,
    depositAmount: 0,
    notes: type === 'devis'
      ? 'Devis valable 30 jours. Retourner signé avec la mention "Bon pour accord".'
      : 'Document non contractuel – Facture proforma à titre indicatif.',
  });

  saveDocRecord(type, id, date, undefined, client, items, subtotal, shipping, shippingZone, tvaRate, tvaAmount, total, '');
}

// ================================================================
// WHATSAPP ORDER MESSAGE
// ================================================================
export function buildWhatsAppOrderMessage(order: Order): string {
  const f = (n: number) => n.toLocaleString('fr-FR');
  const lines: string[] = [];

  lines.push('🧾 *CONFIRMATION DE COMMANDE*');
  lines.push('━━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`📋 *N°* ${order.id}`);
  lines.push(`📅 *Date:* ${order.date}`);
  lines.push('');
  lines.push('👤 *CLIENT*');
  lines.push(`Nom: ${order.clientName}`);
  lines.push(`Tél: ${order.phone}`);
  if (order.clientEmail) lines.push(`Email: ${order.clientEmail}`);
  lines.push(`Adresse: ${order.address}`);
  if (order.geo) {
    lines.push(`📍 *GPS:* https://www.google.com/maps?q=${order.geo.lat},${order.geo.lng}`);
  }
  lines.push('');
  lines.push('📦 *ARTICLES COMMANDÉS*');
  lines.push('───────────────────────');

  order.items.forEach((item, i) => {
    lines.push(`${i + 1}. ${item.product.name}`);
    lines.push(`   ${item.quantity} x ${f(item.product.price)} = *${f(item.product.price * item.quantity)} FCFA*`);
  });

  lines.push('───────────────────────');

  const subtotal = order.items.reduce((s, i) => s + i.product.price * i.quantity, 0);
  lines.push(`💰 Sous-total: ${f(subtotal)} FCFA`);

  if (order.shippingZone) {
    lines.push(`🚛 Transport (${order.shippingZone}): ${order.shipping === 0 ? 'GRATUIT ✅' : f(order.shipping) + ' FCFA'}`);
  }

  if (order.tvaRate > 0 && order.tvaAmount > 0) {
    lines.push(`📊 TVA (${order.tvaRate}%): ${f(order.tvaAmount)} FCFA`);
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`🔶 *TOTAL: ${f(order.total)} FCFA*`);
  lines.push('━━━━━━━━━━━━━━━━━━━━━━');
  lines.push('');
  lines.push(`💳 *Paiement:* ${order.paymentMethod}`);
  lines.push(`📍 *Statut:* En cours de traitement`);
  lines.push('');
  const waCo = useStore.getState().companyInfo;
  lines.push('Merci pour votre commande ! 🙏');
  lines.push(`*${waCo.name}* — ${waCo.slogan}`);
  lines.push(`📞 ${waCo.phone}`);

  return lines.join('\n');
}

// Formater un numéro pour WhatsApp — format Gabon (+241)
export function formatGabonPhone(phone: string): string {
  // Nettoyer : garder uniquement les chiffres
  let clean = phone.replace(/[^\d]/g, '');
  if (!clean) return '';

  // Si commence par 241 suivi de 0 (ex: 24107123456) → retirer le 0
  if (clean.startsWith('2410') && clean.length >= 11) {
    clean = '241' + clean.substring(4);
  }

  // Si commence déjà par 241 et a la bonne longueur → OK
  if (clean.startsWith('241') && clean.length >= 10) {
    return clean;
  }

  // Si commence par 00241 (format international avec 00)
  if (clean.startsWith('00241')) {
    clean = clean.substring(2); // retirer les 00
    if (clean.startsWith('2410')) clean = '241' + clean.substring(4);
    return clean;
  }

  // Si commence par 0 (numéro local : 07xxxxxxx) → remplacer 0 par 241
  if (clean.startsWith('0')) {
    return '241' + clean.substring(1);
  }

  // Numéro court sans indicatif (ex: 7123456 ou 74123456)
  if (clean.length <= 9) {
    return '241' + clean;
  }

  return clean;
}

export function openWhatsAppOrder(order: Order, phoneNumber?: string): void {
  const msg = buildWhatsAppOrderMessage(order);
  const encoded = encodeURIComponent(msg);
  const phone = phoneNumber ? formatGabonPhone(phoneNumber) : '';
  const url = phone
    ? `https://api.whatsapp.com/send?phone=${phone}&text=${encoded}`
    : `https://api.whatsapp.com/send?text=${encoded}`;
  window.open(url, '_blank');
}

// Ouvrir WhatsApp pour envoyer à un numéro spécifique avec un message
export function openWhatsAppDirect(phone: string, message: string): void {
  const ph = formatGabonPhone(phone);
  const encoded = encodeURIComponent(message);
  window.open(`https://api.whatsapp.com/send?phone=${ph}&text=${encoded}`, '_blank');
}
