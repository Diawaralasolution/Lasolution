import React, { useEffect, useState } from 'react';
import { useStore, Page } from './store/useStore';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CategorySection } from './components/CategorySection';
import { FeaturedProducts } from './components/FeaturedProducts';
import { PromoBanner } from './components/PromoBanner';
import { TestimonialsSection } from './components/TestimonialsSection';
import { CatalogPage } from './components/CatalogPage';
import { ProductPage } from './components/ProductPage';
import { CheckoutPage } from './components/CheckoutPage';
import { AccountPage } from './components/AccountPage';
import { OrdersPage } from './components/OrdersPage';
import { AdminPage } from './components/AdminPage';
import { DocumentsPage } from './components/DocumentsPage';
import { TechniciansPage } from './components/TechniciansPage';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { Notification } from './components/Notification';
import { FirebaseSync } from './components/FirebaseSync';
import { PWAInstallBanner } from './components/PWAInstall';
import { MobileBottomNav } from './components/MobileBottomNav';
// firebase imported in FirebaseSync

const HomePage: React.FC = () => (
  <>
    <HeroSection />
    <CategorySection />
    <FeaturedProducts />
    <PromoBanner />
    <TestimonialsSection />
  </>
);

const App: React.FC = () => {
  const { currentPage, darkMode, isLoggedIn, isAdmin, companyInfo } = useStore();

  // Splash screen — until company name is set (from Firebase or localStorage)
  const [ready, setReady] = useState(() => {
    const co = useStore.getState().companyInfo;
    return !!co.name; // Ready if name exists
  });

  useEffect(() => {
    if (ready) return;
    // Check every 200ms if companyInfo has been loaded
    const check = setInterval(() => {
      const co = useStore.getState().companyInfo;
      if (co.name) {
        setReady(true);
        clearInterval(check);
      }
    }, 200);
    // Timeout court pour éviter un écran d'attente long au premier chargement
    const timeout = setTimeout(() => { setReady(true); }, 1200);
    return () => { clearInterval(check); clearTimeout(timeout); };
  }, [ready]);

  // Dynamic page title
  useEffect(() => {
    const name = companyInfo.name || '';
    const slogan = companyInfo.slogan || '';
    document.title = name ? `${name}${slogan ? ' - ' + slogan : ''}` : 'Chargement...';
  }, [companyInfo.name, companyInfo.slogan]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  // Splash screen
  if (!ready) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary via-primary-dark to-[#0c1f33] flex items-center justify-center">
        <div className="text-center animate-fadeIn px-6">
          <div className="w-24 h-24 bg-gradient-to-br from-secondary to-orange-600 rounded-2xl mx-auto mb-5 shadow-2xl flex items-center justify-center">
            <span className="text-white font-black text-4xl">D</span>
          </div>
          <h1 className="text-white text-2xl font-black mb-1">ETS DIAWARA LA SOLUTION</h1>
          <p className="text-gray-400 text-sm mb-6">Chargement de votre boutique...</p>
          <div className="w-8 h-8 border-3 border-white border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  // Protected pages
  const protectedPages: Page[] = ['account', 'orders', 'documents', 'admin'];
  const needsLogin = protectedPages.includes(currentPage) && !isLoggedIn;
  const page = needsLogin ? 'account' as Page
    : (currentPage === 'admin' && !isAdmin()) ? 'home' as Page
    : currentPage;

  const renderPage = () => {
    switch (page) {
      case 'home': return <HomePage />;
      case 'catalog': return <CatalogPage />;
      case 'product': return <ProductPage />;
      case 'checkout': return <CheckoutPage />;
      case 'account': return <AccountPage />;
      case 'orders': return <OrdersPage />;
      case 'admin': return <AdminPage />;
      case 'documents': return <DocumentsPage />;
      case 'technicians': return <TechniciansPage />;
      default: return <HomePage />;
    }
  };

  const showFooter = !['admin', 'checkout'].includes(page);

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'} transition-colors duration-300`}>
      {page !== 'admin' && <Header />}
      <main className="pb-[140px] md:pb-0">{renderPage()}</main>
      {showFooter && <Footer />}
      <div className="h-[140px] md:hidden" aria-hidden="true" />
      <MobileBottomNav />
      <CartDrawer />
      <WhatsAppButton />
      <Notification />
      <FirebaseSync />
      <PWAInstallBanner />
    </div>
  );
};

export default App;
