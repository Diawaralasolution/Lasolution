import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useStore } from '../store/useStore';

export const CategorySection: React.FC = () => {
  const { setPage, setSelectedCategory, darkMode, customCategories: categories } = useStore();

  return (
    <section className={`py-4 md:py-8 ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-3 md:mb-6">
          <h2 className={`text-base md:text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'} mb-1 md:mb-2`}>
            Nos <span className="text-secondary">Catégories</span>
          </h2>
          <p className={`text-xs md:text-base ${darkMode ? 'text-gray-400' : 'text-gray-600'} max-w-2xl mx-auto hidden md:block`}>
            Parcourez notre large sélection de matériaux et équipements pour tous vos projets de construction
          </p>
        </div>

        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-7 gap-2 md:gap-3 stagger-children">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                setPage('catalog');
              }}
              className={`group relative overflow-hidden rounded-2xl ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'} border shadow-[0_8px_24px_rgba(15,45,82,0.07)] hover:shadow-[0_14px_32px_rgba(15,45,82,0.12)] transition-all duration-300 hover:-translate-y-0.5 h-full`}
              style={cat.background ? (cat.background.startsWith('#') || cat.background.startsWith('linear') || cat.background.startsWith('radial') ? { background: cat.background } : { background: `url(${cat.background}) center/cover` }) : {}}
            >
              <div className="relative h-[74px] md:h-[110px] overflow-hidden bg-gradient-to-br from-orange-50 to-blue-50">
                {cat.background && !cat.background.startsWith('#') && !cat.background.startsWith('linear') ? null : (
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                )}
                {!cat.background && <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />}
                <div className={`absolute inset-0 bg-gradient-to-t ${cat.color} opacity-60`} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-3xl md:text-4xl">{cat.icon}</span>
                </div>
              </div>
              <div className="p-2 md:p-3 text-center">
                <h3 className={`font-semibold text-[11px] md:text-base leading-tight ${darkMode ? 'text-white' : 'text-gray-900'}`}>{cat.name}</h3>
              </div>
            </button>
          ))}
        </div>

        <div className="text-center mt-4 md:mt-6">
          <button
            onClick={() => setPage('catalog')}
            className="inline-flex items-center gap-2 text-secondary hover:text-secondary-dark font-semibold transition-colors"
          >
            Voir toutes les catégories
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
};
