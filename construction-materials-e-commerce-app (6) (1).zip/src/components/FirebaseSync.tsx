import { useEffect, useRef, useState } from 'react';
import { useStore } from '../store/useStore';
import { isConfigured, listenToCollection, syncToFirestore, saveDocToFirestore, onAuthChange, setupNetworkHandlers } from '../lib/firebase';
import { products as baseProducts } from '../data/products';

export const FirebaseSync: React.FC = () => {
  const {
    orders, clients, documents, cashRecords, stockProducts, userAccounts,
    companyInfo, customCategories, customSubcategories, productReviews, technicians, technicianReviews, appointments, login, isAdmin
  } = useStore();

  const listenersRef = useRef<(() => void)[]>([]);
  const initialized = useRef(false);
  const writeTimerRef = useRef<any>(null);
  const [loading, setLoading] = useState(true);
  const lastWrittenRef = useRef<Record<string, string>>({});
  const settingsLoadedRef = useRef(false);

  // ===== LISTENERS TEMPS RÉEL =====
  useEffect(() => {
    if (!isConfigured() || initialized.current) return;
    initialized.current = true;
    setLoading(true);
    let loadCount = 0;
    const total = 11;
    const onLoaded = () => { loadCount++; if (loadCount >= total) { setLoading(false); console.log('✅ Firebase sync OK'); } };

    const unsubs: (() => void)[] = [];

    // Collections
    [
      { name: 'orders' as const, key: 'orders' },
      { name: 'clients' as const, key: 'clients' },
      { name: 'cashRecords' as const, key: 'cashRecords' },
      { name: 'documents' as const, key: 'documents' },
      { name: 'products' as const, key: 'stockProducts' },
      { name: 'users' as const, key: 'userAccounts' },
      { name: 'reviews' as const, key: 'productReviews' },
      { name: 'technicians' as const, key: 'technicians' },
      { name: 'technicianReviews' as const, key: 'technicianReviews' },
      { name: 'appointments' as const, key: 'appointments' },
    ].forEach(({ name, key }) => {
      unsubs.push(listenToCollection(name, (data) => {
        lastWrittenRef.current[name] = JSON.stringify(data);
        // Si la collection produits Firebase est vide au premier déploiement,
        // conserver le catalogue local pour l'envoyer ensuite vers Firebase.
        if (name === 'products' && data.length === 0 && useStore.getState().stockProducts.length > 0) {
          onLoaded();
          return;
        }
        // Produits : ne jamais écraser les produits ajoutés localement mais pas encore présents dans Firebase.
        // On fusionne par nom pour éviter les conflits d'ID après changement du catalogue de base.
        if (name === 'products') {
          const localProducts = useStore.getState().stockProducts;
          const baseNames = new Set(baseProducts.map(p => p.name.trim().toLowerCase()));
          const remoteNames = new Set(data.map((p: any) => String(p.name || '').trim().toLowerCase()));
          const remoteIds = new Set(data.map((p: any) => Number(p.id)));
          let maxId = Math.max(0, ...data.map((p: any) => Number(p.id) || 0), ...baseProducts.map(p => p.id));
          const unsyncedLocal = localProducts
            .filter((p: any) => {
              const n = String(p.name || '').trim().toLowerCase();
              return n && !remoteNames.has(n) && !baseNames.has(n);
            })
            .map((p: any) => {
              const id = remoteIds.has(Number(p.id)) ? ++maxId : p.id;
              remoteIds.add(Number(id));
              return { ...p, id };
            });
          useStore.setState({ stockProducts: [...data, ...unsyncedLocal] });
          onLoaded();
          return;
        }
        useStore.setState({ [key]: data } as any);
        onLoaded();
      }));
    });

    // Settings — TOUJOURS écraser les valeurs locales par Firebase
    unsubs.push(listenToCollection('settings', (data) => {
      const doc = data.find((d: any) => d._docId === 'main' || d.id === 'main');
      if (doc) {
        settingsLoadedRef.current = true;
        const rawJson = JSON.stringify(doc);
        lastWrittenRef.current['settings'] = rawJson;

        // Écraser companyInfo ENTIÈREMENT par Firebase (pas merger avec les defaults)
        if (doc.companyInfo) {
          useStore.setState({ companyInfo: doc.companyInfo });
        }
        if (doc.customCategories && doc.customCategories.length > 0) {
          useStore.setState({ customCategories: doc.customCategories });
        }
        if (doc.customSubcategories && doc.customSubcategories.length > 0) {
          useStore.setState({ customSubcategories: doc.customSubcategories });
        }
      }
      onLoaded();
    }));

    unsubs.push(onAuthChange((user) => {
      if (user) login(user.displayName || user.email || 'Utilisateur', user.email || '', '');
    }));

    listenersRef.current = unsubs;
    setupNetworkHandlers();
    const timeout = setTimeout(() => setLoading(false), 3000);
    return () => { listenersRef.current.forEach(u => u()); clearTimeout(timeout); };
  }, []);

  // ===== ÉCRIRE VERS FIREBASE =====
  useEffect(() => {
    if (!isConfigured() || !initialized.current) return;

    if (writeTimerRef.current) clearTimeout(writeTimerRef.current);
    writeTimerRef.current = setTimeout(() => {
      const syncIfChanged = (name: string, data: any[]) => {
        const json = JSON.stringify(data);
        if (lastWrittenRef.current[name] === json) return;
        lastWrittenRef.current[name] = json;
        syncToFirestore(name as any, data);
      };

      syncIfChanged('orders', orders);
      syncIfChanged('clients', clients);
      syncIfChanged('cashRecords', cashRecords);
      syncIfChanged('documents', documents);
      syncIfChanged('products', stockProducts);
      syncIfChanged('users', userAccounts);
      syncIfChanged('reviews', productReviews);
      syncIfChanged('technicians', technicians);
      syncIfChanged('technicianReviews', technicianReviews);
      syncIfChanged('appointments', appointments);

      // Settings — SEULEMENT si admin ET settings ont été chargés depuis Firebase
      // Empêche un client de réécrire les valeurs par défaut
      if (isAdmin() && settingsLoadedRef.current) {
        const settingsData = { id: 'main', companyInfo, customCategories, customSubcategories };
        const settingsJson = JSON.stringify(settingsData);
        if (lastWrittenRef.current['settings'] !== settingsJson) {
          lastWrittenRef.current['settings'] = settingsJson;
          saveDocToFirestore('settings', 'main', settingsData);
        }
      }

      // Premier save des settings si rien n'existe encore dans Firebase
      if (isAdmin() && !settingsLoadedRef.current) {
        saveDocToFirestore('settings', 'main', { id: 'main', companyInfo, customCategories, customSubcategories });
        settingsLoadedRef.current = true;
      }
    }, 2500);

    return () => { if (writeTimerRef.current) clearTimeout(writeTimerRef.current); };
  }, [orders, clients, cashRecords, documents, stockProducts, userAccounts, productReviews, technicians, technicianReviews, appointments, companyInfo, customCategories, customSubcategories]);

  if (loading && isConfigured()) {
    return (
      <div className="fixed bottom-4 left-4 z-50 bg-blue-500 text-white px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg animate-pulse">
        <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
        Synchronisation...
      </div>
    );
  }

  return null;
};
