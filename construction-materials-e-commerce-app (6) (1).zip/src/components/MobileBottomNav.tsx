import React from 'react';
import { Home, Grid3X3, Flame, User, PackageCheck, Wrench } from 'lucide-react';
import { useStore, Page } from '../store/useStore';

export const MobileBottomNav: React.FC = () => {
  const { currentPage, selectedCategory, setPage, setSelectedCategory, darkMode } = useStore();

  const items: { label: string; page: Page; icon: React.ReactNode; action?: () => void }[] = [
    { label: 'Accueil', page: 'home', icon: <Home size={20} /> },
    { label: 'Catégories', page: 'catalog', icon: <Grid3X3 size={20} />, action: () => setSelectedCategory('all') },
    { label: 'Promos', page: 'catalog', icon: <Flame size={20} />, action: () => setSelectedCategory('promo') },
    { label: 'Technicien', page: 'technicians', icon: <Wrench size={20} /> },
    { label: 'Compte', page: 'account', icon: <User size={20} /> },
    { label: 'Commandes', page: 'orders', icon: <PackageCheck size={20} /> },
  ];

  return (
    <nav className={`md:hidden fixed bottom-0 left-0 right-0 z-50 ${darkMode ? 'bg-gray-900/95 border-gray-800' : 'bg-white/95 border-gray-100'} backdrop-blur-xl border-t shadow-[0_-10px_30px_rgba(15,45,82,0.08)] pb-[env(safe-area-inset-bottom)]`}>
      <div className="grid grid-cols-6 px-1 py-2">
        {items.map((item) => {
          const active = item.label === 'Promos'
            ? currentPage === 'catalog' && selectedCategory === 'promo'
            : item.label === 'Catégories'
              ? currentPage === 'catalog' && selectedCategory !== 'promo'
              : currentPage === item.page;
          return (
            <button
              key={item.label}
              onClick={() => { item.action?.(); setPage(item.page); }}
              className={`flex flex-col items-center justify-center gap-1 py-1.5 rounded-2xl text-[9px] font-semibold transition-all ${active ? 'text-secondary bg-orange-50' : darkMode ? 'text-gray-400' : 'text-gray-500'}`}
            >
              {item.icon}
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
};