import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useStore } from '../store/useStore';
import { ProductCard } from './ProductCard';

export const FeaturedProducts: React.FC = () => {
  const { setPage, darkMode, stockProducts } = useStore();
  const featured = stockProducts.filter(p => p.featured).slice(0, 8);

  return (
    <section className={`py-16 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className={`text-3xl md:text-4xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
              Produits <span className="text-secondary">Vedettes</span>
            </h2>
            <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Les meilleurs produits sélectionnés pour vous
            </p>
          </div>
          <button
            onClick={() => setPage('catalog')}
            className="hidden md:flex items-center gap-2 text-secondary hover:text-secondary-dark font-semibold transition-colors"
          >
            Voir tout
            <ArrowRight size={18} />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 stagger-children">
          {featured.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-8 md:hidden">
          <button
            onClick={() => setPage('catalog')}
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-dark text-white px-6 py-3 rounded-xl font-semibold transition-colors"
          >
            Voir tous les produits
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
};
