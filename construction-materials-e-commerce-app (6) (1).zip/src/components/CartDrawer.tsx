import React from 'react';
import { X, Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useStore } from '../store/useStore';

export const CartDrawer: React.FC = () => {
  const { showCart, setShowCart, cart, removeFromCart, updateQuantity, getCartTotal, setPage, darkMode } = useStore();

  if (!showCart) return null;

  const fmt = (n: number) => n.toLocaleString('fr-FR') + ' FCFA';
  const total = getCartTotal();

  return (
    <div className="fixed inset-0 z-[60]">
      <div className="absolute inset-0 bg-black/50" onClick={() => setShowCart(false)} />

      <div className={`absolute right-0 top-0 bottom-0 w-full max-w-md ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-2xl animate-slideInRight flex flex-col`}>
        {/* Header */}
        <div className={`p-4 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'} flex items-center justify-between shrink-0`}>
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-secondary" />
            <h2 className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Panier ({cart.length})</h2>
          </div>
          <button onClick={() => setShowCart(false)} className={`p-2 rounded-lg ${darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}>
            <X size={20} />
          </button>
        </div>

        {/* Empty state */}
        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="text-5xl mb-3">🛒</div>
            <h3 className={`font-bold mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Panier vide</h3>
            <p className={`text-sm mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Ajoutez des produits</p>
            <button onClick={() => { setShowCart(false); setPage('catalog'); }} className="bg-secondary text-white px-5 py-2 rounded-xl text-sm font-medium">
              Voir le catalogue
            </button>
          </div>
        ) : (
          <>
            {/* Items — simple list */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.map((item) => (
                <div key={item.product.id} className={`p-3 rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <div className="flex gap-3">
                    <img src={item.product.images[0]} alt={item.product.name} className="w-16 h-16 object-cover rounded-lg shrink-0" />
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-sm font-medium line-clamp-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{item.product.name}</h4>
                      <p className="text-secondary font-bold text-sm mt-1">{fmt(item.product.price)}</p>
                    </div>
                    <button onClick={() => removeFromCart(item.product.id)} className="text-red-400 hover:text-red-500 p-1 self-start shrink-0">
                      <Trash2 size={16} />
                    </button>
                  </div>
                  {/* Quantity row */}
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-dashed border-gray-200 dark:border-gray-600">
                    <div className={`flex items-center rounded-lg overflow-hidden border ${darkMode ? 'border-gray-600 bg-gray-600' : 'border-gray-200 bg-white'}`}>
                      <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className={`px-2.5 py-1 ${darkMode ? 'hover:bg-gray-500 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
                        <Minus size={14} />
                      </button>
                      <input
                        type="number"
                        min={1}
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.product.id, Math.max(1, Number(e.target.value) || 1))}
                        className={`w-12 py-1 text-sm font-bold text-center outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${darkMode ? 'bg-gray-600 text-white' : 'bg-white text-gray-900'}`}
                      />
                      <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className={`px-2.5 py-1 ${darkMode ? 'hover:bg-gray-500 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}>
                        <Plus size={14} />
                      </button>
                    </div>
                    <span className={`font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer — clean total */}
            <div className={`p-4 border-t ${darkMode ? 'border-gray-700' : 'border-gray-100'} shrink-0 space-y-3`}>
              <div className={`flex justify-between items-center text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                <span>Total</span>
                <span className="text-secondary text-xl">{fmt(total)}</span>
              </div>
              <p className={`text-xs ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                Transport et TVA calculés à l'étape suivante
              </p>
              <button
                onClick={() => { setShowCart(false); setPage('checkout'); }}
                className="w-full bg-secondary hover:bg-secondary-dark text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all hover:scale-[1.02] shadow-lg shadow-secondary/25"
              >
                Commander
                <ArrowRight size={18} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
