import React, { useState } from 'react';
import { Download, RefreshCw, Trash2, Edit, Search, ShoppingCart, Check } from 'lucide-react';
import { useStore, DocumentRecord } from '../store/useStore';
import { generateInvoiceFromOrder } from '../utils/pdfGenerator';
import { PageHeader } from './PageHeader';

export const DocumentsPage: React.FC = () => {
  const { documents, orders, updateDocument, deleteDocument, setCart, setPage, darkMode: dm, isAdmin, user } = useStore();
  const admin = isAdmin();
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'facture' | 'proforma' | 'devis'>('all');
  const [editingDoc, setEditingDoc] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ clientName: '', clientPhone: '', clientAddress: '' });

  const fmt = (n: number) => n.toLocaleString('fr-FR') + ' FCFA';

  const allDocs: DocumentRecord[] = [
    ...documents,
    // Also show orders as facture records if not already in documents
    ...orders
      .filter(o => !documents.find(d => d.orderId === o.id && d.type === 'facture'))
      .map(o => ({
        id: 'FAC-' + o.id,
        type: 'facture' as const,
        orderId: o.id,
        date: o.date,
        clientName: o.clientName,
        clientPhone: o.phone,
        clientEmail: o.clientEmail,
        clientAddress: o.address,
        items: o.items,
        subtotal: o.items.reduce((s, i) => s + i.product.price * i.quantity, 0),
        shipping: o.shipping,
        shippingZone: o.shippingZone,
        tvaRate: o.tvaRate,
        tvaAmount: o.tvaAmount,
        total: o.total,
        paymentMethod: o.paymentMethod,
        status: 'sent' as const,
      })),
  ];

  const visibleDocs = admin
    ? allDocs
    : [
        ...documents.filter(d => user && (d.clientEmail === user.email || d.clientPhone === user.phone) && (d.type === 'proforma' || d.type === 'devis')),
        ...orders
          .filter(o => user && (o.clientEmail === user.email || o.phone === user.phone))
          .flatMap(o => (['proforma', 'devis'] as const).map(type => ({
            id: `${type === 'proforma' ? 'PRO' : 'DEV'}-${o.id}`,
            type,
            orderId: o.id,
            date: o.date,
            clientName: o.clientName,
            clientPhone: o.phone,
            clientEmail: o.clientEmail,
            clientAddress: o.address,
            items: o.items,
            subtotal: o.items.reduce((s, i) => s + i.product.price * i.quantity, 0),
            shipping: o.shipping,
            shippingZone: o.shippingZone,
            tvaRate: o.tvaRate,
            tvaAmount: o.tvaAmount,
            total: o.total,
            paymentMethod: o.paymentMethod,
            status: 'sent' as const,
          })))
      ];

  const filtered = visibleDocs
    .filter(d => filterType === 'all' || d.type === filterType)
    .filter(d => {
      if (!search) return true;
      const q = search.toLowerCase();
      return d.clientName.toLowerCase().includes(q) || d.id.toLowerCase().includes(q) || d.clientPhone.includes(q);
    })
    .sort((a, b) => b.id.localeCompare(a.id));

  const typeLabel = (t: string) => t === 'facture' ? 'Facture' : t === 'proforma' ? 'Proforma' : 'Devis';
  const typeBg = (t: string) => t === 'facture' ? 'bg-green-100 text-green-700' : t === 'proforma' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700';
  const typeBtn = (t: string) => t === 'facture' ? 'bg-green-500 hover:bg-green-600' : t === 'proforma' ? 'bg-blue-500 hover:bg-blue-600' : 'bg-purple-500 hover:bg-purple-600';

  const handleConvertToFacture = (doc: DocumentRecord) => {
    // Generate a facture PDF from the document data
    const fakeOrder = {
      id: 'FAC-' + Date.now().toString(36).toUpperCase(),
      items: doc.items,
      total: doc.total,
      shipping: doc.shipping,
      shippingZone: doc.shippingZone,
      tvaRate: doc.tvaRate,
      tvaAmount: doc.tvaAmount,
      status: 'pending' as const,
      date: new Date().toLocaleDateString('fr-FR'),
      paymentMethod: doc.paymentMethod || '',
      address: doc.clientAddress,
      phone: doc.clientPhone,
      clientName: doc.clientName,
      clientEmail: doc.clientEmail,
    };
    generateInvoiceFromOrder(fakeOrder, 'facture');
    // Mark original as converted
    if (documents.find(d => d.id === doc.id)) {
      updateDocument(doc.id, { status: 'converted', convertedTo: fakeOrder.id });
    }
  };

  const handleReloadToCart = (doc: DocumentRecord) => {
    setCart(doc.items.map(i => ({ product: i.product, quantity: i.quantity })));
    setPage('checkout');
  };

  const handleRedownload = (doc: DocumentRecord) => {
    const fakeOrder = {
      id: doc.id.replace(/^(FAC|PRO|DEV)-/, ''),
      items: doc.items,
      total: doc.total,
      shipping: doc.shipping,
      shippingZone: doc.shippingZone,
      tvaRate: doc.tvaRate,
      tvaAmount: doc.tvaAmount,
      status: 'pending' as const,
      date: doc.date,
      paymentMethod: doc.paymentMethod,
      address: doc.clientAddress,
      phone: doc.clientPhone,
      clientName: doc.clientName,
      clientEmail: doc.clientEmail,
    };
    generateInvoiceFromOrder(fakeOrder, doc.type);
  };

  const startEdit = (doc: DocumentRecord) => {
    setEditingDoc(doc.id);
    setEditForm({ clientName: doc.clientName, clientPhone: doc.clientPhone, clientAddress: doc.clientAddress });
  };

  const saveEdit = (docId: string) => {
    updateDocument(docId, editForm);
    setEditingDoc(null);
  };

  return (
    <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`${dm ? 'bg-gray-800' : 'bg-primary'} py-5 px-4`}>
        <div className="max-w-4xl mx-auto">
          <PageHeader title="Historique des Documents" subtitle={`${visibleDocs.length} document(s) — Proforma et Devis`} dark />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Filters */}
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4 mb-5`}>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher par nom, N°, tél..."
                className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'} focus:border-secondary focus:outline-none`} />
            </div>
            <div className="flex gap-1.5 overflow-x-auto">
              {(['all', 'facture', 'proforma', 'devis'] as const).map(t => (
                <button key={t} onClick={() => setFilterType(t)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${filterType === t
                    ? 'bg-secondary text-white'
                    : dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                  }`}>
                  {t === 'all' ? 'Tous' : typeLabel(t)}
                  <span className="ml-1 opacity-70">({t === 'all' ? visibleDocs.length : visibleDocs.filter(d => d.type === t).length})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Documents List */}
        {filtered.length === 0 ? (
          <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-10 text-center`}>
            <div className="text-5xl mb-3">📄</div>
            <h3 className={`font-bold mb-1 ${dm ? 'text-white' : 'text-gray-900'}`}>Aucun document</h3>
            <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Les documents générés apparaîtront ici</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(doc => {
              const isEditing = editingDoc === doc.id;
              const isFromStore = !!documents.find(d => d.id === doc.id);

              return (
                <div key={doc.id} className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md overflow-hidden`}>
                  {/* Top row */}
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${typeBg(doc.type)}`}>{typeLabel(doc.type)}</span>
                          {doc.status === 'converted' && <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-100 text-amber-700">Converti</span>}
                          {doc.orderId && <span className={`text-[10px] ${dm ? 'text-gray-500' : 'text-gray-400'}`}>Cmd: {doc.orderId}</span>}
                        </div>
                        <h3 className={`font-bold text-sm mt-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{doc.id}</h3>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{doc.date}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-secondary font-bold text-sm">{fmt(doc.total)}</div>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{doc.items.length} article(s)</p>
                      </div>
                    </div>

                    {/* Client info — editable */}
                    {isEditing ? (
                      <div className={`space-y-2 p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <input value={editForm.clientName} onChange={e => setEditForm({ ...editForm, clientName: e.target.value })} placeholder="Nom"
                          className={`w-full px-3 py-1.5 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <input value={editForm.clientPhone} onChange={e => setEditForm({ ...editForm, clientPhone: e.target.value })} placeholder="Téléphone"
                          className={`w-full px-3 py-1.5 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <input value={editForm.clientAddress} onChange={e => setEditForm({ ...editForm, clientAddress: e.target.value })} placeholder="Adresse"
                          className={`w-full px-3 py-1.5 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <div className="flex gap-2">
                          <button onClick={() => saveEdit(doc.id)} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-medium"><Check size={12} /> Enregistrer</button>
                          <button onClick={() => setEditingDoc(null)} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${dm ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600'}`}>Annuler</button>
                        </div>
                      </div>
                    ) : (
                      <div className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
                        <span className="font-medium">{doc.clientName}</span> · {doc.clientPhone} · {doc.clientAddress}
                      </div>
                    )}

                    {/* Items preview */}
                    <div className={`mt-2 text-xs space-y-0.5 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>
                      {doc.items.slice(0, 3).map((item, i) => (
                        <div key={i}>{item.quantity}× {item.product.name} — {fmt(item.product.price * item.quantity)}</div>
                      ))}
                      {doc.items.length > 3 && <div className="italic">+{doc.items.length - 3} autre(s)...</div>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className={`p-3 border-t ${dm ? 'border-gray-700 bg-gray-800/50' : 'border-gray-100 bg-gray-50'}`}>
                    <div className={`grid ${admin ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2'} gap-2`}>

                      {/* Client: Proforma + Devis only */}
                      {!admin && (
                        <>
                          {(doc.type === 'proforma' || doc.type === 'devis') && (
                            <button onClick={() => handleRedownload(doc)}
                              className={`flex items-center justify-center gap-1 py-2 rounded-lg text-white text-xs font-semibold ${typeBtn(doc.type)}`}>
                              <Download size={12} /> {typeLabel(doc.type)}
                            </button>
                          )}
                          {doc.type === 'facture' && (
                            <>
                              <button onClick={() => { const d2 = { ...doc, type: 'proforma' as const }; handleRedownload(d2); }}
                                className="flex items-center justify-center gap-1 py-2 rounded-lg text-white text-xs font-semibold bg-blue-500 hover:bg-blue-600">
                                <Download size={12} /> Proforma
                              </button>
                              <button onClick={() => { const d2 = { ...doc, type: 'devis' as const }; handleRedownload(d2); }}
                                className="flex items-center justify-center gap-1 py-2 rounded-lg text-white text-xs font-semibold bg-purple-500 hover:bg-purple-600">
                                <Download size={12} /> Devis
                              </button>
                            </>
                          )}
                        </>
                      )}

                      {/* Admin: all buttons */}
                      {admin && (
                        <>
                          <button onClick={() => handleRedownload(doc)}
                            className={`flex items-center justify-center gap-1 py-2 rounded-lg text-white text-xs font-semibold ${typeBtn(doc.type)}`}>
                            <Download size={12} /> {typeLabel(doc.type)}
                          </button>

                          {doc.type !== 'facture' && doc.status !== 'converted' && (
                            <button onClick={() => handleConvertToFacture(doc)}
                              className="flex items-center justify-center gap-1 py-2 rounded-lg bg-green-500 hover:bg-green-600 text-white text-xs font-semibold">
                              <RefreshCw size={12} /> → Facture
                            </button>
                          )}

                          <button onClick={() => handleReloadToCart(doc)}
                            className={`flex items-center justify-center gap-1 py-2 rounded-lg text-xs font-semibold ${dm ? 'bg-gray-700 text-gray-200 hover:bg-gray-600' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                            <ShoppingCart size={12} /> Reprendre
                          </button>

                          {isFromStore && (
                            <button onClick={() => startEdit(doc)}
                              className={`flex items-center justify-center gap-1 py-2 rounded-lg text-xs font-semibold ${dm ? 'bg-gray-700 text-gray-200 hover:bg-gray-600' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                              <Edit size={12} /> Modifier
                            </button>
                          )}

                          {isFromStore && (
                            <button onClick={() => deleteDocument(doc.id)}
                              className="flex items-center justify-center gap-1 py-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 text-xs font-semibold">
                              <Trash2 size={12} /> Supprimer
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
