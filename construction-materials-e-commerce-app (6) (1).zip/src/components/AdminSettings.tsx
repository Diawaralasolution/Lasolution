import React, { useState, useRef, useEffect } from 'react';
import { Save, X, Camera, MapPin, Building2, Phone, FileText, Shield, CreditCard, Share2, Database, CheckCircle, AlertCircle } from 'lucide-react';
import { useStore, CompanyInfo, FirebaseConfig } from '../store/useStore';
import { isConfigured as isFirebaseReady, reinitFirebase, uploadLogo, uploadHeroImage } from '../lib/firebase';

export const AdminSettings: React.FC = () => {
  const { companyInfo, updateCompanyInfo, firebaseConfig, updateFirebaseConfig, darkMode: dm } = useStore();
  const [form, setForm] = useState<CompanyInfo>({ ...companyInfo });
  const [fbForm, setFbForm] = useState<FirebaseConfig>({ ...firebaseConfig });
  const [hasChanges, setHasChanges] = useState(false);
  const [activeSection, setActiveSection] = useState('general');
  const [logoPreview, setLogoPreview] = useState(companyInfo.logo);
  const logoRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setForm({ ...companyInfo });
    setLogoPreview(companyInfo.logo);
  }, [companyInfo]);

  const update = (key: keyof CompanyInfo, value: string) => {
    setForm(f => ({ ...f, [key]: value }));
    setHasChanges(true);
  };

  const [uploading, setUploading] = useState(false);

  const handleLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Preview immédiat
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      setLogoPreview(dataUrl);

      // Upload to Firebase Storage
      if (isFirebaseReady()) {
        setUploading(true);
        try {
          const url = await uploadLogo(file);
          setLogoPreview(url);
          setForm(f => ({ ...f, logo: url }));
        } catch {
          setForm(f => ({ ...f, logo: dataUrl }));
        }
        setUploading(false);
      } else {
        setForm(f => ({ ...f, logo: dataUrl }));
      }
      setHasChanges(true);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    updateCompanyInfo(form);
    setHasChanges(false);
  };

  const handleCancel = () => {
    setForm({ ...companyInfo });
    setLogoPreview(companyInfo.logo);
    setHasChanges(false);
  };

  const heroImgRef = useRef<HTMLInputElement>(null);
  const handleHeroImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      update('heroImage', dataUrl); // Preview immédiat
      if (isFirebaseReady()) {
        setUploading(true);
        try {
          const url = await uploadHeroImage(file);
          update('heroImage', url);
        } catch { /* keep base64 */ }
        setUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const sections = [
    { id: 'hero', label: 'En-tête', icon: <Building2 size={16} /> },
    { id: 'general', label: 'Général', icon: <Building2 size={16} /> },
    { id: 'contact', label: 'Contact', icon: <Phone size={16} /> },
    { id: 'payment', label: 'Paiement', icon: <CreditCard size={16} /> },
    { id: 'social', label: 'Réseaux', icon: <Share2 size={16} /> },
    { id: 'legal', label: 'Juridique', icon: <FileText size={16} /> },
    { id: 'location', label: 'Localisation', icon: <MapPin size={16} /> },
    { id: 'firebase', label: 'Cloud', icon: <Database size={16} /> },
  ];

  type StringKeys = { [K in keyof CompanyInfo]: CompanyInfo[K] extends string ? K : never }[keyof CompanyInfo];
  const Field = ({ label, keyName, placeholder, type = 'text', rows }: { label: string; keyName: StringKeys; placeholder?: string; type?: string; rows?: number }) => (
    <div>
      <label className={`block text-sm font-medium mb-1.5 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>{label}</label>
      {rows ? (
        <textarea value={form[keyName] as string} onChange={e => update(keyName, e.target.value)} placeholder={placeholder} rows={rows}
          className={`w-full px-4 py-2.5 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
      ) : (
        <input type={type} value={form[keyName] as string} onChange={e => update(keyName, e.target.value)} placeholder={placeholder}
          className={`w-full px-4 py-2.5 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
      )}
    </div>
  );

  // Payment methods CRUD
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [editPaymentId, setEditPaymentId] = useState<string | null>(null);
  const [pmForm, setPmForm] = useState({ name: '', icon: '💵', desc: '', online: false });

  const methods = form.customPaymentMethods || [];

  const handleTogglePayment = (id: string) => {
    const updated = methods.map(m => m.id === id ? { ...m, enabled: !m.enabled } : m);
    setForm(f => ({ ...f, customPaymentMethods: updated }));
    setHasChanges(true);
  };
  const handleDeletePayment = (id: string) => {
    setForm(f => ({ ...f, customPaymentMethods: methods.filter(m => m.id !== id) }));
    setHasChanges(true);
  };
  const handleAddPayment = () => {
    if (!pmForm.name) return;
    const newM = { id: 'pm-' + Date.now().toString(36), name: pmForm.name, icon: pmForm.icon, desc: pmForm.desc, online: pmForm.online, enabled: true };
    setForm(f => ({ ...f, customPaymentMethods: [...methods, newM] }));
    setPmForm({ name: '', icon: '💵', desc: '', online: false });
    setShowAddPayment(false);
    setHasChanges(true);
  };
  const handleSaveEditPayment = () => {
    if (!editPaymentId || !pmForm.name) return;
    const updated = methods.map(m => m.id === editPaymentId ? { ...m, name: pmForm.name, icon: pmForm.icon, desc: pmForm.desc, online: pmForm.online } : m);
    setForm(f => ({ ...f, customPaymentMethods: updated }));
    setEditPaymentId(null);
    setPmForm({ name: '', icon: '💵', desc: '', online: false });
    setHasChanges(true);
  };
  const startEditPayment = (m: any) => {
    setEditPaymentId(m.id);
    setPmForm({ name: m.name, icon: m.icon, desc: m.desc, online: m.online });
  };

  return (
    <div className="animate-fadeIn">
      {/* Save Bar */}
      {hasChanges && (
        <div className={`sticky top-0 z-10 ${dm ? 'bg-gray-700' : 'bg-amber-50'} border ${dm ? 'border-gray-600' : 'border-amber-200'} rounded-2xl p-3 mb-5 flex items-center justify-between gap-3`}>
          <p className={`text-sm font-medium ${dm ? 'text-amber-300' : 'text-amber-800'}`}>
            {uploading ? '📤 Upload en cours...' : '⚠️ Modifications non enregistrées'}
          </p>
          <div className="flex gap-2">
            <button onClick={handleCancel} className={`px-4 py-2 rounded-xl text-sm font-medium ${dm ? 'bg-gray-600 text-gray-300' : 'bg-white text-gray-700 border border-gray-200'}`}>
              <X size={14} className="inline mr-1" /> Annuler
            </button>
            <button onClick={handleSave} className="px-4 py-2 rounded-xl text-sm font-semibold bg-green-500 hover:bg-green-600 text-white flex items-center gap-1.5">
              <Save size={14} /> Enregistrer
            </button>
          </div>
        </div>
      )}

      {/* Section Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-3 mb-5">
        {sections.map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeSection === s.id ? 'bg-secondary text-white' : dm ? 'bg-gray-800 text-gray-400 hover:bg-gray-700' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
            }`}>
            {s.icon} {s.label}
          </button>
        ))}
      </div>

      {/* ===== EN-TÊTE / HERO ===== */}
      {activeSection === 'hero' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>🖼️ En-tête de la Page d'Accueil</h3>
          <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Personnalisez la bannière principale que vos clients voient en arrivant sur le site.</p>

          {/* Titres principaux */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-blue-50'} border ${dm ? 'border-gray-600' : 'border-blue-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-blue-300' : 'text-blue-800'}`}>📝 Titres de la bannière</p>
            <div className="space-y-3">
              <Field label="Ligne 1 (texte blanc)" keyName="heroTitle1" placeholder="Vos Matériaux de" />
              <Field label="Ligne 2 (texte orange)" keyName="heroTitle2" placeholder="Construction" />
              <Field label="Ligne 3 (texte bleu)" keyName="heroTitle3" placeholder="en Ligne" />
            </div>
          </div>

          {/* Badge & Description */}
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Badge en haut (petit texte vert)" keyName="heroBadge" placeholder="Livraison disponible partout" />
            <Field label="Texte barre supérieure" keyName="topBarText" placeholder="Livraison gratuite dès 150 000 FCFA" />
          </div>
          <Field label="Description sous le titre" keyName="description" placeholder="Votre marketplace de confiance..." rows={2} />

          {/* Boutons */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-orange-50'} border ${dm ? 'border-gray-600' : 'border-orange-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-orange-300' : 'text-orange-800'}`}>🔘 Boutons d'action</p>
            <div className="grid md:grid-cols-2 gap-3">
              <Field label="Bouton principal (orange)" keyName="heroBtnText1" placeholder="Voir le Catalogue" />
              <Field label="Bouton secondaire" keyName="heroBtnText2" placeholder="Nos Promotions 🔥" />
            </div>
          </div>

          {/* Statistiques */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-green-50'} border ${dm ? 'border-gray-600' : 'border-green-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-green-300' : 'text-green-800'}`}>📊 Statistiques affichées</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <Field label="Stat 1 — Valeur" keyName="heroStat1Value" placeholder="5000+" />
              <Field label="Stat 1 — Libellé" keyName="heroStat1Label" placeholder="Produits" />
              <Field label="Stat 2 — Valeur" keyName="heroStat2Value" placeholder="2500+" />
              <Field label="Stat 2 — Libellé" keyName="heroStat2Label" placeholder="Clients" />
              <Field label="Stat 3 — Valeur" keyName="heroStat3Value" placeholder="98%" />
              <Field label="Stat 3 — Libellé" keyName="heroStat3Label" placeholder="Satisfaction" />
            </div>
          </div>

          {/* Image Hero */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-purple-50'} border ${dm ? 'border-gray-600' : 'border-purple-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-purple-300' : 'text-purple-800'}`}>🖼️ Image de la bannière</p>
            <div className="flex items-center gap-4">
              <div onClick={() => heroImgRef.current?.click()}
                className={`w-24 h-24 rounded-xl border-2 border-dashed flex items-center justify-center cursor-pointer overflow-hidden ${form.heroImage ? 'border-green-400' : dm ? 'border-gray-500 hover:border-secondary' : 'border-gray-300 hover:border-secondary'}`}>
                {form.heroImage ? (
                  <img src={form.heroImage} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className={`text-3xl ${dm ? 'text-gray-500' : 'text-gray-400'}`}>📷</span>
                )}
              </div>
              <div>
                <button onClick={() => heroImgRef.current?.click()} className="text-sm text-secondary font-medium">Choisir une image</button>
                <p className={`text-xs mt-0.5 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>PNG, JPG — image carrée recommandée</p>
                {form.heroImage && <button onClick={() => update('heroImage', '')} className="text-xs text-red-500 mt-1">Supprimer l'image</button>}
              </div>
              <input ref={heroImgRef} type="file" accept="image/*" className="hidden" onChange={handleHeroImageChange} />
            </div>
          </div>

          {/* Badges flottants */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-amber-50'} border ${dm ? 'border-gray-600' : 'border-amber-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-amber-300' : 'text-amber-800'}`}>🏷️ Badges flottants sur l'image</p>
            <div className="grid md:grid-cols-2 gap-3">
              <Field label="Badge promo — texte" keyName="heroPromoText" placeholder="Jusqu'à" />
              <Field label="Badge promo — pourcentage" keyName="heroPromoPercent" placeholder="-30%" />
              <Field label="Badge qualité — titre" keyName="heroQualityText" placeholder="Qualité Garantie" />
              <Field label="Badge qualité — sous-titre" keyName="heroQualitySub" placeholder="Produits certifiés" />
            </div>
          </div>

          {/* Trust badges */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-cyan-50'} border ${dm ? 'border-gray-600' : 'border-cyan-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-cyan-300' : 'text-cyan-800'}`}>✅ Badges de confiance (sous la bannière)</p>
            <div className="grid md:grid-cols-2 gap-3">
              <Field label="Badge 1 — Titre" keyName="trustBadge1Title" placeholder="Livraison Rapide" />
              <Field label="Badge 1 — Description" keyName="trustBadge1Desc" placeholder="Partout au pays" />
              <Field label="Badge 2 — Titre" keyName="trustBadge2Title" placeholder="Paiement Sécurisé" />
              <Field label="Badge 2 — Description" keyName="trustBadge2Desc" placeholder="Mobile Money & Carte" />
              <Field label="Badge 3 — Titre" keyName="trustBadge3Title" placeholder="Prix Compétitifs" />
              <Field label="Badge 3 — Description" keyName="trustBadge3Desc" placeholder="Meilleurs prix garantis" />
              <Field label="Badge 4 — Titre" keyName="trustBadge4Title" placeholder="Support 24/7" />
              <Field label="Badge 4 — Description" keyName="trustBadge4Desc" placeholder="Assistance permanente" />
            </div>
          </div>
        </div>
      )}

      {/* ===== GENERAL ===== */}
      {activeSection === 'general' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><Building2 size={18} className="inline mr-2 text-secondary" /> Informations Générales</h3>

          {/* Logo */}
          <div>
            <label className={`block text-sm font-medium mb-2 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Logo de l'entreprise</label>
            <div className="flex items-center gap-4">
              <div onClick={() => logoRef.current?.click()}
                className={`w-20 h-20 rounded-2xl border-2 border-dashed flex items-center justify-center cursor-pointer overflow-hidden transition-colors ${
                  logoPreview ? 'border-green-400' : dm ? 'border-gray-600 hover:border-secondary' : 'border-gray-300 hover:border-secondary'
                }`}>
                {logoPreview ? (
                  <img src={logoPreview} alt="Logo" className="w-full h-full object-contain" />
                ) : (
                  <Camera size={24} className={dm ? 'text-gray-500' : 'text-gray-400'} />
                )}
              </div>
              <div>
                <button onClick={() => logoRef.current?.click()} className="text-sm text-secondary font-medium hover:text-secondary-dark">Choisir une image</button>
                <p className={`text-xs mt-0.5 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>PNG, JPG. Max 2 Mo</p>
              </div>
              <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Nom de l'entreprise" keyName="name" placeholder="BatiMarket" />
            <Field label="Slogan" keyName="slogan" placeholder="Matériaux & Quincaillerie" />
          </div>
          <Field label="Description" keyName="description" placeholder="Description de votre entreprise..." rows={3} />
          <Field label="Horaires d'ouverture" keyName="hours" placeholder="Lun - Sam: 7h00 - 19h00" />
        </div>
      )}

      {/* ===== CONTACT ===== */}
      {activeSection === 'contact' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><Phone size={18} className="inline mr-2 text-secondary" /> Contact</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Téléphone" keyName="phone" placeholder="+225 07 00 00 00 00" type="tel" />
            <Field label="WhatsApp (numéro international sans +)" keyName="whatsapp" placeholder="2250700000000" />
            <Field label="Email" keyName="email" placeholder="contact@batimarket.ci" type="email" />
            <Field label="Site Web" keyName="website" placeholder="www.batimarket.ci" />
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            <Field label="Adresse" keyName="address" placeholder="Cocody Riviera" />
            <Field label="Ville" keyName="city" placeholder="Abidjan" />
            <Field label="Pays" keyName="country" placeholder="Côte d'Ivoire" />
          </div>
        </div>
      )}

      {/* ===== PAYMENT ===== */}
      {activeSection === 'payment' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><CreditCard size={18} className="inline mr-2 text-secondary" /> Moyens de Paiement</h3>

          {/* Payment Methods List */}
          <div className="space-y-2">
            {methods.map(m => (
              <div key={m.id} className={`flex items-center gap-3 p-3 rounded-xl border ${m.enabled ? 'border-green-300 bg-green-50/50' : dm ? 'border-gray-600 bg-gray-700' : 'border-gray-200'} ${dm && m.enabled ? 'border-green-700 bg-green-900/20' : ''}`}>
                {editPaymentId === m.id ? (
                  /* Edit mode */
                  <div className="flex-1 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input value={pmForm.icon} onChange={e => setPmForm({ ...pmForm, icon: e.target.value })} placeholder="Icône (emoji)"
                        className={`px-3 py-2 rounded-lg border text-sm text-center ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      <input value={pmForm.name} onChange={e => setPmForm({ ...pmForm, name: e.target.value })} placeholder="Nom"
                        className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                    </div>
                    <input value={pmForm.desc} onChange={e => setPmForm({ ...pmForm, desc: e.target.value })} placeholder="Description"
                      className={`w-full px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                    <div className="flex items-center justify-between">
                      <label className="flex items-center gap-2 text-sm">
                        <input type="checkbox" checked={pmForm.online} onChange={e => setPmForm({ ...pmForm, online: e.target.checked })} className="accent-secondary" />
                        <span className={dm ? 'text-gray-300' : 'text-gray-600'}>Paiement en ligne</span>
                      </label>
                      <div className="flex gap-2">
                        <button onClick={handleSaveEditPayment} className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-semibold">✓ OK</button>
                        <button onClick={() => setEditPaymentId(null)} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${dm ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600'}`}>Annuler</button>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Display mode */
                  <>
                    <span className="text-2xl shrink-0">{m.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className={`font-semibold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{m.name}</div>
                      <div className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{m.desc} {m.online && '· 🌐 En ligne'}</div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {/* Toggle */}
                      <button onClick={() => handleTogglePayment(m.id)} title={m.enabled ? 'Désactiver' : 'Activer'}
                        className={`w-10 h-6 rounded-full transition-colors relative ${m.enabled ? 'bg-green-500' : dm ? 'bg-gray-600' : 'bg-gray-300'}`}>
                        <div className={`w-4.5 h-4.5 bg-white rounded-full absolute top-[3px] transition-transform shadow ${m.enabled ? 'translate-x-[18px]' : 'translate-x-[3px]'}`} style={{ width: 18, height: 18 }} />
                      </button>
                      {/* Edit */}
                      <button onClick={() => startEditPayment(m)} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-600 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`} title="Modifier">✏️</button>
                      {/* Delete */}
                      <button onClick={() => handleDeletePayment(m.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-500" title="Supprimer">🗑️</button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>

          {/* Add new payment method */}
          {showAddPayment ? (
            <div className={`p-4 rounded-xl border-2 border-dashed ${dm ? 'border-secondary/50 bg-gray-700' : 'border-secondary/30 bg-orange-50/50'}`}>
              <p className={`text-sm font-semibold mb-3 ${dm ? 'text-white' : 'text-gray-900'}`}>➕ Nouveau moyen de paiement</p>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <input value={pmForm.icon} onChange={e => setPmForm({ ...pmForm, icon: e.target.value })} placeholder="Icône (emoji ex: 💵)"
                  className={`px-3 py-2 rounded-lg border text-sm text-center ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                <input value={pmForm.name} onChange={e => setPmForm({ ...pmForm, name: e.target.value })} placeholder="Nom du mode"
                  className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
              </div>
              <input value={pmForm.desc} onChange={e => setPmForm({ ...pmForm, desc: e.target.value })} placeholder="Description courte"
                className={`w-full px-3 py-2 rounded-lg border text-sm mb-2 ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={pmForm.online} onChange={e => setPmForm({ ...pmForm, online: e.target.checked })} className="accent-secondary" />
                  <span className={dm ? 'text-gray-300' : 'text-gray-600'}>Paiement en ligne (CinetPay)</span>
                </label>
                <div className="flex gap-2">
                  <button onClick={handleAddPayment} disabled={!pmForm.name} className="px-4 py-2 rounded-lg bg-green-500 hover:bg-green-600 disabled:bg-gray-300 text-white text-xs font-semibold">Ajouter</button>
                  <button onClick={() => { setShowAddPayment(false); setPmForm({ name: '', icon: '💵', desc: '', online: false }); }} className={`px-4 py-2 rounded-lg text-xs font-medium ${dm ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-600'}`}>Annuler</button>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={() => { setPmForm({ name: '', icon: '💵', desc: '', online: false }); setShowAddPayment(true); }}
              className={`w-full py-3 rounded-xl border-2 border-dashed text-sm font-semibold flex items-center justify-center gap-2 ${dm ? 'border-gray-600 text-gray-400 hover:border-secondary hover:text-secondary' : 'border-gray-300 text-gray-500 hover:border-secondary hover:text-secondary'}`}>
              ➕ Ajouter un moyen de paiement
            </button>
          )}

          {/* Bank details */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-blue-50'} border ${dm ? 'border-gray-600' : 'border-blue-200'}`}>
            <p className={`text-sm font-semibold mb-3 ${dm ? 'text-blue-300' : 'text-blue-800'}`}>🏦 Coordonnées bancaires</p>
            <div className="grid md:grid-cols-2 gap-3">
              <Field label="Banque" keyName="bankName" placeholder="BGFI Bank" />
              <Field label="N° Compte / IBAN" keyName="bankAccount" placeholder="GA00 1234 5678 9012" />
              <Field label="Code BIC/SWIFT" keyName="bankBic" placeholder="BGFIGABL" />
              <Field label="N° Mobile Money" keyName="mobileMoney" placeholder="+241 00 00 00 00" />
            </div>
          </div>
        </div>
      )}

      {/* ===== SOCIAL ===== */}
      {activeSection === 'social' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><Share2 size={18} className="inline mr-2 text-secondary" /> Réseaux Sociaux</h3>
          <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Collez les liens complets de vos pages</p>
          <div className="space-y-4">
            <Field label="📘 Facebook" keyName="facebook" placeholder="https://facebook.com/votrepage" />
            <Field label="📸 Instagram" keyName="instagram" placeholder="https://instagram.com/votrepage" />
            <Field label="🎵 TikTok" keyName="tiktok" placeholder="https://tiktok.com/@votrepage" />
            <Field label="💼 LinkedIn" keyName="linkedin" placeholder="https://linkedin.com/company/votrepage" />
            <Field label="🐦 X (Twitter)" keyName="twitter" placeholder="https://x.com/votrepage" />
          </div>
        </div>
      )}

      {/* ===== LEGAL ===== */}
      {activeSection === 'legal' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><Shield size={18} className="inline mr-2 text-secondary" /> Informations Juridiques</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <Field label="RCCM" keyName="rccm" placeholder="CI-ABJ-2024-B-12345" />
            <Field label="N° Contribuable" keyName="ncc" placeholder="2412345Z" />
            <Field label="Capital Social" keyName="capital" placeholder="10 000 000 FCFA" />
          </div>
          <Field label="Conditions Facture" keyName="conditionsFacture" rows={4} placeholder="Conditions pour factures..." />
          <Field label="Conditions Proforma" keyName="conditionsProforma" rows={4} placeholder="Conditions pour proforma..." />
          <Field label="Conditions Devis" keyName="conditionsDevis" rows={4} placeholder="Conditions pour devis..." />
          <Field label="Politique de Confidentialité" keyName="privacy" rows={6} placeholder="Votre politique de confidentialité..." />
        </div>
      )}

      {/* ===== LOCATION ===== */}
      {activeSection === 'location' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><MapPin size={18} className="inline mr-2 text-secondary" /> Localisation & Carte</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Latitude GPS" keyName="gpsLat" placeholder="5.3600" />
            <Field label="Longitude GPS" keyName="gpsLng" placeholder="-4.0083" />
          </div>
          {form.gpsLat && form.gpsLng && (
            <div className="rounded-xl overflow-hidden border border-gray-200">
              <iframe
                title="Carte Google Maps"
                src={`https://maps.google.com/maps?q=${form.gpsLat},${form.gpsLng}&z=15&output=embed`}
                width="100%" height="300" style={{ border: 0 }} loading="lazy" allowFullScreen
              />
            </div>
          )}
          <a href={`https://www.google.com/maps?q=${form.gpsLat},${form.gpsLng}`} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-sm text-secondary font-medium hover:text-secondary-dark">
            <MapPin size={14} /> Voir sur Google Maps →
          </a>
        </div>
      )}

      {/* ===== FIREBASE / CLOUD ===== */}
      {activeSection === 'firebase' && (
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 space-y-5`}>
          <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><Database size={18} className="inline mr-2 text-secondary" /> Configuration Cloud (Firebase)</h3>

          {/* Status */}
          <div className={`p-4 rounded-xl flex items-center gap-3 ${isFirebaseReady() ? 'bg-green-50 border border-green-200' : dm ? 'bg-gray-700' : 'bg-amber-50 border border-amber-200'}`}>
            {isFirebaseReady() ? (
              <><CheckCircle size={20} className="text-green-500" /><div><p className="text-green-800 font-semibold text-sm">Firebase connecté ✅</p><p className="text-green-600 text-xs">Les données sont synchronisées dans le cloud</p></div></>
            ) : (
              <><AlertCircle size={20} className="text-amber-500" /><div><p className={`font-semibold text-sm ${dm ? 'text-amber-300' : 'text-amber-800'}`}>Firebase non configuré</p><p className={`text-xs ${dm ? 'text-gray-400' : 'text-amber-600'}`}>Les données sont sauvegardées uniquement sur cet appareil</p></div></>
            )}
          </div>

          {/* Guide */}
          <div className={`p-4 rounded-xl ${dm ? 'bg-gray-700' : 'bg-blue-50'} border ${dm ? 'border-gray-600' : 'border-blue-200'}`}>
            <p className={`text-sm font-semibold mb-2 ${dm ? 'text-blue-300' : 'text-blue-800'}`}>📖 Comment obtenir ces clés (gratuit) :</p>
            <ol className={`text-xs space-y-1 list-decimal list-inside ${dm ? 'text-gray-300' : 'text-blue-700'}`}>
              <li>Allez sur <a href="https://console.firebase.google.com" target="_blank" rel="noopener noreferrer" className="underline font-medium">console.firebase.google.com</a></li>
              <li>Cliquez "Créer un projet" → donnez un nom → Continuer</li>
              <li>Allez dans <strong>Authentication</strong> → Activer <strong>Email/Password</strong></li>
              <li>Allez dans <strong>Firestore Database</strong> → Créer → <strong>Mode test</strong></li>
              <li>Allez dans ⚙️ <strong>Paramètres</strong> → Vos applications → <strong>Web (&lt;/&gt;)</strong></li>
              <li>Donnez un nom → Copiez les valeurs ci-dessous</li>
            </ol>
          </div>

          {/* Config Fields */}
          <div className="space-y-3">
            {[
              { key: 'apiKey' as keyof FirebaseConfig, label: 'API Key', ph: 'AIzaSyB...' },
              { key: 'authDomain' as keyof FirebaseConfig, label: 'Auth Domain', ph: 'mon-projet.firebaseapp.com' },
              { key: 'projectId' as keyof FirebaseConfig, label: 'Project ID', ph: 'mon-projet' },
              { key: 'storageBucket' as keyof FirebaseConfig, label: 'Storage Bucket', ph: 'mon-projet.appspot.com' },
              { key: 'messagingSenderId' as keyof FirebaseConfig, label: 'Messaging Sender ID', ph: '123456789' },
              { key: 'appId' as keyof FirebaseConfig, label: 'App ID', ph: '1:123456789:web:abc123def456' },
            ].map(f => (
              <div key={f.key}>
                <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>{f.label}</label>
                <input value={fbForm[f.key]} onChange={e => setFbForm(prev => ({ ...prev, [f.key]: e.target.value }))} placeholder={f.ph}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm font-mono ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
            ))}
          </div>

          <button
            onClick={() => {
              updateFirebaseConfig(fbForm);
              reinitFirebase();
              setTimeout(() => window.location.reload(), 500);
            }}
            disabled={!fbForm.apiKey || !fbForm.projectId}
            className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-300 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
            <Save size={16} /> Enregistrer et connecter Firebase
          </button>

          {isFirebaseReady() && (
            <button onClick={() => { updateFirebaseConfig({ apiKey: '', authDomain: '', projectId: '', storageBucket: '', messagingSenderId: '', appId: '' }); setTimeout(() => window.location.reload(), 500); }}
              className={`w-full py-2.5 rounded-xl font-medium text-sm ${dm ? 'bg-gray-700 text-red-400 hover:bg-gray-600' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}>
              Déconnecter Firebase
            </button>
          )}
        </div>
      )}

      {/* Bottom Save */}
      {hasChanges && (
        <div className="flex gap-3 mt-6">
          <button onClick={handleCancel} className={`px-6 py-3 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>
            Annuler
          </button>
          <button onClick={handleSave} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
            <Save size={18} /> Enregistrer toutes les modifications
          </button>
        </div>
      )}
    </div>
  );
};
