import React, { useState, useRef } from 'react';
import { BarChart3, Package, Users, ShoppingCart, TrendingUp, DollarSign, ArrowUp, Edit, Trash2, Search, Plus, Home, ArrowLeft, Download, Save, AlertTriangle, X, Check, Camera, Image as ImageIcon } from 'lucide-react';
import { useStore, Client } from '../store/useStore';
// categories from store
import { generateInvoiceFromOrder, openWhatsAppOrder, generateFromCart, formatGabonPhone, openWhatsAppDirect } from '../utils/pdfGenerator';
import { AdminSettings } from './AdminSettings';
import { uploadProductImage, isConfigured as fbReady, saveDocToFirestore } from '../lib/firebase';

export const AdminPage: React.FC = () => {
  const { orders, darkMode, setPage, stockProducts, updateStock, updateProductPrice, updateProductImage, updateProductField, addProduct, deleteProduct, clients, addClient, updateClient, deleteClient, updateOrderStatus, updateOrder, deleteOrder, cashRecords, addCashRecord, deleteCashRecord, userAccounts, updateUserAccount, deleteUserAccount, customCategories: categories, addCategory, updateCategory, deleteCategory, customSubcategories, addSubcategory, updateSubcategory, deleteSubcategory, productReviews, deleteProductReview, technicians, addTechnician, updateTechnician, deleteTechnician, technicianReviews, deleteTechnicianReview, appointments, updateAppointment } = useStore();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'products' | 'orders' | 'customers' | 'cash' | 'settings' | 'users' | 'categories' | 'promos' | 'reviews' | 'technicians'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  // Stock editing
  const [editingStock, setEditingStock] = useState<number | null>(null);
  const [editStockVal, setEditStockVal] = useState('');
  const [editingPrice, setEditingPrice] = useState<number | null>(null);
  const [editPriceVal, setEditPriceVal] = useState('');
  // Client modal
  const [showClientModal, setShowClientModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [clientForm, setClientForm] = useState({ name: '', phone: '', email: '', address: '', city: '' });
  // Product modal
  const [showProductModal, setShowProductModal] = useState(false);
  const [productForm, setProductForm] = useState({ name: '', price: '', stock: '', category: 'construction', subcategory: '', description: '' });
  const [productImagePreview, setProductImagePreview] = useState<string | null>(null);
  const [pendingProductFile, setPendingProductFile] = useState<File | null>(null);
  const productFileRef = useRef<HTMLInputElement>(null);
  const productCameraRef = useRef<HTMLInputElement>(null);
  // Image change for existing product
  const imageChangeRef = useRef<HTMLInputElement>(null);
  const [changingImageFor, setChangingImageFor] = useState<number | null>(null);
  // Product edit
  const [editProductId, setEditProductId] = useState<number | null>(null);
  const [editProductForm, setEditProductForm] = useState<any>(null);
  const [showTechModal, setShowTechModal] = useState(false);
  const [editingTechId, setEditingTechId] = useState<string | null>(null);
  const [techForm, setTechForm] = useState({ name: '', trade: 'Électricien', city: 'Port-Gentil', zone: '', experience: '1', phone: '', whatsapp: '', photo: '', description: '', specialties: '', hours: 'Lun-Sam 8h-18h' });
  const techPhotoRef = useRef<HTMLInputElement>(null);
  // Order editing
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [orderEditForm, setOrderEditForm] = useState<any>(null);

  const openOrderEdit = (orderId: string) => {
    // Chercher par id ou _docId (Firebase peut ajouter _docId)
    const order = orders.find(o => o.id === orderId || (o as any)._docId === orderId);
    if (!order) {
      console.warn('Commande non trouvée:', orderId);
      useStore.getState().setNotification({ message: 'Commande introuvable', type: 'error' });
      return;
    }
    try {
      // Clone sécurisé des items — gérer les images trop grosses
      const clonedItems = order.items.map((item: any) => ({
        product: {
          id: item.product?.id || 0,
          name: item.product?.name || 'Produit',
          price: item.product?.price || 0,
          images: item.product?.images || ['/images/ciment.jpg'],
          category: item.product?.category || '',
          subcategory: item.product?.subcategory || '',
          description: item.product?.description || '',
          stock: item.product?.stock || 0,
          rating: item.product?.rating || 0,
          reviews: item.product?.reviews || 0,
          featured: item.product?.featured || false,
        },
        quantity: item.quantity || 1,
      }));
      setOrderEditForm({
        items: clonedItems,
        shipping: order.shipping || 0,
        shippingZone: order.shippingZone || '',
        tvaRate: order.tvaRate || 0,
        tvaAmount: order.tvaAmount || 0,
        discountType: order.discountType || 'amount',
        discountValue: order.discountValue || 0,
        discountAmount: order.discountAmount || 0,
        depositType: order.depositType || 'amount',
        depositValue: order.depositValue || 0,
        depositAmount: order.depositAmount || 0,
        address: order.address || '',
        clientName: order.clientName || '',
        phone: order.phone || '',
      });
      setEditingOrderId(orderId);
    } catch (e) {
      console.warn('Erreur ouverture modification:', e);
      useStore.getState().setNotification({ message: 'Erreur lors de l\'ouverture', type: 'error' });
    }
  };

  const saveOrderEdit = () => {
    if (!editingOrderId || !orderEditForm) return;
    const sub = orderEditForm.items.reduce((s: number, i: any) => s + (i.product?.price || 0) * (i.quantity || 1), 0);
    updateOrder(editingOrderId, {
      items: orderEditForm.items,
      shipping: orderEditForm.shipping || 0,
      shippingZone: orderEditForm.shippingZone || '',
      tvaRate: orderEditForm.tvaRate || 0,
      tvaAmount: orderEditForm.tvaAmount || 0,
      discountType: orderEditForm.discountType || 'amount',
      discountValue: orderEditForm.discountValue || 0,
      discountAmount: orderEditForm.discountAmount || 0,
      depositType: orderEditForm.depositType || 'amount',
      depositValue: orderEditForm.depositValue || 0,
      depositAmount: orderEditForm.depositAmount || 0,
      address: orderEditForm.address || '',
      clientName: orderEditForm.clientName || '',
      phone: orderEditForm.phone || '',
      total: Math.max(0, sub - (orderEditForm.discountAmount || 0) + (orderEditForm.shipping || 0) + (orderEditForm.tvaAmount || 0)),
    });
    setEditingOrderId(null);
    setOrderEditForm(null);
    useStore.getState().setNotification({ message: '✅ Commande modifiée', type: 'success' });
  };

  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const fmt = (n: number) => n.toLocaleString('fr-FR') + ' FCFA';
  const lowStockProducts = stockProducts.filter(p => p.stock <= 10);

  const filteredProducts = stockProducts.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSaveStock = (pid: number) => {
    updateStock(pid, parseInt(editStockVal) || 0);
    setEditingStock(null);
  };
  const handleSavePrice = (pid: number) => {
    updateProductPrice(pid, parseInt(editPriceVal) || 0);
    setEditingPrice(null);
  };

  const [uploadingImage, setUploadingImage] = useState(false);

  // Image file → base64 (fallback local)
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  };

  // Upload to Firebase Storage si disponible, sinon base64
  const uploadImage = async (file: File, productId?: number): Promise<string> => {
    if (fbReady() && productId) {
      setUploadingImage(true);
      try {
        const url = await uploadProductImage(productId, file);
        setUploadingImage(false);
        return url;
      } catch {
        setUploadingImage(false);
      }
    }
    return fileToBase64(file);
  };

  const handleProductImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Preview en base64 immédiat
    const dataUrl = await fileToBase64(file);
    setProductImagePreview(dataUrl);
    setPendingProductFile(file);
  };

  const handleExistingProductImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !changingImageFor) return;
    setUploadingImage(true);
    const url = await uploadImage(file, changingImageFor);
    updateProductImage(changingImageFor, url);
    setChangingImageFor(null);
    setUploadingImage(false);
  };

  const handleAddProduct = async () => {
    if (!productForm.name.trim()) { useStore.getState().setNotification({ message: 'Nom du produit obligatoire', type: 'error' }); return; }
    if (!productForm.price || Number(productForm.price) <= 0) { useStore.getState().setNotification({ message: 'Prix invalide', type: 'error' }); return; }
    const newId = Math.max(0, ...stockProducts.map(p => p.id)) + 1;
    setUploadingImage(true);

    const timeout = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Échec de l\'upload, veuillez réessayer.')), 30000);
    });

    try {
      console.log('Produit: début enregistrement');
      let imageUrl = productImagePreview || '/images/ciment.jpg';

      if (pendingProductFile) {
        console.log('Produit: compression/upload image');
        imageUrl = await Promise.race([
          uploadProductImage(newId, pendingProductFile),
          timeout,
        ]);
        if (!imageUrl) throw new Error('Image invalide ou non compressée');
        console.log('Produit: image prête');
      }

      const selectedCategory = categories.find((c: any) => c.id === productForm.category)?.id || categories[0]?.id || 'construction';
      const product = {
        id: newId,
        name: productForm.name.trim(),
        description: productForm.description || productForm.name,
        price: parseInt(productForm.price) || 0,
        category: selectedCategory,
        subcategory: productForm.subcategory || selectedCategory,
        images: [imageUrl],
        stock: parseInt(productForm.stock) || 0,
        rating: 0,
        reviews: 0,
        featured: false,
      };

      if (fbReady()) {
        console.log('Produit: enregistrement Firestore');
        await Promise.race([
          saveDocToFirestore('products', String(newId), product),
          timeout,
        ]);
        console.log('Produit: Firestore OK');
      }

      addProduct(product);
      setShowProductModal(false);
      setProductForm({ name: '', price: '', stock: '', category: categories[0]?.id || 'construction', subcategory: '', description: '' });
      setProductImagePreview(null);
      setPendingProductFile(null);
      useStore.getState().setNotification({ message: '✅ Produit ajouté', type: 'success' });
    } catch (error: any) {
      console.error('Erreur ajout produit:', error);
      useStore.getState().setNotification({ message: error.message || 'Échec de l\'upload, veuillez réessayer.', type: 'error' });
    } finally {
      setUploadingImage(false);
    }
  };

  const openAddTech = () => {
    setEditingTechId(null);
    setTechForm({ name: '', trade: 'Électricien', city: 'Port-Gentil', zone: '', experience: '1', phone: '', whatsapp: '', photo: '', description: '', specialties: '', hours: 'Lun-Sam 8h-18h' });
    setShowTechModal(true);
  };

  const openEditTech = (t: any) => {
    setEditingTechId(t.id);
    setTechForm({ name: t.name, trade: t.trade, city: t.city, zone: t.zone, experience: String(t.experience || 1), phone: t.phone, whatsapp: t.whatsapp, photo: t.photo || '', description: t.description || '', specialties: (t.specialties || []).join(', '), hours: t.hours || '' });
    setShowTechModal(true);
  };

  const saveTech = () => {
    if (!techForm.name || !techForm.phone) return;
    const data = { name: techForm.name, trade: techForm.trade, city: techForm.city, zone: techForm.zone, experience: Number(techForm.experience) || 0, phone: techForm.phone, whatsapp: techForm.whatsapp || techForm.phone, photo: techForm.photo, description: techForm.description, specialties: techForm.specialties.split(',').map(s => s.trim()).filter(Boolean), gallery: [], hours: techForm.hours, status: 'available' as const, active: true, contactCount: 0 };
    if (editingTechId) updateTechnician(editingTechId, data);
    else addTechnician({ id: 'TECH-' + Date.now().toString(36).toUpperCase(), ...data });
    setShowTechModal(false);
  };

  const handleTechPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await fileToBase64(file);
    setTechForm(f => ({ ...f, photo: dataUrl }));
  };

  const openAddClient = () => {
    setEditingClient(null);
    setClientForm({ name: '', phone: '', email: '', address: '', city: 'Abidjan' });
    setShowClientModal(true);
  };
  const openEditClient = (c: Client) => {
    setEditingClient(c);
    setClientForm({ name: c.name, phone: c.phone, email: c.email, address: c.address, city: c.city });
    setShowClientModal(true);
  };
  const handleSaveClient = () => {
    if (!clientForm.name || !clientForm.phone) return;
    if (editingClient) {
      updateClient(editingClient.id, clientForm);
    } else {
      addClient({
        id: 'CLI-' + Date.now().toString(36).toUpperCase(),
        ...clientForm,
        createdAt: new Date().toLocaleDateString('fr-FR'),
        totalSpent: 0,
        orderCount: 0,
      });
    }
    setShowClientModal(false);
  };

  const tabs = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: <BarChart3 size={18} /> },
    { id: 'products' as const, label: 'Stock', icon: <Package size={18} /> },
    { id: 'orders' as const, label: 'Commandes', icon: <ShoppingCart size={18} /> },
    { id: 'customers' as const, label: 'Clients', icon: <Users size={18} /> },
    { id: 'cash' as const, label: 'Caisse', icon: <DollarSign size={18} /> },
    { id: 'categories' as const, label: 'Catégories', icon: <Package size={18} /> },
    { id: 'technicians' as const, label: 'Techniciens', icon: <Users size={18} /> },
    { id: 'reviews' as const, label: 'Avis', icon: <Edit size={18} /> },
    { id: 'promos' as const, label: 'Promos', icon: <ShoppingCart size={18} /> },
    { id: 'users' as const, label: 'Utilisateurs', icon: <Users size={18} /> },
    { id: 'settings' as const, label: 'Mes Infos', icon: <Edit size={18} /> },
  ];

  const dm = darkMode;

  return (
    <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-gray-100'}`}>
      {/* Header */}
      <div className={`${dm ? 'bg-gray-800' : 'bg-primary-dark'} text-white py-4`}>
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => { const h = useStore.getState().pageHistory; if (h.length > 0) useStore.getState().goBack(); else setPage('home'); }}
              className="text-white/70 hover:text-white p-2 rounded-lg hover:bg-white/10" title="Retour"><ArrowLeft size={20} /></button>
            <button onClick={() => setPage('home')}
              className="text-white/70 hover:text-white p-2 rounded-lg hover:bg-white/10" title="Accueil"><Home size={20} /></button>
            <div>
              <h1 className="text-lg font-bold">Administration</h1>
              <p className="text-xs text-white/60">{useStore.getState().companyInfo.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {useStore.getState().newOrderCount > 0 && (
              <button onClick={() => { setActiveTab('orders'); useStore.getState().clearNewOrders(); }}
                className="flex items-center gap-1.5 bg-secondary/20 text-secondary px-3 py-1.5 rounded-lg text-xs font-bold animate-pulse-glow">
                🔔 {useStore.getState().newOrderCount} nouvelle(s) commande(s)
              </button>
            )}
            {lowStockProducts.length > 0 && (
              <button onClick={() => setActiveTab('products')} className="flex items-center gap-1.5 bg-red-500/20 text-red-300 px-3 py-1.5 rounded-lg text-xs font-medium">
                <AlertTriangle size={14} /> {lowStockProducts.length} stock faible
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className={`${dm ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b sticky top-0 z-10`}>
        <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => { setActiveTab(tab.id); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${activeTab === tab.id ? 'border-secondary text-secondary' : `border-transparent ${dm ? 'text-gray-400' : 'text-gray-500'}`}`}>
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">

        {/* ===== DASHBOARD ===== */}
        {activeTab === 'dashboard' && (
          <div className="animate-fadeIn">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { title: 'Chiffre d\'affaires', value: fmt(totalRevenue || 2450000), change: '+12%', icon: <DollarSign size={20} />, color: 'text-green-500 bg-green-100' },
                { title: 'Commandes', value: orders.length || 145, change: '+8%', icon: <ShoppingCart size={20} />, color: 'text-blue-500 bg-blue-100' },
                { title: 'Clients', value: clients.length, change: '+15%', icon: <Users size={20} />, color: 'text-purple-500 bg-purple-100' },
                { title: 'Produits', value: stockProducts.length, change: `${lowStockProducts.length} faible`, icon: <Package size={20} />, color: 'text-orange-500 bg-orange-100' },
              ].map(s => (
                <div key={s.title} className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`p-2 rounded-xl ${s.color}`}>{s.icon}</div>
                    <span className="text-xs font-medium text-green-500 flex items-center gap-0.5"><ArrowUp size={12} />{s.change}</span>
                  </div>
                  <div className={`text-2xl font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{s.value}</div>
                  <div className={`text-sm mt-1 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{s.title}</div>
                </div>
              ))}
            </div>

            {/* Charts */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6`}>
                <h3 className={`font-bold mb-4 ${dm ? 'text-white' : 'text-gray-900'}`}><TrendingUp size={16} className="inline mr-2 text-secondary" />Ventes par mois</h3>
                <div className="flex items-end gap-2 h-44">
                  {['Jan','Fév','Mar','Avr','Mai','Jun','Jul','Aoû'].map((m, i) => (
                    <div key={m} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full bg-gradient-to-t from-secondary to-secondary-light rounded-t-md" style={{ height: `${[65,45,78,55,85,70,92,80][i]}%` }} />
                      <span className={`text-[10px] ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{m}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6`}>
                <h3 className={`font-bold mb-4 ${dm ? 'text-white' : 'text-gray-900'}`}>📊 Par catégorie</h3>
                <div className="space-y-3">
                  {categories.map((c, i) => {
                    const pct = [35,25,18,12,7,3][i] || 5;
                    return (
                      <div key={c.id}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className={dm ? 'text-gray-300' : 'text-gray-600'}>{c.icon} {c.name}</span>
                          <span className={`font-medium ${dm ? 'text-white' : 'text-gray-900'}`}>{pct}%</span>
                        </div>
                        <div className={`h-2 rounded-full ${dm ? 'bg-gray-700' : 'bg-gray-100'}`}>
                          <div className={`h-full rounded-full bg-gradient-to-r ${c.color}`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Low stock alert */}
            {lowStockProducts.length > 0 && (
              <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6 mb-6`}>
                <h3 className={`font-bold mb-4 flex items-center gap-2 ${dm ? 'text-white' : 'text-gray-900'}`}>
                  <AlertTriangle size={18} className="text-red-500" /> Alertes Stock Faible ({lowStockProducts.length})
                </h3>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {lowStockProducts.map(p => (
                    <div key={p.id} className={`p-3 rounded-xl border-l-4 ${p.stock === 0 ? 'border-red-500' : 'border-amber-500'} ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className={`font-medium text-sm line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{p.name}</p>
                      <p className={`text-xs mt-1 font-bold ${p.stock === 0 ? 'text-red-500' : 'text-amber-500'}`}>
                        {p.stock === 0 ? '❌ Rupture' : `⚠️ ${p.stock} restant(s)`}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== STOCK / PRODUCTS ===== */}
        {activeTab === 'products' && (
          <div className="animate-fadeIn">
            <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
              <div className="relative flex-1 max-w-md">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Rechercher..."
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className={`px-3 py-1 rounded-full ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>{stockProducts.length} produits</span>
                {lowStockProducts.length > 0 && <span className="px-3 py-1 rounded-full bg-red-100 text-red-700 font-medium">{lowStockProducts.length} stock faible</span>}
                {uploadingImage && <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 font-medium animate-pulse">📤 Upload en cours...</span>}
                <button onClick={() => { setProductForm({ name: '', price: '', stock: '', category: categories[0]?.id || 'construction', subcategory: '', description: '' }); setProductImagePreview(null); setPendingProductFile(null); setShowProductModal(true); }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-secondary hover:bg-secondary-dark text-white text-xs font-semibold"><Plus size={14} /> Nouveau</button>
              </div>
            </div>

            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md overflow-hidden`}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className={dm ? 'bg-gray-700' : 'bg-gray-50'}>
                     <tr className={dm ? 'text-gray-300' : 'text-gray-600'}>
                      <th className="text-left py-3 px-4 font-medium">Produit</th>
                      <th className="text-left py-3 px-4 font-medium">Prix</th>
                      <th className="text-left py-3 px-4 font-medium">Stock</th>
                      <th className="text-left py-3 px-4 font-medium">Promo / Vedette</th>
                      <th className="text-right py-3 px-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProducts.map(p => (
                      <tr key={p.id} className={`border-t ${dm ? 'border-gray-700' : 'border-gray-100'} ${p.stock <= 10 ? (dm ? 'bg-red-900/10' : 'bg-red-50/50') : ''}`}>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="relative group/img shrink-0">
                              <img src={p.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover" />
                              <button onClick={() => { setChangingImageFor(p.id); imageChangeRef.current?.click(); }}
                                className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity cursor-pointer"
                                title="Changer l'image">
                                <Camera size={14} className="text-white" />
                              </button>
                            </div>
                            <div>
                              <p className={`font-medium line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{p.name}</p>
                              <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{p.subcategory}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          {editingPrice === p.id ? (
                            <div className="flex items-center gap-1">
                              <input value={editPriceVal} onChange={e => setEditPriceVal(e.target.value)} type="number"
                                className={`w-24 px-2 py-1 rounded border text-xs ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-300'}`} autoFocus />
                              <button onClick={() => handleSavePrice(p.id)} className="text-green-500 p-1"><Check size={14} /></button>
                              <button onClick={() => setEditingPrice(null)} className="text-gray-400 p-1"><X size={14} /></button>
                            </div>
                          ) : (
                            <button onClick={() => { setEditingPrice(p.id); setEditPriceVal(String(p.price)); }}
                              className={`font-medium hover:text-secondary ${dm ? 'text-white' : 'text-gray-900'}`}>
                              {fmt(p.price)}
                            </button>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {editingStock === p.id ? (
                            <div className="flex items-center gap-1">
                              <input value={editStockVal} onChange={e => setEditStockVal(e.target.value)} type="number"
                                className={`w-20 px-2 py-1 rounded border text-xs text-center ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-300'}`} autoFocus />
                              <button onClick={() => handleSaveStock(p.id)} className="text-green-500 p-1"><Check size={14} /></button>
                              <button onClick={() => setEditingStock(null)} className="text-gray-400 p-1"><X size={14} /></button>
                            </div>
                          ) : (
                            <button onClick={() => { setEditingStock(p.id); setEditStockVal(String(p.stock)); }}
                              className={`text-xs px-2 py-1 rounded-full font-bold ${
                                p.stock === 0 ? 'bg-red-100 text-red-700' : p.stock <= 10 ? 'bg-amber-100 text-amber-700' : p.stock <= 50 ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                              }`}>
                              {p.stock === 0 ? '0 ❌' : p.stock}
                            </button>
                          )}
                        </td>
                        {/* Promo / Vedette / Badge */}
                        <td className="py-3 px-4">
                          <div className="flex flex-col gap-1.5">
                            {/* Vedette toggle */}
                            <button onClick={() => updateProductField(p.id, { featured: !p.featured })}
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${p.featured ? 'bg-yellow-100 text-yellow-700' : dm ? 'bg-gray-700 text-gray-500' : 'bg-gray-100 text-gray-400'}`}>
                              {p.featured ? '⭐ Vedette' : '☆ Normal'}
                            </button>
                            {/* Badge selector */}
                            <select value={p.badge || ''} onChange={e => updateProductField(p.id, { badge: e.target.value || undefined })}
                              className={`text-[10px] px-1 py-0.5 rounded-lg border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200 text-gray-700'}`}>
                              <option value="">Pas de badge</option>
                              <option value="Promo">🔥 Promo</option>
                              <option value="Nouveau">🆕 Nouveau</option>
                              <option value="Best-seller">🏆 Best-seller</option>
                              <option value="Top vente">📈 Top vente</option>
                              <option value="-10%">-10%</option>
                              <option value="-15%">-15%</option>
                              <option value="-20%">-20%</option>
                              <option value="-25%">-25%</option>
                              <option value="-30%">-30%</option>
                              <option value="-50%">-50%</option>
                            </select>
                            {/* Old price for promo */}
                            {p.badge && (p.badge === 'Promo' || p.badge.startsWith('-')) && (
                              <input type="number" placeholder="Ancien prix" value={p.oldPrice || ''}
                                onChange={e => updateProductField(p.id, { oldPrice: Number(e.target.value) || undefined })}
                                className={`text-[10px] w-20 px-1.5 py-0.5 rounded-lg border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button onClick={() => { setChangingImageFor(p.id); imageChangeRef.current?.click(); }}
                              className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-600 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`} title="Changer l'image">
                              <ImageIcon size={14} />
                            </button>
                            <button onClick={() => { setEditProductId(p.id); setEditProductForm({ name: p.name, price: String(p.price), stock: String(p.stock), category: p.category, subcategory: p.subcategory, description: p.description }); }}
                              className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-600 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`} title="Modifier">
                              <Edit size={14} />
                            </button>
                            <button onClick={() => deleteProduct(p.id)}
                              className="p-1.5 rounded-lg hover:bg-red-50 text-red-500" title="Supprimer">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ===== ORDERS ===== */}
        {activeTab === 'orders' && (
          <div className="animate-fadeIn">
            {orders.length === 0 ? (
              <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-12 text-center`}>
                <div className="text-5xl mb-3">📋</div>
                <h3 className={`font-bold mb-1 ${dm ? 'text-white' : 'text-gray-900'}`}>Aucune commande</h3>
                <p className={dm ? 'text-gray-400' : 'text-gray-500'}>Les commandes apparaîtront ici</p>
              </div>
            ) : (
              <div className="space-y-3">
                {[...orders].reverse().map(order => (
                  <div key={order.id} className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md overflow-hidden`}>
                    {/* Order header */}
                    <div className={`p-4 flex items-center justify-between flex-wrap gap-2 border-b ${dm ? 'border-gray-700' : 'border-gray-100'}`}>
                      <div>
                        <p className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{order.id}</p>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{order.date} · {order.clientName} · {order.phone}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-secondary font-bold">{fmt(order.total)}</span>
                        <select value={order.status} onChange={e => updateOrderStatus(order.id, e.target.value as any)}
                          className={`text-xs px-2 py-1 rounded-lg font-medium border ${order.status === 'pending' ? 'bg-amber-50 text-amber-700 border-amber-200' : order.status === 'confirmed' ? 'bg-blue-50 text-blue-700 border-blue-200' : order.status === 'shipped' ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-green-50 text-green-700 border-green-200'}`}>
                          <option value="pending">En attente</option>
                          <option value="confirmed">Confirmée</option>
                          <option value="shipped">Expédiée</option>
                          <option value="delivered">Livrée</option>
                        </select>
                        {/* Status Stamp selector */}
                        <select value={order.statusStamp || ''} onChange={e => updateOrder(order.id || (order as any)._docId, { statusStamp: e.target.value || undefined })}
                          className={`text-[10px] px-1.5 py-1 rounded-lg font-medium border ${order.statusStamp ? 'bg-green-50 text-green-700 border-green-200' : (dm ? 'bg-gray-700 text-gray-400 border-gray-600' : 'bg-gray-100 text-gray-400 border-gray-200')}`}
                          title="Cachet sur le document">
                          <option value="">Cachet</option>
                          <option value="Payé Livré">✅ Payé Livré</option>
                          <option value="Livré Payé">✅ Livré Payé</option>
                          <option value="Payé Non Livré">⏳ Payé Non Livré</option>
                          <option value="Livré Non Payé">⚠️ Livré Non Payé</option>
                        </select>
                      </div>
                    </div>
                    {/* Items summary */}
                    <div className="p-4 space-y-1">
                      {order.items.map((item, i) => (
                        <div key={i} className={`flex justify-between text-sm ${dm ? 'text-gray-300' : 'text-gray-600'}`}>
                          <span className="truncate mr-2">{item.quantity}× {item.product.name}</span>
                          <span className="shrink-0 font-medium">{fmt(item.product.price * item.quantity)}</span>
                        </div>
                      ))}
                      <div className={`text-xs pt-1 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>
                        📍 {order.address} {order.shippingZone && `· 🚛 ${order.shippingZone}: ${order.shipping === 0 ? 'Gratuit' : fmt(order.shipping)}`}
                      </div>
                    </div>
                    {/* Actions */}
                    <div className={`p-3 border-t ${dm ? 'border-gray-700 bg-gray-800/50' : 'border-gray-100 bg-gray-50'} flex flex-wrap gap-1.5`}>
                      <button onClick={(e) => { e.stopPropagation(); e.preventDefault(); openOrderEdit(order.id || (order as any)._docId); }}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-100 text-amber-700 hover:bg-amber-200 flex items-center gap-1 cursor-pointer" type="button"><Edit size={12} /> Modifier</button>
                      <button onClick={() => generateInvoiceFromOrder(order, 'facture')} className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200"><Download size={11} className="inline mr-0.5" />Facture</button>
                      <button onClick={() => generateInvoiceFromOrder(order, 'proforma')} className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-blue-100 text-blue-700 hover:bg-blue-200"><Download size={11} className="inline mr-0.5" />Pro</button>
                      <button onClick={() => generateInvoiceFromOrder(order, 'devis')} className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-purple-100 text-purple-700 hover:bg-purple-200"><Download size={11} className="inline mr-0.5" />Devis</button>
                      <button onClick={() => openWhatsAppOrder(order, order.phone)} className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-green-100 text-green-700 hover:bg-green-200">📱 WA</button>
                      <button onClick={() => { if (confirm(`Supprimer la commande ${order.id} ?`)) deleteOrder(order.id || (order as any)._docId); }}
                        className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-red-100 text-red-700 hover:bg-red-200">🗑️</button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== ORDER EDIT MODAL ===== */}
            {editingOrderId && orderEditForm && (
              <div className="fixed inset-0 z-[60] flex items-start justify-center p-3 pt-6 overflow-y-auto">
                <div className="fixed inset-0 bg-black/50" onClick={() => { setEditingOrderId(null); setOrderEditForm(null); }} />
                <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl w-full max-w-lg animate-fadeIn my-4`}>
                  <div className={`sticky top-0 z-10 p-4 border-b ${dm ? 'border-gray-700 bg-gray-800' : 'border-gray-100 bg-white'} rounded-t-2xl flex items-center justify-between`}>
                    <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>✏️ Modifier — {editingOrderId}</h3>
                    <button onClick={() => { setEditingOrderId(null); setOrderEditForm(null); }} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
                  </div>
                  <div className="p-4 space-y-4">
                    {/* Client info */}
                    <div className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className={`text-xs font-semibold mb-2 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>👤 Client</p>
                      <div className="grid grid-cols-2 gap-2">
                        <input value={orderEditForm.clientName} onChange={e => setOrderEditForm({ ...orderEditForm, clientName: e.target.value })} placeholder="Nom"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <input value={orderEditForm.phone} onChange={e => setOrderEditForm({ ...orderEditForm, phone: e.target.value })} placeholder="Téléphone"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                    </div>

                    {/* Delivery */}
                    <div className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className={`text-xs font-semibold mb-2 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>📍 Livraison</p>
                      <textarea value={orderEditForm.address} onChange={e => setOrderEditForm({ ...orderEditForm, address: e.target.value })} placeholder="Adresse de livraison" rows={2}
                        className={`w-full px-3 py-2 rounded-lg border text-sm mb-2 ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      <div className="grid grid-cols-2 gap-2">
                        <input value={orderEditForm.shippingZone} onChange={e => setOrderEditForm({ ...orderEditForm, shippingZone: e.target.value })} placeholder="Zone de transport"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <input type="number" value={orderEditForm.shipping} onChange={e => setOrderEditForm({ ...orderEditForm, shipping: Number(e.target.value) })} placeholder="Frais transport"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <input type="number" min={0} max={100} value={orderEditForm.tvaRate}
                          onChange={e => {
                            const rate = Math.max(0, Math.min(100, Number(e.target.value)));
                            const sub = orderEditForm.items.reduce((s: number, i: any) => s + (i.product?.price || 0) * (i.quantity || 1), 0);
                            setOrderEditForm({ ...orderEditForm, tvaRate: rate, tvaAmount: Math.round(sub * rate / 100) });
                          }}
                          placeholder="Taux TVA %"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        <input type="number" value={orderEditForm.tvaAmount}
                          onChange={e => setOrderEditForm({ ...orderEditForm, tvaAmount: Number(e.target.value) || 0 })}
                          placeholder="Montant TVA"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <select value={orderEditForm.discountType || 'amount'} onChange={e => setOrderEditForm({ ...orderEditForm, discountType: e.target.value })}
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`}>
                          <option value="amount">Remise montant</option>
                          <option value="percent">Remise %</option>
                        </select>
                        <input type="number" value={orderEditForm.discountValue || 0}
                          onChange={e => {
                            const value = Number(e.target.value) || 0;
                            const sub = orderEditForm.items.reduce((s: number, i: any) => s + (i.product?.price || 0) * (i.quantity || 1), 0);
                            const amount = orderEditForm.discountType === 'percent' ? Math.round(sub * value / 100) : value;
                            setOrderEditForm({ ...orderEditForm, discountValue: value, discountAmount: Math.max(0, amount) });
                          }}
                          placeholder="Valeur remise"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <select value={orderEditForm.depositType || 'amount'} onChange={e => setOrderEditForm({ ...orderEditForm, depositType: e.target.value })}
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`}>
                          <option value="amount">Acompte montant</option>
                          <option value="percent">Acompte %</option>
                        </select>
                        <input type="number" value={orderEditForm.depositValue || 0}
                          onChange={e => {
                            const value = Number(e.target.value) || 0;
                            const sub = orderEditForm.items.reduce((s: number, i: any) => s + (i.product?.price || 0) * (i.quantity || 1), 0);
                            const totalBeforeDeposit = Math.max(0, sub - (orderEditForm.discountAmount || 0) + (orderEditForm.shipping || 0) + (orderEditForm.tvaAmount || 0));
                            const amount = orderEditForm.depositType === 'percent' ? Math.round(totalBeforeDeposit * value / 100) : value;
                            setOrderEditForm({ ...orderEditForm, depositValue: value, depositAmount: Math.max(0, amount) });
                          }}
                          placeholder="Valeur acompte"
                          className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                    </div>

                    {/* Items */}
                    <div className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <p className={`text-xs font-semibold mb-2 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>📦 Articles ({orderEditForm.items.length})</p>
                      <div className="space-y-2">
                        {orderEditForm.items.map((item: any, idx: number) => (
                          <div key={idx} className={`flex items-center gap-2 p-2 rounded-lg ${dm ? 'bg-gray-600' : 'bg-white'} border ${dm ? 'border-gray-500' : 'border-gray-200'}`}>
                            <img src={item.product.images?.[0] || '/images/ciment.jpg'} alt="" className="w-9 h-9 rounded-lg object-cover shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className={`text-xs font-medium line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{item.product.name}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <label className={`text-[10px] ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Qté:</label>
                                <input type="number" min={1} value={item.quantity}
                                  onChange={e => { const newItems = [...orderEditForm.items]; newItems[idx] = { ...newItems[idx], quantity: Math.max(1, Number(e.target.value)) }; setOrderEditForm({ ...orderEditForm, items: newItems }); }}
                                  className={`w-14 px-2 py-1 rounded border text-xs text-center ${dm ? 'bg-gray-700 border-gray-500 text-white' : 'bg-gray-50 border-gray-200'}`} />
                                <label className={`text-[10px] ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Prix:</label>
                                <input type="number" value={item.product.price}
                                  onChange={e => { const newItems = [...orderEditForm.items]; newItems[idx] = { ...newItems[idx], product: { ...newItems[idx].product, price: Math.max(0, Number(e.target.value)) } }; setOrderEditForm({ ...orderEditForm, items: newItems }); }}
                                  className={`w-20 px-2 py-1 rounded border text-xs text-center ${dm ? 'bg-gray-700 border-gray-500 text-white' : 'bg-gray-50 border-gray-200'}`} />
                              </div>
                            </div>
                            <button onClick={() => { const newItems = orderEditForm.items.filter((_: any, i: number) => i !== idx); setOrderEditForm({ ...orderEditForm, items: newItems }); }}
                              className="text-red-500 p-1 shrink-0" title="Retirer"><Trash2 size={14} /></button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* New total preview */}
                    {(() => {
                      const sub = orderEditForm.items.reduce((s: number, i: any) => s + i.product.price * i.quantity, 0);
                      return (
                        <div className={`p-3 rounded-xl ${dm ? 'bg-green-900/20 border-green-700' : 'bg-green-50 border-green-200'} border`}>
                          <div className="flex justify-between text-sm"><span className={dm ? 'text-gray-300' : 'text-gray-600'}>Sous-total articles</span><span className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{fmt(sub)}</span></div>
                          <div className="flex justify-between text-sm"><span className={dm ? 'text-gray-300' : 'text-gray-600'}>Remise</span><span className="font-medium text-red-500">-{fmt(orderEditForm.discountAmount || 0)}</span></div>
                          <div className="flex justify-between text-sm"><span className={dm ? 'text-gray-300' : 'text-gray-600'}>Transport</span><span className={`font-medium ${dm ? 'text-white' : 'text-gray-900'}`}>{orderEditForm.shipping === 0 ? 'Gratuit' : fmt(orderEditForm.shipping)}</span></div>
                          <div className="flex justify-between text-sm"><span className={dm ? 'text-gray-300' : 'text-gray-600'}>TVA ({orderEditForm.tvaRate || 0}%)</span><span className={`font-medium ${dm ? 'text-white' : 'text-gray-900'}`}>{fmt(orderEditForm.tvaAmount || 0)}</span></div>
                          <div className="flex justify-between text-sm"><span className={dm ? 'text-gray-300' : 'text-gray-600'}>Acompte</span><span className="font-medium text-green-500">{fmt(orderEditForm.depositAmount || 0)}</span></div>
                          <div className={`flex justify-between text-base font-bold pt-1 mt-1 border-t ${dm ? 'border-green-800 text-white' : 'border-green-200 text-gray-900'}`}>
                            <span>Nouveau total</span><span className="text-secondary">{fmt(Math.max(0, sub - (orderEditForm.discountAmount || 0) + orderEditForm.shipping + (orderEditForm.tvaAmount || 0)))}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Save bar */}
                  <div className={`sticky bottom-0 p-4 border-t ${dm ? 'border-gray-700 bg-gray-800' : 'border-gray-100 bg-white'} rounded-b-2xl flex gap-3`}>
                    <button onClick={() => { setEditingOrderId(null); setOrderEditForm(null); }} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
                    <button onClick={saveOrderEdit} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2">
                      <Save size={16} /> Enregistrer les modifications
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== CLIENTS ===== */}
        {activeTab === 'customers' && (
          <div className="animate-fadeIn">
            <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
              <div className="relative flex-1 max-w-md">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Rechercher un client..."
                  className={`w-full pl-10 pr-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
              <button onClick={openAddClient} className="flex items-center gap-2 bg-secondary hover:bg-secondary-dark text-white px-4 py-2.5 rounded-xl font-medium text-sm">
                <Plus size={16} /> Ajouter un client
              </button>
            </div>

            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4`}>
              {filteredClients.length === 0 ? (
                <p className={`text-center py-6 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Aucun client trouvé</p>
              ) : (
                <div className="space-y-2">
                  {filteredClients.map(c => (
                    <div key={c.id} className={`flex items-center gap-3 p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0">{c.name[0]}</div>
                      <div className="flex-1 min-w-0">
                        <p className={`font-medium text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{c.name}</p>
                        <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{c.phone} · {c.email}</p>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{c.address}{c.city ? `, ${c.city}` : ''}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{fmt(c.totalSpent)}</p>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{c.orderCount} commande(s)</p>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <button onClick={() => openEditClient(c)} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-600 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`} title="Modifier"><Edit size={14} /></button>
                        <button onClick={() => deleteClient(c.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-500" title="Supprimer"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== CAISSE ===== */}
        {activeTab === 'cash' && (
          <div className="animate-fadeIn">
            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              {(() => {
                const totalIn = cashRecords.filter(r => r.type === 'in').reduce((s, r) => s + r.amount, 0);
                const totalOut = cashRecords.filter(r => r.type === 'out').reduce((s, r) => s + r.amount, 0);
                return [
                  { label: 'Total Entrées', value: fmt(totalIn), color: 'text-green-500 bg-green-100', icon: '📥' },
                  { label: 'Total Sorties', value: fmt(totalOut), color: 'text-red-500 bg-red-100', icon: '📤' },
                  { label: 'Solde Caisse', value: fmt(totalIn - totalOut), color: 'text-blue-500 bg-blue-100', icon: '💰' },
                ];
              })().map(c => (
                <div key={c.label} className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4`}>
                  <div className="text-2xl mb-1">{c.icon}</div>
                  <div className={`text-xl font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{c.value}</div>
                  <div className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'} mt-0.5`}>{c.label}</div>
                </div>
              ))}
            </div>

            {/* ===== PANIER ADMIN — Facturation directe ===== */}
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4 mb-6`}>
              <h4 className={`font-bold mb-3 ${dm ? 'text-white' : 'text-gray-900'}`}>🛒 Panier — Facturation Client</h4>
              <p className={`text-xs mb-3 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Ajoutez des produits et générez Facture, Proforma ou Devis</p>

              {/* Client info */}
              <div className="grid grid-cols-2 gap-2 mb-3">
                <input id="adminClientName" placeholder="Nom du client" className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <input id="adminClientPhone" placeholder="Téléphone" className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              </div>
              <input id="adminClientAddress" placeholder="Adresse du client" className={`w-full px-3 py-2 rounded-lg border text-sm mb-3 ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />

              {/* Product picker */}
              <div className="flex gap-2 mb-3">
                <select id="adminProductSelect" className={`flex-1 px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`}>
                  {stockProducts.map(p => <option key={p.id} value={p.id}>{p.name} — {fmt(p.price)}</option>)}
                </select>
                <input id="adminProductQty" type="number" defaultValue={1} min={1} className={`w-16 px-2 py-2 rounded-lg border text-sm text-center ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <button onClick={() => {
                  const pid = Number((document.getElementById('adminProductSelect') as HTMLSelectElement).value);
                  const qty = Number((document.getElementById('adminProductQty') as HTMLInputElement).value) || 1;
                  const product = stockProducts.find(p => p.id === pid);
                  if (!product) return;
                  const store = useStore.getState();
                  store.addToCart(product, qty);
                }} className="px-3 py-2 rounded-lg bg-secondary text-white text-sm font-semibold shrink-0">+ Ajouter</button>
              </div>

              {/* Cart items */}
              {useStore.getState().cart.length > 0 && (
                <div className={`rounded-xl p-3 mb-3 ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  {useStore.getState().cart.map(item => (
                    <div key={item.product.id} className="flex items-center justify-between py-1 text-sm">
                      <span className={`${dm ? 'text-gray-300' : 'text-gray-700'} truncate mr-2`}>{item.quantity}× {item.product.name}</span>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
                        <button onClick={() => useStore.getState().removeFromCart(item.product.id)} className="text-red-400 hover:text-red-500 text-xs">✕</button>
                      </div>
                    </div>
                  ))}
                  <div className={`flex justify-between font-bold text-sm pt-2 mt-2 border-t ${dm ? 'border-gray-600 text-white' : 'border-gray-200 text-gray-900'}`}>
                    <span>Total</span>
                    <span className="text-secondary">{fmt(useStore.getState().getCartTotal())}</span>
                  </div>
                </div>
              )}

              {/* Generate buttons */}
              {useStore.getState().cart.length > 0 && (
                <div className="grid grid-cols-3 gap-2">
                  {(['facture', 'proforma', 'devis'] as const).map(type => {
                    const colors = { facture: 'bg-green-500 hover:bg-green-600', proforma: 'bg-blue-500 hover:bg-blue-600', devis: 'bg-purple-500 hover:bg-purple-600' };
                    const labels = { facture: '📄 Facture', proforma: '📋 Proforma', devis: '📝 Devis' };
                    return (
                      <button key={type} onClick={() => {
                        const name = (document.getElementById('adminClientName') as HTMLInputElement).value || 'Client';
                        const phone = (document.getElementById('adminClientPhone') as HTMLInputElement).value || '';
                        const address = (document.getElementById('adminClientAddress') as HTMLInputElement).value || '';
                        const cartItems = useStore.getState().cart;
                        generateFromCart(type, cartItems, { name, phone, email: '', address }, 0, '', 0, 0);
                      }} className={`py-2.5 rounded-lg text-white text-xs font-bold ${colors[type]}`}>
                        {labels[type]}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Add manual entry */}
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4 mb-6`}>
              <h4 className={`font-bold mb-3 ${dm ? 'text-white' : 'text-gray-900'}`}>➕ Nouvelle opération</h4>
              <div className="flex flex-wrap gap-2">
                <select id="cashType" className={`px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`}>
                  <option value="in">Entrée</option>
                  <option value="out">Sortie</option>
                </select>
                <input id="cashLabel" placeholder="Libellé" className={`flex-1 min-w-[120px] px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <input id="cashAmount" type="number" placeholder="Montant" className={`w-28 px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <input id="cashMethod" placeholder="Méthode" defaultValue="Espèces" className={`w-28 px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <button onClick={() => {
                  const t = (document.getElementById('cashType') as HTMLSelectElement).value as 'in' | 'out';
                  const l = (document.getElementById('cashLabel') as HTMLInputElement).value;
                  const a = Number((document.getElementById('cashAmount') as HTMLInputElement).value);
                  const m = (document.getElementById('cashMethod') as HTMLInputElement).value;
                  if (!l || !a) return;
                  const now = new Date();
                  addCashRecord({ id: 'CASH-' + Date.now().toString(36).toUpperCase(), date: now.toLocaleDateString('fr-FR'), time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }), type: t, label: l, amount: a, method: m || 'Espèces' });
                  (document.getElementById('cashLabel') as HTMLInputElement).value = '';
                  (document.getElementById('cashAmount') as HTMLInputElement).value = '';
                }} className="px-4 py-2 rounded-lg bg-secondary hover:bg-secondary-dark text-white text-sm font-semibold">Ajouter</button>
              </div>
            </div>

            {/* Records */}
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md overflow-hidden`}>
              {cashRecords.length === 0 ? (
                <div className="p-10 text-center">
                  <div className="text-5xl mb-3">🏦</div>
                  <h3 className={`font-bold mb-1 ${dm ? 'text-white' : 'text-gray-900'}`}>Caisse vide</h3>
                  <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Les mouvements de caisse apparaîtront ici</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {[...cashRecords].reverse().map(r => (
                    <div key={r.id} className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'} flex items-center gap-3`}>
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg shrink-0 ${r.type === 'in' ? 'bg-green-100' : 'bg-red-100'}`}>
                        {r.type === 'in' ? '📥' : '📤'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`font-medium text-sm line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{r.label}</p>
                        <div className={`flex items-center gap-2 text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>
                          <span>{r.date} {r.time}</span>
                          <span>·</span>
                          <span>{r.method}</span>
                          {r.orderId && <span className="text-[10px] opacity-70">· {r.orderId}</span>}
                        </div>
                        {/* Documents for order */}
                        {r.orderId && orders.find(o => o.id === r.orderId) && (
                          <div className="flex gap-1 mt-1 flex-wrap">
                            {(['facture', 'proforma', 'devis'] as const).map(type => (
                              <button key={type} onClick={() => generateInvoiceFromOrder(orders.find(o => o.id === r.orderId)!, type)}
                                className={`px-1.5 py-0.5 rounded text-[9px] font-semibold ${type === 'facture' ? 'bg-green-100 text-green-700' : type === 'proforma' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                                {type === 'facture' ? 'Facture' : type === 'proforma' ? 'Pro' : 'Devis'}
                              </button>
                            ))}
                            <button onClick={() => openWhatsAppOrder(orders.find(o => o.id === r.orderId)!, orders.find(o => o.id === r.orderId)!.phone)}
                              className="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-green-100 text-green-700">📱</button>
                          </div>
                        )}
                      </div>
                      <div className="text-right shrink-0">
                        <div className={`font-bold text-sm ${r.type === 'in' ? 'text-green-500' : 'text-red-500'}`}>
                          {r.type === 'in' ? '+' : '-'}{fmt(r.amount)}
                        </div>
                        <button onClick={() => { if (confirm(`Supprimer "${r.label}" ?`)) deleteCashRecord(r.id); }}
                          className="text-red-400 hover:text-red-500 text-xs mt-1">Supprimer</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== CATEGORIES ===== */}
        {activeTab === 'categories' && (
          <div className="animate-fadeIn">
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 mb-5`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>📂 Catégories ({categories.length})</h3>
                <button onClick={() => {
                  const id = 'cat-' + Date.now().toString(36);
                  addCategory({ id, name: 'Nouvelle catégorie', icon: '📦', count: 0, image: '/images/ciment.jpg', color: 'from-gray-500 to-gray-700', background: '' });
                }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-secondary hover:bg-secondary-dark text-white text-xs font-semibold">
                  <Plus size={14} /> Ajouter
                </button>
              </div>
              <div className="space-y-3">
                {categories.map((cat: any) => (
                  <div key={cat.id} className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <div className="flex items-center gap-3">
                      <div className="text-2xl shrink-0">{cat.icon}</div>
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex gap-2 flex-wrap">
                          <input value={cat.icon} onChange={e => updateCategory(cat.id, { icon: e.target.value })}
                            className={`w-12 px-2 py-1 rounded-lg border text-center text-lg ${dm ? 'bg-gray-600 border-gray-500' : 'bg-white border-gray-200'}`} />
                          <input value={cat.name} onChange={e => updateCategory(cat.id, { name: e.target.value })}
                            className={`flex-1 min-w-[120px] px-3 py-1 rounded-lg border text-sm font-medium ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                        </div>
                        {/* Background picker */}
                        <div className="flex gap-2 flex-wrap items-center">
                          <input value={cat.background || ''} onChange={e => updateCategory(cat.id, { background: e.target.value })}
                            placeholder="Couleur, dégradé ou URL image"
                            className={`flex-1 min-w-[160px] px-3 py-1.5 rounded-lg border text-xs ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                          <input type="file" accept="image/*" className="hidden" id={`cat-bg-${cat.id}`}
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const reader = new FileReader();
                              reader.onload = () => updateCategory(cat.id, { background: reader.result as string });
                              reader.readAsDataURL(file);
                            }} />
                          <label htmlFor={`cat-bg-${cat.id}`} className={`px-2.5 py-1.5 rounded-lg border text-xs cursor-pointer font-medium ${dm ? 'bg-gray-600 border-gray-500 text-gray-200 hover:bg-gray-500' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                            🖼️ Image
                          </label>
                          {/* Preview */}
                          {cat.background && (
                            <div className="flex items-center gap-1">
                              <div className={`w-8 h-8 rounded-lg border ${dm ? 'border-gray-600' : 'border-gray-200'}`}
                                style={cat.background.startsWith('#') || cat.background.startsWith('linear') || cat.background.startsWith('radial')
                                  ? { background: cat.background }
                                  : { background: `url(${cat.background}) center/cover` }} />
                              <button onClick={() => updateCategory(cat.id, { background: '' })} className="text-red-400 text-xs">✕</button>
                            </div>
                          )}
                        </div>
                      </div>
                      <button onClick={() => { if (confirm(`Supprimer "${cat.name}" ?`)) deleteCategory(cat.id); }}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-red-500 shrink-0"><Trash2 size={14} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 mb-5`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>📁 Sous-catégories ({customSubcategories.length})</h3>
                <button onClick={() => addSubcategory({ id: 'sub-' + Date.now().toString(36), categoryId: categories[0]?.id || 'construction', name: 'Nouvelle sous-catégorie' })}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-secondary hover:bg-secondary-dark text-white text-xs font-semibold">
                  <Plus size={14} /> Ajouter
                </button>
              </div>
              <div className="space-y-2">
                {customSubcategories.map(sub => (
                  <div key={sub.id} className={`flex flex-wrap items-center gap-2 p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <select value={sub.categoryId} onChange={e => updateSubcategory(sub.id, { categoryId: e.target.value })}
                      className={`px-3 py-2 rounded-lg border text-xs ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`}>
                      {categories.map((cat: any) => <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>)}
                    </select>
                    <input value={sub.name} onChange={e => updateSubcategory(sub.id, { name: e.target.value })}
                      className={`flex-1 min-w-[150px] px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-600 border-gray-500 text-white' : 'bg-white border-gray-200'}`} />
                    <button onClick={() => deleteSubcategory(sub.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-500"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===== TECHNICIENS ===== */}
        {activeTab === 'technicians' && (
          <div className="animate-fadeIn space-y-5">
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>🛠️ Techniciens ({technicians.length})</h3>
                <button onClick={openAddTech} className="px-3 py-2 rounded-xl bg-secondary text-white text-xs font-bold"><Plus size={14} className="inline mr-1" /> Ajouter</button>
              </div>
              <div className="space-y-3">
                {technicians.map(t => {
                  const reviews = technicianReviews.filter(r => r.technicianId === t.id);
                  const avg = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : '4.5';
                  return (
                    <div key={t.id} className={`flex flex-wrap items-center gap-3 p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      {t.photo ? <img src={t.photo} className="w-12 h-12 rounded-xl object-cover" /> : <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center text-2xl">🛠️</div>}
                      <div className="flex-1 min-w-[160px]">
                        <p className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{t.name}</p>
                        <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{t.trade} · {t.city} · {t.experience} ans · ⭐ {avg} ({reviews.length})</p>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>Contacts : {t.contactCount || 0} · RDV : {appointments.filter(a => a.technicianId === t.id).length}</p>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        <button onClick={() => updateTechnician(t.id, { active: !t.active })} className={`px-2 py-1 rounded-lg text-[10px] font-bold ${t.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{t.active ? 'Actif' : 'Désactivé'}</button>
                        <button onClick={() => updateTechnician(t.id, { status: t.status === 'available' ? 'busy' : 'available' })} className="px-2 py-1 rounded-lg bg-amber-100 text-amber-700 text-[10px] font-bold">{t.status === 'available' ? 'Disponible' : 'Occupé'}</button>
                        <button onClick={() => openEditTech(t)} className="px-2 py-1 rounded-lg bg-blue-100 text-blue-700 text-[10px] font-bold">Modifier</button>
                        <button onClick={() => { if (confirm(`Supprimer ${t.name} ?`)) deleteTechnician(t.id); }} className="px-2 py-1 rounded-lg bg-red-100 text-red-700 text-[10px] font-bold">Supprimer</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
              <h3 className={`font-bold mb-3 ${dm ? 'text-white' : 'text-gray-900'}`}>📅 Demandes de rendez-vous ({appointments.length})</h3>
              <div className="space-y-2">
                {appointments.map(a => (
                  <div key={a.id} className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'} flex items-center gap-3`}>
                    <div className="flex-1 min-w-0 text-sm">
                      <p className={dm ? 'text-white' : 'text-gray-900'}>{a.clientName} · {a.phone}</p>
                      <p className={dm ? 'text-gray-400' : 'text-gray-500'}>{a.message}</p>
                    </div>
                    <select value={a.status} onChange={e => updateAppointment(a.id, { status: e.target.value as any })} className={`px-2 py-1 rounded-lg text-xs ${dm ? 'bg-gray-600 text-white' : 'bg-white'}`}>
                      <option value="pending">En attente</option><option value="confirmed">Confirmé</option><option value="done">Terminé</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===== AVIS ===== */}
        {activeTab === 'reviews' && (
          <div className="animate-fadeIn">
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
              <h3 className={`font-bold mb-4 ${dm ? 'text-white' : 'text-gray-900'}`}>⭐ Appréciations clients ({productReviews.length})</h3>
              {productReviews.length === 0 ? (
                <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Aucun avis pour le moment.</p>
              ) : (
                <div className="space-y-3">
                  {[...productReviews].reverse().map(review => {
                    const product = stockProducts.find(p => p.id === review.productId);
                    const negative = review.rating <= 2;
                    return (
                      <div key={review.id} className={`p-3 rounded-xl border ${negative ? 'border-red-200 bg-red-50' : dm ? 'border-gray-700 bg-gray-700' : 'border-gray-100 bg-gray-50'}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className={`font-semibold text-sm ${dm && !negative ? 'text-white' : 'text-gray-900'}`}>{review.userName}</p>
                            <p className={`text-xs ${dm && !negative ? 'text-gray-400' : 'text-gray-500'}`}>{product?.name || 'Produit'} · {review.date}</p>
                            <div className="flex gap-0.5 mt-1">
                              {[1,2,3,4,5].map(n => <span key={n} className={n <= review.rating ? 'text-amber-400' : 'text-gray-300'}>★</span>)}
                            </div>
                            <p className={`text-sm mt-2 ${dm && !negative ? 'text-gray-300' : 'text-gray-700'}`}>{review.comment}</p>
                          </div>
                          <button onClick={() => deleteProductReview(review.id)} className="px-3 py-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-xs font-semibold shrink-0">
                            Supprimer
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== PROMOTIONS — Envoi aux utilisateurs ===== */}
        {activeTab === 'promos' && (() => {
          const promoProducts = stockProducts.filter(p => p.badge || p.featured || p.oldPrice);
          const allUsers = userAccounts.filter(a => a.status === 'active' && a.role === 'user');
          const co = useStore.getState().companyInfo;

          const buildPromoMessage = (products: typeof promoProducts) => {
            const lines: string[] = [];
            lines.push(`🔥 *PROMOTIONS ${co.name.toUpperCase()}* 🔥`);
            lines.push('━━━━━━━━━━━━━━━━━━━━━━');
            lines.push('');
            products.forEach(p => {
              lines.push(`🏷️ *${p.name}*`);
              if (p.oldPrice) {
                const f = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
                lines.push(`   ~~${f(p.oldPrice)} FCFA~~ → *${f(p.price)} FCFA*`);
              } else {
                const f = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
                lines.push(`   💰 *${f(p.price)} FCFA*`);
              }
              if (p.badge) lines.push(`   ${p.badge}`);
              lines.push('');
            });
            lines.push('━━━━━━━━━━━━━━━━━━━━━━');
            lines.push(`📍 *${co.name}*`);
            lines.push(`📞 ${co.phone}`);
            lines.push(`🌐 ${co.website}`);
            lines.push('');
            lines.push('Commandez maintenant ! 🛒');
            return lines.join('\n');
          };

          const buildPromoEmail = (products: typeof promoProducts) => {
            let body = `Bonjour,\n\nDécouvrez nos promotions du moment chez ${co.name} !\n\n`;
            products.forEach(p => {
              body += `• ${p.name}`;
              if (p.oldPrice) {
                const f = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
                body += ` — ${f(p.oldPrice)} → ${f(p.price)} FCFA`;
              } else {
                const f = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
                body += ` — ${f(p.price)} FCFA`;
              }
              if (p.badge) body += ` (${p.badge})`;
              body += '\n';
            });
            body += `\nContactez-nous : ${co.phone}\n${co.website}\n\nCordialement,\n${co.name}`;
            return body;
          };

          const promoMessage = buildPromoMessage(promoProducts);

          const copyMessage = () => {
            navigator.clipboard.writeText(promoMessage).then(() => {
              useStore.getState().setNotification({ message: '✅ Message copié ! Collez-le dans WhatsApp', type: 'success' });
            }).catch(() => {
              // Fallback
              const ta = document.createElement('textarea');
              ta.value = promoMessage;
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              useStore.getState().setNotification({ message: '✅ Message copié !', type: 'success' });
            });
          };

          const sendEmailToAll = () => {
            const emails = allUsers.map(u => u.email).filter(Boolean);
            const subject = encodeURIComponent(`🔥 Promotions ${co.name}`);
            const body = encodeURIComponent(buildPromoEmail(promoProducts));
            window.open(`mailto:${emails.join(',')}?subject=${subject}&body=${body}`, '_self');
            useStore.getState().setNotification({ message: `Email préparé pour ${emails.length} utilisateur(s)`, type: 'success' });
          };



          return (
            <div className="animate-fadeIn space-y-5">
              {/* Promo products summary */}
              <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
                <h3 className={`font-bold mb-3 ${dm ? 'text-white' : 'text-gray-900'}`}>🔥 Produits en promotion ({promoProducts.length})</h3>
                {promoProducts.length === 0 ? (
                  <div className="text-center py-6">
                    <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Aucun produit en promotion. Allez dans Stock → colonne "Promo/Vedette" pour en ajouter.</p>
                  </div>
                ) : (
                  <div className="space-y-2 mb-4">
                    {promoProducts.map(p => (
                      <div key={p.id} className={`flex items-center gap-3 p-2 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <img src={p.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{p.name}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-secondary font-bold text-sm">{fmt(p.price)}</span>
                            {p.oldPrice && <span className="text-xs text-gray-400 line-through">{fmt(p.oldPrice)}</span>}
                            {p.badge && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 font-bold">{p.badge}</span>}
                            {p.featured && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-yellow-100 text-yellow-700 font-bold">⭐</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Envoi aux clients */}
              {promoProducts.length > 0 && (() => {
                const validUsers = allUsers.filter(u => formatGabonPhone(u.phone).length >= 10);
                const waQueueKey = 'wa-promo-queue';
                const getSent = (): string[] => { try { return JSON.parse(localStorage.getItem(waQueueKey) || '[]'); } catch { return []; } };
                const markSent = (id: string) => { const s = getSent(); s.push(id); localStorage.setItem(waQueueKey, JSON.stringify(s)); };
                const resetQueue = () => localStorage.removeItem(waQueueKey);
                const sentIds = getSent();
                const remaining = validUsers.filter(u => !sentIds.includes(u.id));
                const nextUser = remaining[0];

                const sendNext = () => {
                  if (!nextUser) return;
                  markSent(nextUser.id);
                  openWhatsAppDirect(nextUser.phone, promoMessage);
                  // Force re-render
                  setTimeout(() => useStore.getState().setNotification({ message: `✅ Envoyé à ${nextUser.name} (${sentIds.length + 1}/${validUsers.length})`, type: 'success' }), 500);
                };

                return (
                  <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
                    <h3 className={`font-bold mb-1 ${dm ? 'text-white' : 'text-gray-900'}`}>📤 Envoyer la promo par WhatsApp</h3>
                    <p className={`text-xs mb-4 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
                      {validUsers.length} client(s) · {sentIds.length} envoyé(s) · {remaining.length} restant(s)
                    </p>

                    {/* Progress */}
                    {sentIds.length > 0 && (
                      <div className="mb-4">
                        <div className={`h-2 rounded-full ${dm ? 'bg-gray-700' : 'bg-gray-200'}`}>
                          <div className="h-full rounded-full bg-[#25D366] transition-all" style={{ width: `${(sentIds.length / validUsers.length) * 100}%` }} />
                        </div>
                        <p className={`text-xs mt-1 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{sentIds.length}/{validUsers.length} envoyés</p>
                      </div>
                    )}

                    {/* Main action buttons */}
                    <div className="space-y-2 mb-4">
                      {remaining.length > 0 ? (
                        <button onClick={sendNext}
                          className="w-full py-3.5 rounded-xl font-bold text-sm bg-[#25D366] hover:bg-[#1ebe5b] text-white flex items-center justify-center gap-2 shadow-lg shadow-green-500/20 active:scale-[0.98]">
                          📱 {sentIds.length === 0 ? `Envoyer à tous (${validUsers.length})` : `Envoyer au suivant → ${nextUser?.name}`}
                        </button>
                      ) : (
                        <div className={`py-3 rounded-xl text-center font-bold text-sm ${dm ? 'bg-green-900/30 text-green-400' : 'bg-green-50 text-green-700'}`}>
                          ✅ Tous les clients ont reçu la promo !
                        </div>
                      )}

                      {sentIds.length > 0 && (
                        <button onClick={() => { resetQueue(); useStore.getState().setNotification({ message: 'File réinitialisée', type: 'info' }); }}
                          className={`w-full py-2 rounded-xl text-xs font-medium ${dm ? 'bg-gray-700 text-gray-400 hover:bg-gray-600' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}>
                          🔄 Recommencer depuis le début
                        </button>
                      )}
                    </div>

                    {/* Other actions */}
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      <button onClick={copyMessage}
                        className={`py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 ${dm ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                        📋 Copier le texte
                      </button>
                      <button onClick={sendEmailToAll}
                        className="py-2 rounded-xl font-bold text-xs bg-blue-500 hover:bg-blue-600 text-white flex items-center justify-center gap-1.5">
                        ✉️ Email à tous
                      </button>
                    </div>

                    {/* Client list with status */}
                    <div className="space-y-1.5">
                      {validUsers.map(u => {
                        const isSent = sentIds.includes(u.id);
                        return (
                          <div key={u.id} className={`flex items-center gap-2.5 p-2 rounded-xl ${isSent ? (dm ? 'bg-green-900/20' : 'bg-green-50') : (dm ? 'bg-gray-700' : 'bg-gray-50')}`}>
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0 ${isSent ? 'bg-green-500' : 'bg-primary'}`}>
                              {isSent ? '✓' : u.name[0]}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className={`text-xs font-medium ${dm ? 'text-white' : 'text-gray-900'}`}>{u.name}</p>
                              <p className={`text-[10px] ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{u.phone}</p>
                            </div>
                            <span className={`text-[10px] font-bold shrink-0 ${isSent ? 'text-green-500' : (dm ? 'text-gray-500' : 'text-gray-400')}`}>
                              {isSent ? '✅ Envoyé' : '⏳ En attente'}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Preview */}
                    <details className={`rounded-xl mt-4 ${dm ? 'bg-gray-700' : 'bg-gray-50'} overflow-hidden`}>
                      <summary className={`px-4 py-2 cursor-pointer text-sm font-medium ${dm ? 'text-gray-300' : 'text-gray-600'}`}>👁️ Aperçu du message</summary>
                      <pre className={`px-4 py-3 text-xs whitespace-pre-wrap ${dm ? 'text-gray-300' : 'text-gray-700'}`}>{promoMessage}</pre>
                    </details>
                  </div>
                );
              })()}
            </div>
          );
        })()}

        {/* ===== UTILISATEURS ===== */}
        {activeTab === 'users' && (
          <div className="animate-fadeIn">
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>👥 Comptes utilisateurs ({userAccounts.length})</h3>
              </div>
              <div className="space-y-2">
                {userAccounts.map(acc => (
                  <div key={acc.id} className={`flex flex-wrap items-center gap-2 p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'} ${acc.status === 'disabled' ? 'opacity-50' : ''}`}>
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0 ${acc.role === 'admin' ? 'bg-red-500' : 'bg-primary'}`}>{acc.name[0]}</div>
                    <div className="flex-1 min-w-0 min-w-[140px]">
                      <p className={`font-medium text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{acc.name}</p>
                      <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{acc.email} · {acc.phone}</p>
                      <p className={`text-[10px] ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{acc.id} · {acc.createdAt}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-wrap">
                      <select value={acc.role} onChange={e => updateUserAccount(acc.id, { role: e.target.value as 'admin' | 'user' })}
                        className={`text-[10px] px-1.5 py-1 rounded-lg font-medium border ${acc.role === 'admin' ? 'bg-red-50 text-red-700 border-red-200' : 'bg-blue-50 text-blue-700 border-blue-200'}`}>
                        <option value="user">👤</option>
                        <option value="admin">👑</option>
                      </select>
                      <button onClick={() => updateUserAccount(acc.id, { status: acc.status === 'active' ? 'disabled' : 'active' })}
                        className={`text-[10px] px-2 py-1 rounded-full font-semibold ${acc.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {acc.status === 'active' ? 'Actif' : 'Désactivé'}
                      </button>
                      <button onClick={() => { if (confirm(`Supprimer le compte de ${acc.name} ?`)) deleteUserAccount(acc.id); }}
                        className="p-1 rounded-lg hover:bg-red-50 text-red-500" title="Supprimer">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ===== MES INFOS ===== */}
        {activeTab === 'settings' && <AdminSettings />}
      </div>

      {/* Technician Modal */}
      {showTechModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowTechModal(false)} />
          <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto`}>
            <div className="flex items-center justify-between mb-5">
              <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{editingTechId ? 'Modifier technicien' : 'Nouveau technicien'}</h3>
              <button onClick={() => setShowTechModal(false)}><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div onClick={() => techPhotoRef.current?.click()} className={`h-28 rounded-xl border-2 border-dashed flex items-center justify-center cursor-pointer overflow-hidden ${dm ? 'border-gray-600 bg-gray-700' : 'border-gray-200 bg-gray-50'}`}>
                {techForm.photo ? <img src={techForm.photo} className="w-full h-full object-cover" /> : <span className={dm ? 'text-gray-400' : 'text-gray-500'}>📷 Photo de profil</span>}
              </div>
              <input ref={techPhotoRef} type="file" accept="image/*" className="hidden" onChange={handleTechPhoto} />
              <input value={techForm.name} onChange={e => setTechForm({ ...techForm, name: e.target.value })} placeholder="Nom complet" className={`w-full px-4 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              <div className="grid grid-cols-2 gap-2">
                <select value={techForm.trade} onChange={e => setTechForm({ ...techForm, trade: e.target.value })} className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`}>
                  {['Électricien','Plombier','Maçon','Peintre','Soudeur','Menuisier','Climatisation','Carreleur'].map(t => <option key={t}>{t}</option>)}
                </select>
                <input value={techForm.experience} onChange={e => setTechForm({ ...techForm, experience: e.target.value })} type="number" placeholder="Années" className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input value={techForm.city} onChange={e => setTechForm({ ...techForm, city: e.target.value })} placeholder="Ville" className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <input value={techForm.zone} onChange={e => setTechForm({ ...techForm, zone: e.target.value })} placeholder="Zone" className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input value={techForm.phone} onChange={e => setTechForm({ ...techForm, phone: e.target.value })} placeholder="Téléphone" className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                <input value={techForm.whatsapp} onChange={e => setTechForm({ ...techForm, whatsapp: e.target.value })} placeholder="WhatsApp" className={`px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              </div>
              <input value={techForm.specialties} onChange={e => setTechForm({ ...techForm, specialties: e.target.value })} placeholder="Spécialités séparées par virgules" className={`w-full px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              <input value={techForm.hours} onChange={e => setTechForm({ ...techForm, hours: e.target.value })} placeholder="Horaires" className={`w-full px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
              <textarea value={techForm.description} onChange={e => setTechForm({ ...techForm, description: e.target.value })} rows={3} placeholder="Description" className={`w-full px-3 py-2 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowTechModal(false)} className={`px-5 py-2.5 rounded-xl ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
              <button onClick={saveTech} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2.5 rounded-xl font-semibold"><Save size={16} className="inline mr-1" /> Enregistrer</button>
            </div>
          </div>
        </div>
      )}

      {/* Client Modal */}
      {showClientModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowClientModal(false)} />
          <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl p-6 w-full max-w-md animate-fadeIn`}>
            <div className="flex items-center justify-between mb-6">
              <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>
                {editingClient ? 'Modifier le client' : 'Nouveau client'}
              </h3>
              <button onClick={() => setShowClientModal(false)} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
            </div>
            <div className="space-y-4">
              {[
                { label: 'Nom complet *', key: 'name', ph: 'Nom du client' },
                { label: 'Téléphone *', key: 'phone', ph: '+225 07 XX XX XX' },
                { label: 'Email', key: 'email', ph: 'email@exemple.com' },
                { label: 'Adresse', key: 'address', ph: 'Quartier, rue...' },
                { label: 'Ville', key: 'city', ph: 'Abidjan' },
              ].map(f => (
                <div key={f.key}>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>{f.label}</label>
                  <input value={(clientForm as any)[f.key]} onChange={e => setClientForm({ ...clientForm, [f.key]: e.target.value })} placeholder={f.ph}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowClientModal(false)} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
              <button onClick={handleSaveClient} disabled={!clientForm.name || !clientForm.phone}
                className="flex-1 bg-secondary hover:bg-secondary-dark disabled:bg-gray-300 text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2">
                <Save size={16} /> {editingClient ? 'Enregistrer' : 'Créer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Hidden file inputs */}
      <input ref={imageChangeRef} type="file" accept="image/*" className="hidden"
        onChange={handleExistingProductImageChange} />
      <input ref={productFileRef} type="file" accept="image/*" className="hidden"
        onChange={handleProductImageSelect} />
      <input ref={productCameraRef} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={handleProductImageSelect} />

      {/* Edit Product Modal */}
      {editProductId && editProductForm && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-8 overflow-y-auto">
          <div className="fixed inset-0 bg-black/50" onClick={() => setEditProductId(null)} />
          <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl p-6 w-full max-w-md animate-fadeIn my-4`}>
            <div className="flex items-center justify-between mb-5">
              <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>✏️ Modifier le produit</h3>
              <button onClick={() => setEditProductId(null)} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Nom *</label>
                <input value={editProductForm.name} onChange={e => setEditProductForm({ ...editProductForm, name: e.target.value })}
                  className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Prix (FCFA) *</label>
                  <input type="number" value={editProductForm.price} onChange={e => setEditProductForm({ ...editProductForm, price: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Stock</label>
                  <input type="number" value={editProductForm.stock} onChange={e => setEditProductForm({ ...editProductForm, stock: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Catégorie</label>
                  <select value={editProductForm.category} onChange={e => setEditProductForm({ ...editProductForm, category: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`}>
                    {categories.map((cat: any) => <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Sous-catégorie</label>
                  <select value={editProductForm.subcategory} onChange={e => setEditProductForm({ ...editProductForm, subcategory: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`}>
                    <option value="">Choisir...</option>
                    {customSubcategories.filter(s => s.categoryId === editProductForm.category).map(sub => (
                      <option key={sub.id} value={sub.name}>{sub.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Description</label>
                <textarea value={editProductForm.description} onChange={e => setEditProductForm({ ...editProductForm, description: e.target.value })} rows={2}
                  className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setEditProductId(null)} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
              <button onClick={() => {
                updateProductField(editProductId, {
                  name: editProductForm.name,
                  price: parseInt(editProductForm.price) || 0,
                  stock: parseInt(editProductForm.stock) || 0,
                  category: editProductForm.category,
                  subcategory: editProductForm.subcategory,
                  description: editProductForm.description,
                });
                setEditProductId(null);
                useStore.getState().setNotification({ message: '✅ Produit modifié', type: 'success' });
              }} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2">
                <Save size={16} /> Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => { setShowProductModal(false); setPendingProductFile(null); }} />
          <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-2xl p-6 w-full max-w-md animate-fadeIn max-h-[90vh] overflow-y-auto`}>
            <div className="flex items-center justify-between mb-5">
              <h3 className={`text-lg font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>Nouveau produit</h3>
              <button onClick={() => { setShowProductModal(false); setPendingProductFile(null); }} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
            </div>

            {/* Image upload */}
            <div className="mb-4">
              <label className={`block text-sm font-medium mb-2 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Photo du produit</label>
              <div
                className={`border-2 border-dashed rounded-xl p-4 text-center transition-colors ${
                  productImagePreview
                    ? 'border-green-400 bg-green-50'
                    : dm ? 'border-gray-600 hover:border-secondary bg-gray-700' : 'border-gray-300 hover:border-secondary bg-gray-50'
                }`}>
                {productImagePreview ? (
                  <div className="relative">
                    <img src={productImagePreview} alt="Aperçu" className="w-full h-40 object-contain rounded-lg" />
                    <p className="text-xs text-green-600 font-medium mt-2">✅ Image sélectionnée</p>
                  </div>
                ) : (
                  <div className="py-4">
                    <Camera size={32} className={`mx-auto mb-2 ${dm ? 'text-gray-500' : 'text-gray-400'}`} />
                    <p className={`text-sm font-medium ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Ajoutez une image du produit</p>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <button type="button" onClick={() => productFileRef.current?.click()}
                    className={`py-2 rounded-xl text-xs font-semibold ${dm ? 'bg-gray-600 text-white hover:bg-gray-500' : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'}`}>
                    🖼️ Ajouter image
                  </button>
                  <button type="button" onClick={() => productCameraRef.current?.click()}
                    className="py-2 rounded-xl text-xs font-semibold bg-secondary text-white hover:bg-secondary-dark">
                    📷 Prendre photo
                  </button>
                </div>
              </div>
            </div>

            {/* Form fields */}
            <div className="space-y-3">
              <div>
                <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Nom du produit *</label>
                <input value={productForm.name} onChange={e => setProductForm({ ...productForm, name: e.target.value })} placeholder="Ex: Ciment Portland 50kg"
                  className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Prix (FCFA) *</label>
                  <input type="number" value={productForm.price} onChange={e => setProductForm({ ...productForm, price: e.target.value })} placeholder="8500"
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Stock initial</label>
                  <input type="number" value={productForm.stock} onChange={e => setProductForm({ ...productForm, stock: e.target.value })} placeholder="100"
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Catégorie</label>
                  <select value={productForm.category} onChange={e => setProductForm({ ...productForm, category: e.target.value, subcategory: '' })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`}>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Sous-catégorie</label>
                  <select value={productForm.subcategory} onChange={e => setProductForm({ ...productForm, subcategory: e.target.value })}
                    className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`}>
                    <option value="">Choisir...</option>
                    {customSubcategories.filter(s => s.categoryId === productForm.category).map(sub => (
                      <option key={sub.id} value={sub.name}>{sub.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${dm ? 'text-gray-300' : 'text-gray-700'}`}>Description</label>
                <textarea value={productForm.description} onChange={e => setProductForm({ ...productForm, description: e.target.value })} placeholder="Description du produit..." rows={2}
                  className={`w-full px-4 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={() => { setShowProductModal(false); setPendingProductFile(null); }} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
              <button onClick={handleAddProduct} disabled={!productForm.name || !productForm.price || uploadingImage}
                className="flex-1 bg-secondary hover:bg-secondary-dark disabled:bg-gray-300 text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2">
                <Save size={16} /> {uploadingImage ? 'Enregistrement...' : 'Enregistrer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
