import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, LogOut, ShoppingBag, ChevronRight, Eye, EyeOff, Loader2, Lock, MapPin, Save, X, Check } from 'lucide-react';
import { useStore } from '../store/useStore';
import { PageHeader } from './PageHeader';
import { PWAInstallButton } from './PWAInstall';
import { formatGabonPhone } from '../utils/pdfGenerator';

export const AccountPage: React.FC = () => {
  const { isLoggedIn, user, logout, orders, setPage, darkMode, isAdmin, userAccounts, updateUserAccount, authMode, setAuthMode } = useStore();
  const { register, loginWithPassword } = useStore();
  const dm = darkMode;

  // Auth form — sync with authMode from store
  const [isRegister, setIsRegister] = useState(authMode === 'register');
  useEffect(() => { setIsRegister(authMode === 'register'); }, [authMode]);
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', city: 'Port-Gentil', address: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  // Profile edit
  const [editProfile, setEditProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({ name: '', phone: '', email: '', address: '' });
  const [changePassword, setChangePassword] = useState(false);
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' });
  const [pwError, setPwError] = useState('');
  const [pwSuccess, setPwSuccess] = useState('');

  // GPS send
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsSent, setGpsSent] = useState(false);

  const handleSendGPS = () => {
    if (!navigator.geolocation) {
      useStore.getState().setNotification({ message: 'Géolocalisation non supportée', type: 'error' });
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        let address = '';
        try {
          const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=fr`);
          const d = await r.json();
          const a = d.address || {};
          address = [a.road || a.neighbourhood, a.suburb || a.city_district, a.city || a.town].filter(Boolean).join(', ');
        } catch { /* ignore */ }

        const co = useStore.getState().companyInfo;
        const waPhone = formatGabonPhone(co.whatsapp);
        const msg = [
          `📍 *Ma position actuelle*`,
          ``,
          `👤 ${user?.name || 'Client'}`,
          `📞 ${user?.phone || ''}`,
          ``,
          address ? `📍 ${address}` : '',
          `🗺️ https://www.google.com/maps?q=${latitude},${longitude}`,
          ``,
          `GPS: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
        ].filter(Boolean).join('\n');

        const encoded = encodeURIComponent(msg);
        window.open(`https://api.whatsapp.com/send?phone=${waPhone}&text=${encoded}`, '_blank');
        setGpsLoading(false);
        setGpsSent(true);
        setTimeout(() => setGpsSent(false), 5000);
      },
      (err) => {
        setGpsLoading(false);
        if (err.code === 1) useStore.getState().setNotification({ message: 'Accès à la localisation refusé', type: 'error' });
        else useStore.getState().setNotification({ message: 'Position indisponible', type: 'error' });
      },
      { enableHighAccuracy: true, timeout: 15000 }
    );
  };

  const myAccount = user ? userAccounts.find(a => a.email.toLowerCase() === user.email.toLowerCase()) : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setLoading(true);
    if (isRegister) {
      if (!form.name.trim()) { setAuthError('Entrez votre nom complet'); setLoading(false); return; }
      if (!form.email.trim()) { setAuthError('Entrez votre adresse email'); setLoading(false); return; }
      if (!form.phone.trim()) { setAuthError('Entrez votre numéro de téléphone'); setLoading(false); return; }
      if (form.password.length < 4) { setAuthError('Le mot de passe doit contenir au moins 4 caractères'); setLoading(false); return; }
      if (form.password !== form.confirmPassword) { setAuthError('Les mots de passe ne correspondent pas'); setLoading(false); return; }
      const err = register(form.name, form.email, form.phone, form.password);
      if (err) { setAuthError(err); setLoading(false); return; }
      // Save extra info
      const acc = useStore.getState().userAccounts.find(a => a.email.toLowerCase() === form.email.toLowerCase());
      if (acc) updateUserAccount(acc.id, { phone: form.phone });
    } else {
      if (!form.email.trim() || !form.password) { setAuthError('Remplissez email et mot de passe'); setLoading(false); return; }
      const err = loginWithPassword(form.email, form.password);
      if (err) { setAuthError(err); setLoading(false); return; }
    }
    setLoading(false);
  };

  const startEditProfile = () => {
    if (!myAccount) return;
    setProfileForm({ name: myAccount.name, phone: myAccount.phone, email: myAccount.email, address: '' });
    setEditProfile(true);
  };

  const saveProfile = () => {
    if (!myAccount || !profileForm.name) return;
    updateUserAccount(myAccount.id, { name: profileForm.name, phone: profileForm.phone, email: profileForm.email });
    // Update current session
    useStore.getState().login(profileForm.name, profileForm.email, profileForm.phone, user?.role || 'user');
    setEditProfile(false);
  };

  const handleChangePassword = () => {
    setPwError('');
    setPwSuccess('');
    if (!myAccount) return;
    if (myAccount.password !== pwForm.current) { setPwError('Mot de passe actuel incorrect'); return; }
    if (pwForm.newPw.length < 4) { setPwError('Le nouveau mot de passe doit contenir au moins 4 caractères'); return; }
    if (pwForm.newPw !== pwForm.confirm) { setPwError('Les nouveaux mots de passe ne correspondent pas'); return; }
    updateUserAccount(myAccount.id, { password: pwForm.newPw });
    setPwSuccess('Mot de passe modifié avec succès ✅');
    setPwForm({ current: '', newPw: '', confirm: '' });
    setTimeout(() => { setPwSuccess(''); setChangePassword(false); }, 2000);
  };

  const InputField = ({ icon, label, value, onChange, placeholder, type = 'text', required = false }: any) => (
    <div className="group">
      <label className={`block text-xs font-semibold mb-1.5 uppercase tracking-wider ${dm ? 'text-gray-400 group-focus-within:text-secondary' : 'text-gray-500 group-focus-within:text-secondary'} transition-colors`}>
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      <div className="relative">
        {icon && <div className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${dm ? 'text-gray-500 group-focus-within:text-secondary' : 'text-gray-400 group-focus-within:text-secondary'} transition-colors`}>{icon}</div>}
        <input type={type} value={value} onChange={onChange} placeholder={placeholder}
          className={`w-full ${icon ? 'pl-11' : 'pl-4'} pr-4 py-3 rounded-2xl border-2 text-[15px] ${dm ? 'bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500' : 'bg-gray-50 border-gray-200 text-gray-900 placeholder:text-gray-400'} focus:border-secondary focus:bg-transparent focus:outline-none focus:ring-2 focus:ring-secondary/20 transition-all`} />
      </div>
    </div>
  );

  // ===== LOGGED IN VIEW =====
  if (isLoggedIn && user) {
    return (
      <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-gray-50'} py-6`}>
        <div className="max-w-4xl mx-auto px-4">
          <PageHeader title="Mon Compte" />

          {/* Profile Header */}
          <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 md:p-6 mb-5`}>
            <div className="flex items-center gap-4">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-bold shadow-lg ${user.role === 'admin' ? 'bg-gradient-to-br from-red-500 to-orange-500' : 'bg-gradient-to-br from-primary to-accent'}`}>
                {user.name?.[0] || 'C'}
              </div>
              <div className="flex-1 min-w-0">
                <h1 className={`text-xl font-bold ${dm ? 'text-white' : 'text-gray-900'} truncate`}>{user.name}</h1>
                <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'} truncate`}>{user.email}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  {user.phone && <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'}`}>{user.phone}</p>}
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${user.role === 'admin' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                    {user.role === 'admin' ? '👑 Admin' : '👤 Client'}
                  </span>
                </div>
              </div>
              <button onClick={logout} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-red-500 hover:bg-red-50 text-sm font-medium shrink-0">
                <LogOut size={16} /><span className="hidden sm:inline">Déconnexion</span>
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
            {[
              { icon: '📦', label: 'Commandes', action: () => setPage('orders') },
              { icon: '📄', label: 'Documents', action: () => setPage('documents') },
              { icon: '✏️', label: 'Modifier profil', action: startEditProfile },
              { icon: '🔒', label: 'Mot de passe', action: () => setChangePassword(true) },
              ...(!isAdmin() ? [{ icon: '📍', label: 'Envoyer ma position', action: handleSendGPS }] : []),
              ...(isAdmin() ? [{ icon: '🔧', label: 'Administration', action: () => setPage('admin') }] : []),
            ].map(item => (
              <button key={item.label} onClick={item.action}
                className={`${dm ? 'bg-gray-800 hover:bg-gray-750' : 'bg-white hover:bg-gray-50'} rounded-xl shadow-md p-3.5 text-center transition-colors`}>
                <div className="text-2xl mb-1">{item.icon}</div>
                <div className={`font-medium text-xs ${dm ? 'text-white' : 'text-gray-900'}`}>{item.label}</div>
              </button>
            ))}
          </div>

          {/* GPS — client only */}
          {!isAdmin() && (
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-4 mb-5`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-lg">📍</div>
                  <div>
                    <h3 className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>Ma position GPS</h3>
                    <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Envoyez votre localisation à la boutique pour une livraison précise</p>
                  </div>
                </div>
                <button onClick={handleSendGPS} disabled={gpsLoading}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs shrink-0 flex items-center gap-1.5 ${gpsSent ? 'bg-green-500 text-white' : 'bg-blue-500 hover:bg-blue-600 text-white'} disabled:opacity-50`}>
                  {gpsLoading ? <><Loader2 size={14} className="animate-spin" /> Localisation...</>
                    : gpsSent ? <>✅ Envoyé !</>
                    : <>📍 Envoyer</>}
                </button>
              </div>
            </div>
          )}

          {/* Install App Button */}
          <PWAInstallButton className={`w-full mb-5 py-3 rounded-xl font-semibold text-sm justify-center ${dm ? 'bg-secondary/20 text-secondary' : 'bg-orange-50 text-secondary'}`} />

          {/* ===== EDIT PROFILE MODAL ===== */}
          {editProfile && (
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 mb-5 animate-fadeIn`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>✏️ Modifier mes informations</h3>
                <button onClick={() => setEditProfile(false)} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
              </div>
              <div className="space-y-3">
                <InputField icon={<User size={16} />} label="Nom complet" value={profileForm.name} onChange={(e: any) => setProfileForm({ ...profileForm, name: e.target.value })} placeholder="Votre nom" />
                <div className="grid grid-cols-2 gap-3">
                  <InputField icon={<Phone size={16} />} label="Téléphone" value={profileForm.phone} onChange={(e: any) => setProfileForm({ ...profileForm, phone: e.target.value })} placeholder="+241..." />
                  <InputField icon={<Mail size={16} />} label="Email" value={profileForm.email} onChange={(e: any) => setProfileForm({ ...profileForm, email: e.target.value })} placeholder="email@..." />
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <button onClick={() => setEditProfile(false)} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
                <button onClick={saveProfile} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2"><Save size={16} /> Enregistrer</button>
              </div>
            </div>
          )}

          {/* ===== CHANGE PASSWORD ===== */}
          {changePassword && (
            <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 mb-5 animate-fadeIn`}>
              <div className="flex items-center justify-between mb-4">
                <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>🔒 Changer le mot de passe</h3>
                <button onClick={() => { setChangePassword(false); setPwError(''); setPwSuccess(''); }} className={`p-1.5 rounded-lg ${dm ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}><X size={18} /></button>
              </div>
              <div className="space-y-3">
                <InputField icon={<Lock size={16} />} label="Mot de passe actuel" value={pwForm.current} onChange={(e: any) => setPwForm({ ...pwForm, current: e.target.value })} placeholder="••••••" type="password" />
                <InputField icon={<Lock size={16} />} label="Nouveau mot de passe" value={pwForm.newPw} onChange={(e: any) => setPwForm({ ...pwForm, newPw: e.target.value })} placeholder="Min 4 caractères" type="password" />
                <InputField icon={<Check size={16} />} label="Confirmer le nouveau" value={pwForm.confirm} onChange={(e: any) => setPwForm({ ...pwForm, confirm: e.target.value })} placeholder="Retapez le mot de passe" type="password" />
              </div>
              {pwError && <p className="text-red-500 text-sm mt-2 bg-red-50 p-2 rounded-lg">⚠️ {pwError}</p>}
              {pwSuccess && <p className="text-green-600 text-sm mt-2 bg-green-50 p-2 rounded-lg">{pwSuccess}</p>}
              <div className="flex gap-3 mt-4">
                <button onClick={() => setChangePassword(false)} className={`px-5 py-2.5 rounded-xl font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Annuler</button>
                <button onClick={handleChangePassword} className="flex-1 bg-secondary hover:bg-secondary-dark text-white py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2"><Lock size={16} /> Changer</button>
              </div>
            </div>
          )}

          {/* Recent Orders */}
          <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'}`}><ShoppingBag size={18} className="inline mr-2 text-secondary" />Commandes Récentes</h2>
              <button onClick={() => setPage('orders')} className="text-secondary text-sm font-medium flex items-center gap-1">Voir tout <ChevronRight size={14} /></button>
            </div>
            {(() => {
              const myOrders = orders.filter(o => isAdmin() || o.clientEmail === user.email || o.phone === user.phone);
              return myOrders.length === 0 ? (
                <div className="text-center py-6">
                  <div className="text-4xl mb-2">📦</div>
                  <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Aucune commande</p>
                  <button onClick={() => setPage('catalog')} className="mt-2 text-secondary font-medium text-sm">Parcourir le catalogue →</button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {myOrders.slice(-3).reverse().map(order => (
                    <div key={order.id} className={`p-3 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'} flex items-center gap-3`}>
                      <div className="flex-1 min-w-0">
                        <div className={`font-medium text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{order.id}</div>
                        <div className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{order.date} · {order.items.length} article(s)</div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>{order.total.toLocaleString('fr-FR')} F</div>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${order.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}>
                          {order.status === 'pending' ? 'En attente' : order.status === 'confirmed' ? 'Confirmée' : order.status === 'shipped' ? 'Expédiée' : 'Livrée'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        </div>
      </div>
    );
  }

  // ===== LOGIN / REGISTER FORM =====
  const ci = useStore.getState().companyInfo;
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoAddress, setGeoAddress] = useState('');
  const [showDelivery, setShowDelivery] = useState(false);

  const handleGeolocate = () => {
    if (!navigator.geolocation) return;
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json&accept-language=fr`);
          const d = await r.json();
          const a = d.address || {};
          setGeoAddress([a.road || a.neighbourhood, a.suburb || a.city_district, a.city || a.town].filter(Boolean).join(', ') || `GPS: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`);
        } catch { setGeoAddress(`GPS: ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`); }
        setGeoLoading(false);
      },
      () => setGeoLoading(false),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Phone validation
  const phoneClean = form.phone.replace(/[\s\-+]/g, '').replace(/^241/, '');
  const phoneValid = /^\d{8}$/.test(phoneClean);

  // Row layout: [icon 32px gap] [input field]
  const ic = `w-8 h-[48px] flex items-center justify-center shrink-0`; // icon container
  const inp = `flex-1 h-[48px] rounded-[10px] border-2 text-[14px] px-3 transition-all duration-200 focus:outline-none focus:ring-3 focus:ring-secondary/15`;
  const inpL = `bg-gray-50/80 border-gray-200 text-gray-900 placeholder:text-gray-400 focus:border-secondary focus:bg-white`;
  const inpD = `bg-gray-700/40 border-gray-600 text-white placeholder:text-gray-500 focus:border-secondary focus:bg-gray-700/60`;
  const icClr = dm ? 'text-gray-500' : 'text-gray-400';
  const lbl = `block text-[11px] font-semibold mb-1.5 pl-10 ${dm ? 'text-gray-300' : 'text-gray-600'}`;

  return (
    <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-[#f5f6fa]'} flex items-center justify-center px-4 py-8`}>
      <div className="w-full max-w-[380px] animate-fadeIn">

        {/* Logo */}
        <div className="text-center mb-6">
          <div className="w-[60px] h-[60px] bg-gradient-to-br from-secondary to-secondary-dark rounded-[16px] flex items-center justify-center mx-auto mb-3 shadow-xl shadow-secondary/25 overflow-hidden">
            {ci.logo ? <img src={ci.logo} alt="" className="w-full h-full object-contain p-1" /> : <span className="text-white font-black text-2xl">{ci.name[0]}</span>}
          </div>
          <h1 className={`text-[20px] font-black ${dm ? 'text-white' : 'text-gray-900'}`}>
            {isRegister ? 'Créer un compte' : ci.name}
          </h1>
          <p className={`text-[12px] mt-1 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
            {isRegister ? 'Rejoignez-nous et commandez en quelques clics' : 'Connectez-vous pour accéder à votre espace'}
          </p>
        </div>

        {/* Card */}
        <div className={`${dm ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-100'} rounded-[16px] shadow-xl shadow-black/5 py-5 px-4`}>
          <form onSubmit={handleSubmit} className="space-y-4">

            {isRegister && (
              <>
                {/* Nom complet */}
                <div>
                  <label className={lbl}>Nom complet <span className="text-red-400">*</span></label>
                  <div className="flex items-center gap-2">
                    <div className={`${ic} ${icClr}`}><User size={20} /></div>
                    <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Jean-Pierre Ndong"
                      className={`${inp} ${dm ? inpD : inpL}`} />
                  </div>
                </div>

                {/* Téléphone Gabon */}
                <div>
                  <label className={lbl}>Téléphone <span className="text-red-400">*</span></label>
                  <div className="flex items-center gap-2">
                    {/* Zone fixe : drapeau + indicatif */}
                    <div className={`shrink-0 h-[48px] px-2.5 rounded-[10px] flex items-center gap-1.5 border-2 ${dm ? 'bg-gray-700/60 border-gray-600' : 'bg-gray-100 border-gray-200'}`}>
                      <span className="text-lg leading-none">🇬🇦</span>
                      <span className={`text-[13px] font-bold ${dm ? 'text-gray-300' : 'text-gray-700'}`}>+241</span>
                    </div>
                    {/* Zone de saisie du numéro */}
                    <div className="flex-1 relative">
                      <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value.replace(/[^\d\s]/g, '') })} placeholder="07 12 34 56" type="tel" maxLength={11}
                        className={`${inp} w-full pr-9 ${dm ? inpD : inpL} ${form.phone && phoneValid ? '!border-green-400' : form.phone && !phoneValid ? '!border-red-300' : ''}`} />
                      {/* Bouton validation / effacement */}
                      {form.phone && (
                        <button type="button" onClick={() => !phoneValid ? setForm({ ...form, phone: '' }) : undefined}
                          className="absolute right-2 top-0 h-[48px] flex items-center">
                          {phoneValid
                            ? <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center"><Check size={12} className="text-green-600" /></div>
                            : <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center"><X size={12} className="text-red-500" /></div>
                          }
                        </button>
                      )}
                    </div>
                  </div>
                  <p className={`text-[10px] mt-1.5 pl-10 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>Format : +241 XX XX XX XX</p>
                </div>
              </>
            )}

            {/* Email */}
            <div>
              <label className={lbl}>Email <span className="text-red-400">*</span></label>
              <div className="flex items-center gap-2">
                <div className={`${ic} ${icClr}`}><Mail size={20} /></div>
                <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="votre@email.com"
                  className={`${inp} ${dm ? inpD : inpL}`} />
              </div>
            </div>

            {/* Mot de passe */}
            <div>
              <label className={lbl}>Mot de passe <span className="text-red-400">*</span></label>
              <div className="flex items-center gap-2">
                <div className={`${ic} ${icClr}`}><Lock size={20} /></div>
                <div className="flex-1 relative">
                  <input type={showPassword ? 'text' : 'password'} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder={isRegister ? 'Min 4 caractères' : '••••••••'}
                    className={`${inp} w-full pr-10 ${dm ? inpD : inpL}`} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-0 top-0 h-[48px] w-10 flex items-center justify-center ${dm ? 'text-gray-500 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              {isRegister && form.password && (
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex-1 flex gap-1 h-[5px]">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className={`flex-1 rounded-full transition-all duration-300 ${
                        form.password.length >= i * 2 ? (form.password.length >= 8 ? 'bg-green-500' : form.password.length >= 6 ? 'bg-yellow-400' : 'bg-red-400') : (dm ? 'bg-gray-700' : 'bg-gray-200')
                      }`} />
                    ))}
                  </div>
                  <span className={`text-[11px] font-bold ${form.password.length >= 8 ? 'text-green-500' : form.password.length >= 6 ? 'text-yellow-500' : form.password.length >= 4 ? 'text-red-400' : (dm ? 'text-gray-600' : 'text-gray-400')}`}>
                    {form.password.length >= 8 ? '✓ Fort' : form.password.length >= 6 ? 'Moyen' : form.password.length >= 4 ? 'Faible' : 'Trop court'}
                  </span>
                </div>
              )}
            </div>

            {/* Confirmer */}
            {isRegister && (
              <div>
                <label className={lbl}>Confirmer <span className="text-red-400">*</span></label>
                <div className="flex items-center gap-2">
                  <div className={`${ic} ${form.confirmPassword && form.password === form.confirmPassword ? 'text-green-500' : icClr}`}><Check size={20} /></div>
                  <div className="flex-1 relative">
                    <input type="password" value={form.confirmPassword} onChange={e => setForm({ ...form, confirmPassword: e.target.value })} placeholder="Retapez le mot de passe"
                      className={`${inp} w-full pr-10 ${
                        form.confirmPassword
                          ? form.password === form.confirmPassword ? `${dm ? 'bg-green-900/20 border-green-600' : 'bg-green-50/80 border-green-400'}` : `${dm ? 'bg-red-900/20 border-red-600' : 'bg-red-50/80 border-red-400'}`
                          : dm ? inpD : inpL
                      } ${dm ? 'text-white placeholder:text-gray-500' : 'placeholder:text-gray-400'}`} />
                    {form.confirmPassword && (
                      <div className="absolute right-2.5 top-0 h-[48px] flex items-center">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${form.password === form.confirmPassword ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-500'}`}>
                          {form.password === form.confirmPassword ? '✓' : '✗'}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Adresse de livraison — facultatif */}
            {isRegister && (
              <div className={`ml-10 rounded-[10px] border-2 border-dashed ${dm ? 'border-gray-600' : 'border-gray-200'} overflow-hidden`}>
                <button type="button" onClick={() => setShowDelivery(!showDelivery)}
                  className={`w-full flex items-center justify-between px-4 py-3 text-left ${dm ? 'hover:bg-gray-700/50' : 'hover:bg-gray-50'} transition-colors`}>
                  <div className="flex items-center gap-2">
                    <MapPin size={18} className={dm ? 'text-gray-400' : 'text-gray-500'} />
                    <span className={`text-[13px] font-semibold ${dm ? 'text-gray-300' : 'text-gray-600'}`}>Adresse de livraison</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${dm ? 'bg-gray-700 text-gray-400' : 'bg-gray-100 text-gray-500'}`}>Facultatif</span>
                  </div>
                  <ChevronRight size={16} className={`${dm ? 'text-gray-500' : 'text-gray-400'} transition-transform ${showDelivery ? 'rotate-90' : ''}`} />
                </button>
                {showDelivery && (
                  <div className="px-4 pb-4 space-y-3">
                    <button type="button" onClick={handleGeolocate} disabled={geoLoading}
                      className={`w-full h-[48px] rounded-[12px] border-2 flex items-center justify-center gap-2 text-[13px] font-semibold transition-all ${
                        geoAddress ? (dm ? 'border-green-700 bg-green-900/20 text-green-400' : 'border-green-300 bg-green-50 text-green-700')
                        : dm ? 'border-gray-600 text-gray-300 hover:border-secondary hover:text-secondary' : 'border-gray-200 text-gray-600 hover:border-secondary hover:text-secondary'
                      }`}>
                      {geoLoading ? <><Loader2 size={16} className="animate-spin" /> Localisation...</>
                        : geoAddress ? <><MapPin size={16} /> 📍 Position trouvée !</>
                        : <><MapPin size={16} /> 📍 Utiliser ma position actuelle</>}
                    </button>
                    {geoAddress && <p className={`text-[12px] ${dm ? 'text-green-400' : 'text-green-700'} px-1`}>✅ {geoAddress}</p>}
                    <p className={`text-[10px] ${dm ? 'text-gray-500' : 'text-gray-400'} flex items-start gap-1 px-1`}>
                      <Lock size={10} className="shrink-0 mt-0.5" />
                      Votre position ne sera utilisée que pour les livraisons et ne sera jamais partagée.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Erreur */}
            {authError && (
              <div className={`ml-10 flex items-center gap-3 p-3 rounded-[10px] ${dm ? 'bg-red-900/20 border border-red-800' : 'bg-red-50 border border-red-200'}`}>
                <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center shrink-0"><span className="text-red-500">!</span></div>
                <p className={`text-[13px] ${dm ? 'text-red-300' : 'text-red-700'}`}>{authError}</p>
              </div>
            )}

            {/* Bouton principal */}
            <button type="submit" disabled={loading}
              className="ml-10 w-[calc(100%-40px)] h-[52px] bg-gradient-to-r from-secondary to-secondary-dark hover:from-secondary-dark hover:to-secondary disabled:from-gray-300 disabled:to-gray-400 text-white rounded-[10px] font-bold text-[15px] flex items-center justify-center gap-2 shadow-lg shadow-secondary/25 hover:shadow-xl hover:shadow-secondary/30 transition-all duration-200 hover:scale-[1.01] active:scale-[0.98]">
              {loading ? <><Loader2 size={22} className="animate-spin" /> Chargement...</>
                : isRegister ? <><User size={20} /> Créer mon compte</>
                : <><Lock size={20} /> Se connecter</>}
            </button>
          </form>

          {/* Conditions */}
          {isRegister && (
            <p className={`text-[10px] text-center mt-3 leading-relaxed ml-10 ${dm ? 'text-gray-500' : 'text-gray-400'}`}>
              En créant un compte, vous acceptez nos <span className="text-secondary font-medium">conditions générales</span> et notre <span className="text-secondary font-medium">politique de confidentialité</span>.
            </p>
          )}
        </div>

        {/* Switch login/register */}
        <div className="mt-5 text-center">
          <span className={`text-[13px] ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
            {isRegister ? 'Déjà un compte ?' : 'Vous êtes nouveau ?'}
          </span>
          <button onClick={() => { const next = !isRegister; setIsRegister(next); setAuthMode(next ? 'register' : 'login'); setAuthError(''); setForm({ ...form, password: '', confirmPassword: '' }); }}
            className="text-[13px] text-secondary font-bold ml-1.5 hover:text-secondary-dark transition-colors underline underline-offset-2">
            {isRegister ? 'Se connecter' : 'Créer un compte'}
          </button>
        </div>
      </div>
    </div>
  );
};
