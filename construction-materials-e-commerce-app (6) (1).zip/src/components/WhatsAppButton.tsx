import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useStore } from '../store/useStore';

export const WhatsAppButton: React.FC = () => {
  const { companyInfo } = useStore();
  const wa = companyInfo.whatsapp || '2250700000000';

  return (
    <a
      href={`https://api.whatsapp.com/send?phone=${wa}&text=${encodeURIComponent(`Bonjour ${companyInfo.name} ! Je souhaite avoir des informations.`)}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-24 md:bottom-8 right-6 z-50 bg-[#25D366] hover:bg-[#1ebe5b] text-white p-4 rounded-full shadow-2xl transition-all hover:scale-110 animate-bounce-gentle group"
      title="Contactez-nous sur WhatsApp"
    >
      <MessageCircle size={28} />
      <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        <div className="bg-gray-900 text-white text-sm px-3 py-2 rounded-lg whitespace-nowrap shadow-lg">
          Besoin d'aide ? 💬
          <div className="absolute -bottom-1 right-4 w-2 h-2 bg-gray-900 rotate-45" />
        </div>
      </div>
      <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20" />
    </a>
  );
};
