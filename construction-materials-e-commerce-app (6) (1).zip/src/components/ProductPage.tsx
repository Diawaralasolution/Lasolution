import React, { useState } from 'react';
import { Star, ShoppingCart, Minus, Plus, Truck, Shield, RotateCcw, Check } from 'lucide-react';
import { useStore } from '../store/useStore';
import { ProductCard } from './ProductCard';
import { PageHeader } from './PageHeader';

export const ProductPage: React.FC = () => {
  const { selectedProductId, setPage, addToCart, darkMode, stockProducts, productReviews, addProductReview, user } = useStore();
  const product = stockProducts.find(p => p.id === selectedProductId);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'specs' | 'reviews'>('description');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  if (!product) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h2 className={`text-2xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Produit non trouvé</h2>
          <button onClick={() => setPage('catalog')} className="text-secondary font-medium">
            Retour au catalogue
          </button>
        </div>
      </div>
    );
  }

  const formatPrice = (price: number) => price.toLocaleString('fr-FR') + ' FCFA';

  const relatedProducts = stockProducts
    .filter((p: typeof product) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  const reviews = productReviews.filter(r => r.productId === product.id);
  const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : product.rating;

  const submitReview = () => {
    if (!reviewComment.trim()) return;
    addProductReview({
      id: 'REV-' + Date.now().toString(36).toUpperCase(),
      productId: product.id,
      userName: user?.name || 'Client',
      userEmail: user?.email || '',
      rating: reviewRating,
      comment: reviewComment.trim(),
      date: new Date().toLocaleDateString('fr-FR'),
    });
    setReviewComment('');
    setReviewRating(5);
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'} px-4 py-3`}>
        <div className="max-w-7xl mx-auto">
          <PageHeader title={product.name} subtitle={product.subcategory} />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-lg overflow-hidden`}>
          <div className="grid md:grid-cols-2 gap-0">
            {/* Images */}
            <div className="p-6 md:p-8">
              <div className="aspect-square rounded-xl overflow-hidden mb-4 bg-gray-100">
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {product.images.length > 1 && (
                <div className="flex gap-3">
                  {product.images.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImage(i)}
                      className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                        i === selectedImage ? 'border-secondary' : darkMode ? 'border-gray-600' : 'border-gray-200'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div className={`p-6 md:p-8 ${darkMode ? 'border-gray-700' : 'border-gray-100'} md:border-l`}>
              {product.badge && (
                <span className="inline-block text-xs font-bold px-3 py-1 rounded-full bg-secondary text-white mb-3">
                  {product.badge}
                </span>
              )}
              <h1 className={`text-2xl md:text-3xl font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {product.name}
              </h1>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={18} className={i < Math.floor(avgRating) ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} />
                  ))}
                </div>
                <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{avgRating.toFixed(1)}</span>
                <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>({reviews.length || product.reviews} avis)</span>
              </div>

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-baseline gap-3">
                  <span className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-primary'}`}>
                    {formatPrice(product.price)}
                  </span>
                  {product.oldPrice && (
                    <span className="text-lg text-gray-400 line-through">{formatPrice(product.oldPrice)}</span>
                  )}
                </div>
                {product.oldPrice && (
                  <span className="text-green-500 text-sm font-medium">
                    Économisez {formatPrice(product.oldPrice - product.price)}
                  </span>
                )}
              </div>

              {/* Stock */}
              <div className="flex items-center gap-2 mb-6">
                <div className={`w-3 h-3 rounded-full ${product.stock > 10 ? 'bg-green-500' : product.stock > 0 ? 'bg-amber-500' : 'bg-red-500'}`} />
                <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {product.stock > 10 ? 'En stock' : product.stock > 0 ? `Plus que ${product.stock} en stock` : 'Rupture de stock'}
                </span>
              </div>

              {/* Quantity & Add to Cart */}
              <div className="flex items-center gap-4 mb-6">
                <div className={`flex items-center rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-gray-100'} overflow-hidden`}>
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className={`p-3 ${darkMode ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-200 text-gray-600'} transition-colors`}
                  >
                    <Minus size={18} />
                  </button>
                  <span className={`px-5 font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className={`p-3 ${darkMode ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-200 text-gray-600'} transition-colors`}
                  >
                    <Plus size={18} />
                  </button>
                </div>
                <button
                  onClick={() => addToCart(product, quantity)}
                  className="flex-1 bg-secondary hover:bg-secondary-dark text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all hover:scale-[1.02] shadow-lg shadow-secondary/20"
                >
                  <ShoppingCart size={20} />
                  Ajouter au panier
                </button>
              </div>

              {/* Features */}
              <div className={`grid grid-cols-3 gap-3 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {[
                  { icon: <Truck size={18} />, text: 'Livraison rapide' },
                  { icon: <Shield size={18} />, text: 'Garantie qualité' },
                  { icon: <RotateCcw size={18} />, text: 'Retour 48h' },
                ].map(f => (
                  <div key={f.text} className={`flex flex-col items-center text-center p-3 rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-gray-50'} text-xs gap-1.5`}>
                    {f.icon}
                    {f.text}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className={`border-t ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
            <div className="flex border-b border-gray-200">
              {[
                { id: 'description' as const, label: 'Description' },
                { id: 'specs' as const, label: 'Caractéristiques' },
                { id: 'reviews' as const, label: `Avis (${reviews.length || product.reviews})` },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-6 py-4 text-sm font-medium transition-colors border-b-2 ${
                    activeTab === tab.id
                      ? 'border-secondary text-secondary'
                      : `border-transparent ${darkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            <div className="p-6 md:p-8">
              {activeTab === 'description' && (
                <p className={`leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {product.description}
                </p>
              )}
              {activeTab === 'specs' && product.specs && (
                <div className="grid md:grid-cols-2 gap-3">
                  {Object.entries(product.specs).map(([key, value]) => (
                    <div key={key} className={`flex items-center gap-3 p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <Check size={16} className="text-green-500 shrink-0" />
                      <span className={`font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{key}:</span>
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{value}</span>
                    </div>
                  ))}
                </div>
              )}
              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  <div className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-orange-50'} border ${darkMode ? 'border-gray-600' : 'border-orange-200'}`}>
                    <h4 className={`font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Laisser une appréciation</h4>
                    <div className="flex gap-1 mb-3">
                      {[1, 2, 3, 4, 5].map(n => (
                        <button key={n} onClick={() => setReviewRating(n)} className="p-1">
                          <Star size={22} className={n <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} />
                        </button>
                      ))}
                    </div>
                    <textarea value={reviewComment} onChange={e => setReviewComment(e.target.value)} rows={3}
                      placeholder="Votre avis sur ce produit..."
                      className={`w-full px-3 py-2 rounded-xl border text-sm ${darkMode ? 'bg-gray-800 border-gray-600 text-white' : 'bg-white border-orange-200'} focus:border-secondary focus:outline-none`} />
                    <button onClick={submitReview} disabled={!reviewComment.trim()}
                      className="mt-3 bg-secondary hover:bg-secondary-dark disabled:bg-gray-300 text-white px-5 py-2 rounded-xl text-sm font-semibold">
                      Envoyer mon avis
                    </button>
                  </div>

                  {reviews.length === 0 && (
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Aucun avis pour le moment. Soyez le premier à laisser une appréciation.</p>
                  )}

                  {reviews.map((review, i) => (
                    <div key={i} className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white text-xs font-bold">
                            {review.userName[0]}
                          </div>
                          <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{review.userName}</span>
                        </div>
                        <span className={`text-xs ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>{review.date}</span>
                      </div>
                      <div className="flex gap-0.5 mb-2">
                        {[...Array(5)].map((_, j) => (
                          <Star key={j} size={14} className={j < review.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} />
                        ))}
                      </div>
                      <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-12">
            <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              Produits Similaires
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
