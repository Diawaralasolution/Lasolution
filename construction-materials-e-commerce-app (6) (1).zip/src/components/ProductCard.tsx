import React from 'react';
import { ShoppingCart, Star, Minus, Plus } from 'lucide-react';
import { useStore } from '../store/useStore';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, removeFromCart, updateQuantity, cart, setPage, setSelectedProduct, darkMode } = useStore();

  const fmt = (n: number) => n.toLocaleString('fr-FR');
  const discount = product.oldPrice ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) : 0;
  const cartItem = cart.find(i => i.product.id === product.id);
  const qty = cartItem?.quantity || 0;

  const goToProduct = () => { setSelectedProduct(product.id); setPage('product'); };

  return (
    <div className={`group rounded-xl overflow-hidden ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'} border shadow-[0_6px_16px_rgba(15,45,82,0.06)] hover:shadow-[0_10px_24px_rgba(15,45,82,0.1)] transition-all duration-300 hover:-translate-y-0.5 flex flex-col`}>
      {/* Image — tappable — reduced 50% height */}
      <div className="relative overflow-hidden aspect-[5/2] cursor-pointer" onClick={goToProduct}>
        <img src={product.images[0]} alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.badge && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              product.badge === 'Promo' ? 'bg-red-500 text-white' :
              product.badge === 'Nouveau' ? 'bg-green-500 text-white' :
              product.badge === 'Best-seller' ? 'bg-blue-500 text-white' :
              'bg-secondary text-white'
            }`}>{product.badge}</span>
          )}
          {discount > 0 && !product.badge?.includes('%') && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500 text-white">-{discount}%</span>
          )}
        </div>
        {product.stock > 0 && product.stock < 10 && (
          <div className="absolute bottom-2 left-2">
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800">
              Plus que {product.stock}
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-1 flex flex-col flex-1">
        {/* Name */}
        <h3 onClick={goToProduct}
          className={`font-semibold text-[8.5px] md:text-[9px] leading-tight line-clamp-2 cursor-pointer mb-0.5 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
          {product.name}
        </h3>

        {/* Rating */}
        <div className="hidden sm:flex items-center gap-0.5 mb-0.5">
          {[...Array(5)].map((_, i) => (
            <Star key={i} size={7} className={i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} />
          ))}
          <span className={`text-[7px] ml-0.5 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>({product.reviews})</span>
        </div>

        {/* Price */}
        <div className="mb-1">
          <div className={`text-[10px] md:text-[11px] font-bold ${darkMode ? 'text-white' : 'text-primary'}`}>{fmt(product.price)} <span className="text-[7px] font-normal">FCFA</span></div>
          {product.oldPrice && (
            <div className="text-[8px] text-gray-400 line-through">{fmt(product.oldPrice)} FCFA</div>
          )}
        </div>

        {/* Add / Qty buttons */}
        <div className="mt-auto">
          {qty === 0 ? (
            <button onClick={(e) => { e.stopPropagation(); addToCart(product); }}
              className="w-full bg-gradient-to-r from-secondary to-secondary-dark hover:from-secondary-dark hover:to-secondary text-white py-0.5 rounded-md font-bold text-[8px] flex items-center justify-center gap-0.5 transition-all active:scale-95 shadow-md shadow-secondary/20">
              <ShoppingCart size={10} /> Ajouter
            </button>
          ) : (
            <div className="flex items-center justify-between">
              <div className={`flex items-center rounded-lg overflow-hidden border ${darkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-200 bg-gray-50'}`}>
                <button onClick={(e) => { e.stopPropagation(); qty === 1 ? removeFromCart(product.id) : updateQuantity(product.id, qty - 1); }}
                  className={`px-1.5 py-1 ${darkMode ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-200 text-gray-600'} active:scale-90`}>
                  <Minus size={11} />
                </button>
                <input
                  type="number"
                  min={1}
                  value={qty}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) => {
                    e.stopPropagation();
                    const value = Math.max(1, Number(e.target.value) || 1);
                    updateQuantity(product.id, value);
                  }}
                  className={`w-8 py-1 text-[10px] font-bold text-center outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${darkMode ? 'bg-gray-700 text-white' : 'bg-gray-50 text-gray-900'}`}
                />
                <button onClick={(e) => { e.stopPropagation(); updateQuantity(product.id, qty + 1); }}
                  className={`px-1.5 py-1 ${darkMode ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-200 text-gray-600'} active:scale-90`}>
                  <Plus size={11} />
                </button>
              </div>
              <span className="text-secondary font-bold text-[10px]">{fmt(product.price * qty)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
