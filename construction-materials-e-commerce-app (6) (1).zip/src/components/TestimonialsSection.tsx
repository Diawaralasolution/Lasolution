import React from 'react';
import { Star, Quote } from 'lucide-react';
import { useStore } from '../store/useStore';
import { testimonials } from '../data/products';

export const TestimonialsSection: React.FC = () => {
  const { darkMode } = useStore();

  return (
    <section className={`py-16 ${darkMode ? 'bg-gray-800' : 'bg-gradient-to-br from-primary/5 to-accent/5'}`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-3xl md:text-4xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
            Ce que disent nos <span className="text-secondary">Clients</span>
          </h2>
          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Découvrez les avis de nos clients satisfaits
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 stagger-children">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className={`${darkMode ? 'bg-gray-900' : 'bg-white'} rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 relative`}
            >
              <Quote size={32} className={`${darkMode ? 'text-gray-700' : 'text-gray-100'} absolute top-4 right-4`} />
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-2xl">
                  {t.avatar}
                </div>
                <div>
                  <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{t.name}</h4>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{t.role}</p>
                </div>
              </div>
              <div className="flex gap-0.5 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < t.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}
                  />
                ))}
              </div>
              <p className={`text-sm leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                "{t.content}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
