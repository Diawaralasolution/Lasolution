import React, { useState } from 'react';
import { Package, Clock, CheckCircle, Truck as TruckIcon, MapPin, Download, MessageCircle, Edit, Trash2, Minus, Plus, Save, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { PageHeader } from './PageHeader';
import { generateInvoiceFromOrder, openWhatsAppOrder } from '../utils/pdfGenerator';

export const OrdersPage: React.FC = () => {
  const { orders, darkMode, isAdmin, companyInfo, user, updateOrder, deleteOrder } = useStore();
  const fmt = (n: number) => n.toLocaleString('fr-FR') + ' FCFA';
  const dm = darkMode;
  const admin = isAdmin();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editItems, setEditItems] = useState<any[]>([]);
  const [editAddress, setEditAddress] = useState('');

  const handleWhatsApp = (order: any) => {
    if (admin) openWhatsAppOrder(order, order.phone);
    else openWhatsAppOrder(order, companyInfo.whatsapp);
  };

  const myOrders = admin ? orders : orders.filter(o => user && (o.clientEmail === user.email || o.phone === user.phone));

  const userCanEdit = (order: any) => !admin && order.status === 'pending';

  const startEdit = (order: any) => {
    setEditingId(order.id);
    setEditItems(JSON.parse(JSON.stringify(order.items)));
    setEditAddress(order.address);
  };

  const saveEdit = () => {
    if (!editingId) return;
    const sub = editItems.reduce((s: number, i: any) => s + (i.product?.price || 0) * (i.quantity || 1), 0);
    updateOrder(editingId, { items: editItems, address: editAddress, total: sub });
    setEditingId(null);
  };

  const handleDelete = (order: any) => {
    if (confirm(`Confirmez-vous l'annulation de la commande ${order.id} ?`)) {
      deleteOrder(order.id);
    }
  };

  const statusConfig: Record<string, { label: string; bg: string; color: string }> = {
    pending: { label: 'En attente', bg: 'bg-amber-100', color: 'text-amber-700' },
    confirmed: { label: 'Confirmée', bg: 'bg-blue-100', color: 'text-blue-700' },
    shipped: { label: 'Expédiée', bg: 'bg-purple-100', color: 'text-purple-700' },
    delivered: { label: 'Livrée', bg: 'bg-green-100', color: 'text-green-700' },
  };
  const steps = ['pending', 'confirmed', 'shipped', 'delivered'];

  return (
    <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className={`${dm ? 'bg-gray-800' : 'bg-primary'} py-5 px-4`}>
        <div className="max-w-3xl mx-auto">
          <PageHeader title="Mes Commandes" subtitle={`${myOrders.length} commande(s)`} dark />
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {myOrders.length === 0 ? (
          <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-10 text-center`}>
            <div className="text-5xl mb-3">📦</div>
            <h2 className={`text-lg font-bold mb-1 ${dm ? 'text-white' : 'text-gray-900'}`}>Aucune commande</h2>
            <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Vous n'avez pas encore passé de commande</p>
          </div>
        ) : (
          <div className="space-y-5">
            {[...myOrders].reverse().map(order => {
              const currentIdx = steps.indexOf(order.status);
              const sc = statusConfig[order.status] || statusConfig.pending;
              const isEditing = editingId === order.id;
              const canEdit = userCanEdit(order);

              return (
                <div key={order.id} className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md overflow-hidden`}>
                  {/* Header */}
                  <div className={`p-4 border-b ${dm ? 'border-gray-700' : 'border-gray-100'}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'} truncate`}>{order.id}</h3>
                        <p className={`text-xs ${dm ? 'text-gray-500' : 'text-gray-400'} mt-0.5`}>{order.date} · {order.paymentMethod}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-secondary font-bold text-sm">{fmt(order.total)}</div>
                        <span className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-semibold ${sc.bg} ${sc.color} mt-0.5`}>
                          {sc.label}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-0.5 mt-3">
                      {steps.map((step, i) => (
                        <React.Fragment key={step}>
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${i <= currentIdx ? 'bg-green-500 text-white' : dm ? 'bg-gray-700 text-gray-500' : 'bg-gray-200 text-gray-400'}`}>
                            {step === 'pending' && <Clock size={12} />}
                            {step === 'confirmed' && <CheckCircle size={12} />}
                            {step === 'shipped' && <TruckIcon size={12} />}
                            {step === 'delivered' && <Package size={12} />}
                          </div>
                          {i < steps.length - 1 && <div className={`flex-1 h-1 rounded-full ${i < currentIdx ? 'bg-green-500' : dm ? 'bg-gray-700' : 'bg-gray-200'}`} />}
                        </React.Fragment>
                      ))}
                    </div>
                  </div>

                  {/* Content: Read mode */}
                  {!isEditing && (
                    <>
                      <div className="p-4 space-y-2.5">
                        {order.items.map(item => (
                          <div key={item.product.id} className="flex items-center gap-2.5">
                            <img src={item.product.images[0]} alt="" className="w-11 h-11 rounded-lg object-cover shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className={`text-sm font-medium line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{item.product.name}</p>
                              <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{item.quantity} × {fmt(item.product.price)}</p>
                            </div>
                            <span className={`text-sm font-bold shrink-0 ${dm ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
                          </div>
                        ))}
                      </div>
                      <div className="px-4 pb-3">
                        <div className={`flex items-start gap-1.5 text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
                          <MapPin size={12} className="shrink-0 mt-0.5" />
                          <span className="break-words">{order.address}</span>
                          {order.geo && (
                            <a href={`https://www.google.com/maps?q=${order.geo.lat},${order.geo.lng}`} target="_blank" rel="noopener noreferrer"
                              className="shrink-0 text-blue-500 font-medium">📍 Carte</a>
                          )}
                        </div>
                      </div>
                    </>
                  )}

                  {/* Content: Edit mode */}
                  {isEditing && (
                    <div className="p-4 space-y-3">
                      <p className={`text-xs font-semibold ${dm ? 'text-amber-300' : 'text-amber-700'}`}>✏️ Modification en cours</p>
                      {editItems.map((item, idx) => (
                        <div key={idx} className={`flex items-center gap-2 p-2 rounded-xl ${dm ? 'bg-gray-700' : 'bg-gray-50'}`}>
                          <img src={item.product.images?.[0] || '/images/ciment.jpg'} alt="" className="w-10 h-10 rounded-lg object-cover shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className={`text-xs font-medium line-clamp-1 ${dm ? 'text-white' : 'text-gray-900'}`}>{item.product.name}</p>
                            <p className={`text-[10px] ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{fmt(item.product.price)} / u</p>
                          </div>
                          <div className={`flex items-center rounded-lg overflow-hidden border ${dm ? 'border-gray-600' : 'border-gray-200'}`}>
                            <button onClick={() => { const n = [...editItems]; n[idx] = { ...n[idx], quantity: Math.max(1, n[idx].quantity - 1) }; setEditItems(n); }}
                              className={`px-2 py-1 ${dm ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-100'}`}><Minus size={12} /></button>
                            <span className={`px-2 text-xs font-bold ${dm ? 'text-white' : 'text-gray-900'}`}>{item.quantity}</span>
                            <button onClick={() => { const n = [...editItems]; n[idx] = { ...n[idx], quantity: n[idx].quantity + 1 }; setEditItems(n); }}
                              className={`px-2 py-1 ${dm ? 'hover:bg-gray-600 text-gray-300' : 'hover:bg-gray-100'}`}><Plus size={12} /></button>
                          </div>
                          <button onClick={() => setEditItems(editItems.filter((_, i) => i !== idx))} className="text-red-400 p-1"><Trash2 size={14} /></button>
                        </div>
                      ))}
                      <div>
                        <label className={`text-xs font-medium ${dm ? 'text-gray-400' : 'text-gray-500'}`}>📍 Adresse de livraison</label>
                        <input value={editAddress} onChange={e => setEditAddress(e.target.value)}
                          className={`w-full mt-1 px-3 py-2 rounded-lg border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'}`} />
                      </div>
                      <div className={`flex justify-between font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>
                        <span>Nouveau total</span>
                        <span className="text-secondary">{fmt(editItems.reduce((s: number, i: any) => s + i.product.price * i.quantity, 0))}</span>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => setEditingId(null)} className={`flex-1 py-2 rounded-xl text-sm font-medium ${dm ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}><X size={14} className="inline mr-1" /> Annuler</button>
                        <button onClick={saveEdit} className="flex-1 py-2 rounded-xl text-sm font-semibold bg-green-500 text-white"><Save size={14} className="inline mr-1" /> Enregistrer</button>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  {!isEditing && (
                    <div className={`p-3 border-t ${dm ? 'border-gray-700 bg-gray-800/50' : 'border-gray-100 bg-gray-50'}`}>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {/* WhatsApp */}
                        <button onClick={() => handleWhatsApp(order)}
                          className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-[#25D366] hover:bg-[#1ebe5b] text-white text-xs font-semibold">
                          <MessageCircle size={13} /> {admin ? 'WA Client' : 'WhatsApp'}
                        </button>

                        {/* Proforma */}
                        <button onClick={() => generateInvoiceFromOrder(order, 'proforma')}
                          className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-xs font-semibold">
                          <Download size={13} /> Proforma
                        </button>

                        {/* Devis */}
                        <button onClick={() => generateInvoiceFromOrder(order, 'devis')}
                          className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white text-xs font-semibold">
                          <Download size={13} /> Devis
                        </button>

                        {/* Admin only: Facture */}
                        {admin && (
                          <button onClick={() => generateInvoiceFromOrder(order, 'facture')}
                            className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-green-500 hover:bg-green-600 text-white text-xs font-semibold">
                            <Download size={13} /> Facture
                          </button>
                        )}

                        {/* Client: Edit & Delete */}
                        {canEdit && (
                          <>
                            <button onClick={() => startEdit(order)}
                              className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold">
                              <Edit size={13} /> Modifier
                            </button>
                            <button onClick={() => handleDelete(order)}
                              className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-xs font-semibold">
                              <Trash2 size={13} /> Annuler
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
