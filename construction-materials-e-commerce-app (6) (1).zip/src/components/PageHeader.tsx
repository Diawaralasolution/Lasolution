import React from 'react';
import { ArrowLeft, Home } from 'lucide-react';
import { useStore } from '../store/useStore';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  dark?: boolean; // true = white text on primary bg (already styled outside)
}

export const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle, dark = false }) => {
  const { goBack, setPage, currentPage, darkMode } = useStore();

  const isHome = currentPage === 'home';

  if (isHome) return null;

  const btnClass = dark
    ? 'text-white/70 hover:text-white hover:bg-white/10'
    : darkMode
      ? 'text-gray-400 hover:text-white hover:bg-gray-700'
      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100';

  return (
    <div className="flex items-center gap-2 mb-3">
      {/* Back button */}
      <button
        onClick={goBack}
        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${btnClass}`}
        title="Retour"
      >
        <ArrowLeft size={18} />
        <span className="hidden sm:inline">Retour</span>
      </button>

      {/* Home button */}
      <button
        onClick={() => setPage('home')}
        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${btnClass}`}
        title="Accueil"
      >
        <Home size={18} />
        <span className="hidden sm:inline">Accueil</span>
      </button>

      {/* Title inline on mobile */}
      <div className="ml-1 min-w-0">
        <h1 className={`text-lg md:text-xl font-bold truncate ${dark ? 'text-white' : darkMode ? 'text-white' : 'text-gray-900'}`}>
          {title}
        </h1>
        {subtitle && (
          <p className={`text-xs truncate ${dark ? 'text-gray-300' : darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
};
