import React, { useState } from 'react';
import { MapPin, Phone, User, CreditCard, Check, Shield, MessageCircle, Loader2, ShoppingCart } from 'lucide-react';
import { useStore, Order } from '../store/useStore';
// shipping removed from user checkout
import { openWhatsAppOrder } from '../utils/pdfGenerator';
import { PageHeader } from './PageHeader';
import { initCinetPayPayment, isCinetPayConfigured } from '../lib/cinetpay';

export const CheckoutPage: React.FC = () => {
  const { cart, getCartTotal, setPage, clearCart, addOrder, darkMode, user, isLoggedIn, setAuthMode } = useStore();
  const [step, setStep] = useState(isLoggedIn ? 1 : 0); // 0 = auth gate
  const [form, setForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    address: '',
    city: 'Port-Gentil',
    commune: 'Port-Gentil',
    paymentMethod: '',
    shippingZone: '',
  });
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState('');
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoCoords, setGeoCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [geoError, setGeoError] = useState('');

  const handleGeolocate = () => {
    if (!navigator.geolocation) {
      setGeoError('Géolocalisation non supportée par votre navigateur');
      return;
    }
    setGeoLoading(true);
    setGeoError('');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        setGeoCoords({ lat: latitude, lng: longitude });
        try {
          const resp = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&accept-language=fr`);
          const data = await resp.json();
          if (data.address) {
            const a = data.address;
            const road = a.road || a.pedestrian || a.neighbourhood || '';
            const suburb = a.suburb || a.city_district || a.village || '';
            const city = a.city || a.town || a.state || '';
            setForm(f => ({
              ...f,
              address: [road, suburb].filter(Boolean).join(', ') || data.display_name?.split(',').slice(0, 2).join(',') || '',
              commune: 'Port-Gentil',
              city: city || f.city,
            }));
          }
        } catch {
          setForm(f => ({ ...f, address: `GPS: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}` }));
        }
        setGeoLoading(false);
      },
      (err) => {
        setGeoLoading(false);
        if (err.code === 1) setGeoError('Accès à la localisation refusé. Veuillez autoriser dans les paramètres.');
        else if (err.code === 2) setGeoError('Position indisponible. Vérifiez votre GPS.');
        else setGeoError('Délai d\'attente dépassé. Réessayez.');
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  const subtotal = getCartTotal();
  const shipping = 0;
  const finalTotal = subtotal;

  const fmt = (n: number) => n.toLocaleString('fr-FR') + ' FCFA';

  const { companyInfo: ci } = useStore();
  const paymentMethods = (ci.customPaymentMethods || []).filter(m => m.enabled);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  const clientInfo = { name: form.name, phone: form.phone, email: form.email, address: `${form.address}, ${form.commune || 'Port-Gentil'}, ${form.city}` };



  const handleSubmit = async () => {
    const selectedMethod = paymentMethods.find(p => p.id === form.paymentMethod);
    const isOnlinePayment = selectedMethod?.online === true;

    // Si paiement en ligne → lancer CinetPay
    if (isOnlinePayment) {
      setPaymentLoading(true);
      setPaymentError('');
      try {
        const result = await initCinetPayPayment({
          amount: finalTotal,
          orderId: 'CMD-' + Date.now().toString(36).toUpperCase(),
          customerName: form.name,
          customerPhone: form.phone,
          customerEmail: form.email,
          description: `Commande ${ci.name || 'boutique'} - ${cart.length} article(s)`,
        });
        if (result !== 'SUCCESS') {
          setPaymentError('Le paiement est en attente de confirmation');
        }
      } catch (err: any) {
        setPaymentLoading(false);
        setPaymentError(err.message || 'Paiement échoué');
        return;
      }
      setPaymentLoading(false);
    }

    const orderId = 'CMD-' + Date.now().toString(36).toUpperCase();
    const orderData: Order = {
      id: orderId,
      items: [...cart],
      total: finalTotal,
      shipping,
      shippingZone: '',
      tvaRate: 0,
      tvaAmount: 0,
      discountType: 'amount',
      discountValue: 0,
      discountAmount: 0,
      depositType: 'amount',
      depositValue: 0,
      depositAmount: 0,
      status: 'pending',
      date: new Date().toLocaleDateString('fr-FR'),
      paymentMethod: paymentMethods.find(p => p.id === form.paymentMethod)?.name || '',
      address: clientInfo.address,
      phone: form.phone,
      clientName: form.name,
      clientEmail: form.email,
      geo: geoCoords ? { lat: geoCoords.lat, lng: geoCoords.lng } : undefined,
    };
    addOrder(orderData);
    clearCart();
    setPlacedOrderId(orderId);
    setPlacedOrder(orderData);
    setOrderPlaced(true);
  };

  // ===== ORDER PLACED =====
  if (orderPlaced && placedOrder) {
    return (
      <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'} flex items-center justify-center p-4`}>
        <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-xl p-6 md:p-10 max-w-md w-full animate-fadeIn`}>
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check size={32} className="text-green-500" />
            </div>
            <h1 className={`text-xl md:text-2xl font-bold mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Commande Confirmée ! 🎉</h1>
            <p className="text-secondary font-mono font-bold">{placedOrderId}</p>
          </div>

          {/* Order summary */}
          <div className={`rounded-xl p-4 mb-4 text-sm space-y-1.5 ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
            {placedOrder.items.map(item => (
              <div key={item.product.id} className="flex justify-between">
                <span className={`${darkMode ? 'text-gray-300' : 'text-gray-600'} truncate mr-2`}>{item.product.name} ×{item.quantity}</span>
                <span className={`font-medium shrink-0 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
              </div>
            ))}
            <div className={`border-t pt-1.5 mt-1.5 ${darkMode ? 'border-gray-600' : 'border-gray-200'}`} />
            <div className={`flex justify-between font-bold text-base pt-1.5 border-t ${darkMode ? 'border-gray-600 text-white' : 'border-gray-200 text-gray-900'}`}>
              <span>Total</span>
              <span className="text-secondary">{fmt(placedOrder.total)}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-2.5">
            {/* WhatsApp — primary action */}
            <button
              onClick={() => openWhatsAppOrder(placedOrder, ci.whatsapp)}
              className="w-full bg-[#25D366] hover:bg-[#1ebe5b] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm transition-colors shadow-lg shadow-green-500/20"
            >
              <MessageCircle size={18} />
              Envoyer à la boutique par WhatsApp
            </button>

            {/* Navigation */}
            <div className="flex gap-2.5 pt-1">
              <button onClick={() => setPage('orders')} className="flex-1 bg-primary hover:bg-primary-light text-white py-2.5 rounded-xl font-semibold text-sm">Mes commandes</button>
              <button onClick={() => setPage('home')} className="flex-1 bg-secondary hover:bg-secondary-dark text-white py-2.5 rounded-xl font-semibold text-sm">Accueil</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ===== EMPTY CART =====
  if (cart.length === 0) {
    return (
      <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'} flex items-center justify-center p-4`}>
        <div className="text-center">
          <div className="text-6xl mb-4">🛒</div>
          <h2 className={`text-2xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Panier vide</h2>
          <button onClick={() => setPage('catalog')} className="bg-secondary text-white px-6 py-3 rounded-xl font-semibold mt-2">Voir le catalogue</button>
        </div>
      </div>
    );
  }

  // ===== STEP 0: AUTH GATE — Premium Design =====
  if (step === 0 && !isLoggedIn) {
    const dm = darkMode;
    const total = getCartTotal();
    return (
      <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-[#f5f6fa]'} flex items-center justify-center px-4 py-8`}>
        <div className="w-full max-w-[420px] animate-fadeIn">

          {/* Card */}
          <div className={`${dm ? 'bg-gray-800 border border-gray-700' : 'bg-white'} rounded-[24px] shadow-2xl shadow-black/8 overflow-hidden`}>

            {/* Top gradient strip */}
            <div className="h-1.5 bg-gradient-to-r from-secondary via-orange-400 to-secondary-dark" />

            <div className="px-6 pt-7 pb-6">
              {/* Icon */}
              <div className="flex justify-center mb-5">
                <div className="w-[72px] h-[72px] bg-gradient-to-br from-secondary to-orange-600 rounded-[20px] flex items-center justify-center shadow-xl shadow-secondary/30">
                  <ShoppingCart size={32} className="text-white" />
                </div>
              </div>

              {/* Title */}
              <h1 className={`text-[22px] font-black text-center ${dm ? 'text-white' : 'text-gray-900'}`}>
                Finaliser la commande
              </h1>

              {/* Badge articles + total */}
              <div className="flex justify-center mt-3 mb-7">
                <div className={`inline-flex items-center gap-2 px-5 py-2 rounded-full ${dm ? 'bg-gray-700' : 'bg-gray-100'}`}>
                  <span className={`text-sm font-semibold ${dm ? 'text-gray-300' : 'text-gray-600'}`}>{cart.length} article{cart.length > 1 ? 's' : ''}</span>
                  <div className={`w-1 h-1 rounded-full ${dm ? 'bg-gray-500' : 'bg-gray-400'}`} />
                  <span className="text-sm font-black text-secondary">{fmt(total)}</span>
                </div>
              </div>

              {/* Buttons */}
              <div className="space-y-3">
                {/* Primary — Commander maintenant */}
                <button onClick={() => setStep(1)}
                  className="w-full h-[54px] bg-gradient-to-r from-[#ff6b00] to-[#ff8533] hover:from-[#e86000] hover:to-[#ff6b00] text-white rounded-[14px] font-bold text-[15px] flex items-center justify-center gap-2.5 shadow-lg shadow-orange-500/25 hover:shadow-xl hover:shadow-orange-500/30 transition-all duration-200 active:scale-[0.98]">
                  <ShoppingCart size={20} />
                  Commander maintenant
                </button>

                {/* Secondary — Se connecter */}
                <button onClick={() => { setAuthMode('login'); setPage('account'); }}
                  className={`w-full h-[50px] rounded-[14px] font-semibold text-[14px] flex items-center justify-center gap-2 border-2 transition-all duration-200 ${dm ? 'border-[#ff6b00] text-[#ff6b00] hover:bg-[#ff6b00]/10' : 'border-[#ff6b00] text-[#ff6b00] bg-white hover:bg-orange-50'}`}>
                  <User size={18} />
                  Se connecter
                </button>

                {/* Tertiary — Créer un compte */}
                <button onClick={() => { setAuthMode('register'); setPage('account'); }}
                  className={`w-full h-[50px] rounded-[14px] font-semibold text-[14px] flex items-center justify-center gap-2 transition-all duration-200 ${dm ? 'bg-gray-700 text-gray-200 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                  <User size={18} />
                  Créer un compte
                </button>
              </div>

              {/* Info text */}
              <p className={`text-[11px] text-center mt-5 leading-relaxed ${dm ? 'text-gray-500' : 'text-gray-400'}`}>
                Créez un compte pour suivre vos commandes, consulter votre historique et commander plus rapidement.
              </p>
            </div>

            {/* Trust badges */}
            <div className={`px-6 py-4 ${dm ? 'bg-gray-700/50 border-t border-gray-700' : 'bg-gray-50 border-t border-gray-100'}`}>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: '🔒', label: 'Paiement sécurisé' },
                  { icon: '🚚', label: 'Livraison rapide' },
                  { icon: '🛡️', label: 'Données protégées' },
                ].map(g => (
                  <div key={g.label} className="text-center">
                    <div className="text-lg mb-0.5">{g.icon}</div>
                    <p className={`text-[9px] font-medium leading-tight ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{g.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Back to cart */}
          <button onClick={() => setPage('home')}
            className={`w-full mt-4 py-2.5 text-center text-[13px] font-medium ${dm ? 'text-gray-400 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700'} transition-colors`}>
            ← Continuer mes achats
          </button>
        </div>
      </div>
    );
  }

  // ===== CHECKOUT STEPS =====
  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`${darkMode ? 'bg-gray-800' : 'bg-primary'} py-5`}>
        <div className="max-w-5xl mx-auto px-4">
          <PageHeader title="Finaliser la commande" dark />
          <div className="flex items-center gap-2 mt-5">
            {['Livraison', 'Paiement', 'Confirmation'].map((label, i) => (
              <React.Fragment key={label}>
                <div className={`flex items-center gap-1.5 ${step > i ? 'text-white' : step === i + 1 ? 'text-white' : 'text-white/40'}`}>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${step > i + 1 ? 'bg-green-500' : step === i + 1 ? 'bg-secondary' : 'bg-white/20'}`}>
                    {step > i + 1 ? <Check size={14} /> : i + 1}
                  </div>
                  <span className="text-xs font-medium hidden sm:inline">{label}</span>
                </div>
                {i < 2 && <div className={`flex-1 h-0.5 ${step > i + 1 ? 'bg-green-500' : 'bg-white/20'}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* STEP 1 */}
            {step === 1 && (
              <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6 animate-fadeIn`}>
                <h2 className={`text-xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  <User size={20} className="inline mr-2 text-secondary" /> Informations
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { label: 'Nom complet *', value: form.name, key: 'name', ph: 'Votre nom', icon: <User size={14} className="inline mr-1" /> },
                    { label: 'Téléphone *', value: form.phone, key: 'phone', ph: '+241 07 XX XX XX', icon: <Phone size={14} className="inline mr-1" /> },
                  ].map(f => (
                    <div key={f.key}>
                      <label className={`block text-sm font-medium mb-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{f.icon}{f.label}</label>
                      <input value={f.value} onChange={e => setForm({ ...form, [f.key]: e.target.value })} placeholder={f.ph}
                        className={`w-full px-4 py-2.5 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                    </div>
                  ))}
                  <div className="md:col-span-2">
                    <label className={`block text-sm font-medium mb-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Email</label>
                    <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="email@exemple.com"
                      className={`w-full px-4 py-2.5 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Ville *</label>
                    <select value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}
                      className={`w-full px-4 py-2.5 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`}>
                      {['Port-Gentil', 'Libreville', 'Franceville', 'Lambaréné', 'Oyem', 'Mouila', 'Tchibanga', 'Makokou', 'Koulamoutou'].map(c => <option key={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Commune *</label>
                    <input value={form.commune || 'Port-Gentil'} readOnly placeholder="Port-Gentil"
                      className={`w-full px-4 py-2.5 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-100 border-gray-200 text-gray-700'} cursor-not-allowed`} />
                  </div>
                  <div className="md:col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className={`block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}><MapPin size={14} className="inline mr-1" /> Adresse *</label>
                      <button type="button" onClick={handleGeolocate} disabled={geoLoading}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${geoLoading ? 'opacity-50 cursor-wait' : ''} ${geoCoords ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}>
                        {geoLoading ? (
                          <><span className="animate-spin">⏳</span> Localisation...</>
                        ) : geoCoords ? (
                          <><MapPin size={12} /> 📍 Localisé !</>
                        ) : (
                          <><MapPin size={12} /> 📍 Ma position</>
                        )}
                      </button>
                    </div>
                    <textarea value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} placeholder="Rue, quartier, repère..." rows={2}
                      className={`w-full px-4 py-2.5 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-200'} focus:border-secondary focus:outline-none`} />
                    {geoCoords && (
                      <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                        ✅ GPS: {geoCoords.lat.toFixed(5)}, {geoCoords.lng.toFixed(5)} — Adresse auto-remplie
                      </p>
                    )}
                    {geoError && (
                      <p className="text-xs text-red-500 mt-1">⚠️ {geoError}</p>
                    )}
                  </div>
                </div>
                <button onClick={() => setStep(2)} disabled={!form.name || !form.phone || !form.address || !form.commune}
                  className="mt-6 w-full bg-secondary hover:bg-secondary-dark disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 rounded-xl font-semibold">
                  Continuer → Paiement
                </button>
              </div>
            )}

            {/* STEP 2: Payment */}
            {step === 2 && (
              <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6 animate-fadeIn`}>
                <h2 className={`text-xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  <CreditCard size={20} className="inline mr-2 text-secondary" /> Paiement
                </h2>
                <div className="space-y-2 mb-6">
                  {paymentMethods.map(m => (
                    <button key={m.id} onClick={() => setForm({ ...form, paymentMethod: m.id })}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all ${form.paymentMethod === m.id ? 'border-secondary bg-secondary/5' : darkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-200'}`}>
                      <span className="text-2xl">{m.icon}</span>
                      <div className="text-left flex-1">
                        <div className={`font-semibold text-sm ${darkMode ? 'text-white' : 'text-gray-900'}`}>{m.name}</div>
                        <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{m.desc}</div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${form.paymentMethod === m.id ? 'border-secondary' : 'border-gray-300'}`}>
                        {form.paymentMethod === m.id && <div className="w-2.5 h-2.5 rounded-full bg-secondary" />}
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className={`px-5 py-3 rounded-xl font-medium ${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Retour</button>
                  <button onClick={() => setStep(3)} disabled={!form.paymentMethod} className="flex-1 bg-secondary hover:bg-secondary-dark disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 rounded-xl font-semibold">
                    Vérifier
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Review */}
            {step === 3 && (
              <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-6 animate-fadeIn`}>
                <h2 className={`text-xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}><Shield size={20} className="inline mr-2 text-secondary" /> Récapitulatif</h2>
                {/* Info blocks */}
                {[
                  { title: '📍 Livraison', lines: [form.name, form.phone, `${form.address}, ${form.commune}, ${form.city}`] },

                  { title: '💳 Paiement', lines: [paymentMethods.find(p => p.id === form.paymentMethod)?.name || ''] },
                ].map(block => (
                  <div key={block.title} className={`p-3 rounded-xl mb-3 ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <h4 className={`font-semibold text-sm mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{block.title}</h4>
                    {block.lines.map((l, i) => <p key={i} className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{l}</p>)}
                  </div>
                ))}
                {/* Items */}
                <div className={`p-3 rounded-xl mb-4 ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <h4 className={`font-semibold text-sm mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>📦 Articles ({cart.length})</h4>
                  {cart.map(item => (
                    <div key={item.product.id} className="flex justify-between text-sm py-0.5">
                      <span className={darkMode ? 'text-gray-300' : 'text-gray-600'}>{item.product.name} × {item.quantity}</span>
                      <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
                {paymentError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 mb-3">
                    <p className="text-sm text-red-700">⚠️ {paymentError}</p>
                  </div>
                )}
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} disabled={paymentLoading} className={`px-5 py-3 rounded-xl font-medium ${darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'}`}>Retour</button>
                  <button onClick={handleSubmit} disabled={paymentLoading}
                    className="flex-1 bg-green-500 hover:bg-green-600 disabled:bg-gray-300 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
                    {paymentLoading ? (
                      <><Loader2 size={18} className="animate-spin" /> Paiement en cours...</>
                    ) : (
                      <><Check size={18} /> Confirmer — {fmt(finalTotal)}</>
                    )}
                  </button>
                </div>
                {!isCinetPayConfigured && paymentMethods.find(p => p.id === form.paymentMethod)?.online && (
                  <p className={`text-xs mt-2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                    🔧 Mode démo — CinetPay sera simulé. Configurez vos clés API pour les vrais paiements.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-md p-5 sticky top-32`}>
              <h3 className={`font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Résumé</h3>
              <div className="space-y-2 mb-4">
                {cart.map(item => (
                  <div key={item.product.id} className="flex items-center gap-2">
                    <img src={item.product.images[0]} alt="" className="w-10 h-10 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-medium line-clamp-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{item.product.name}</p>
                      <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>×{item.quantity}</p>
                    </div>
                    <span className={`text-xs font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{fmt(item.product.price * item.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className={`border-t ${darkMode ? 'border-gray-700' : 'border-gray-200'} pt-3 space-y-1.5`}>
                <div className="flex justify-between text-sm">
                  <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Sous-total</span>
                  <span className={darkMode ? 'text-white' : 'text-gray-900'}>{fmt(subtotal)}</span>
                </div>
                <div className={`flex justify-between font-bold text-lg pt-2 border-t ${darkMode ? 'border-gray-700 text-white' : 'border-gray-200 text-gray-900'}`}>
                  <span>Total</span>
                  <span className="text-secondary">{fmt(finalTotal)}</span>
                </div>
              </div>


            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
