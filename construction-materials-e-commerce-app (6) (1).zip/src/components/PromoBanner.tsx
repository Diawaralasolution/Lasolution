import React from 'react';
import { ArrowRight } from 'lucide-react';
import { useStore } from '../store/useStore';

export const PromoBanner: React.FC = () => {
  const { setPage, setSelectedCategory, darkMode } = useStore();

  return (
    <section className={`${darkMode ? 'bg-gray-900' : 'bg-gray-50'} py-8 md:py-12`}>
      <div className="max-w-7xl mx-auto px-4">
        <div
          onClick={() => { setSelectedCategory('promo'); setPage('catalog'); }}
          className="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-secondary via-[#ff8d26] to-secondary-dark min-h-[220px] md:min-h-[300px] flex items-center cursor-pointer shadow-[0_24px_70px_rgba(255,122,0,0.25)] group"
        >
          <div className="absolute inset-0 opacity-15" style={{ backgroundImage: 'radial-gradient(circle at 30px 30px, white 2px, transparent 0)', backgroundSize: '54px 54px' }} />
          <div className="absolute -right-10 -top-10 w-72 h-72 bg-white/20 rounded-full blur-3xl" />
          <img
            src="/images/ciment.jpg"
            alt="Matériaux en promotion"
            className="absolute right-0 bottom-0 h-full w-1/2 object-cover opacity-25 md:opacity-45 transition-transform duration-700 group-hover:scale-105"
          />
          <div className="relative z-10 p-7 md:p-10 max-w-xl">
            <span className="inline-flex items-center px-4 py-2 rounded-full bg-white text-secondary text-sm font-black shadow-lg mb-4">
              -15 %
            </span>
            <h3 className="text-2xl md:text-5xl font-black text-white leading-tight mb-3">
              Promotions sur vos matériaux essentiels
            </h3>
            <p className="text-white/90 text-sm md:text-base mb-6 max-w-md">
              Profitez des meilleures offres sur ciment, électricité, plomberie, quincaillerie et finitions.
            </p>
            <button className="inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-2xl font-bold shadow-xl transition-all group-hover:translate-x-1">
              J'en profite <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};