import React from 'react';
import { MapPin, Phone, Mail, Clock, ArrowRight } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Footer: React.FC = () => {
  const { darkMode, setPage, setSelectedCategory, setAuthMode, companyInfo: c } = useStore();

  const socials = [
    { link: c.facebook, icon: '📘' },
    { link: c.instagram, icon: '📸' },
    { link: c.tiktok, icon: '🎵' },
    { link: c.linkedin, icon: '💼' },
    { link: c.twitter, icon: '🐦' },
  ].filter(s => s.link);

  const enabledPayments = (c.customPaymentMethods || []).filter(m => m.enabled);

  return (
    <footer className={`${darkMode ? 'bg-gray-800' : 'bg-primary-dark'} text-white`}>
      {/* Newsletter */}
      <div className="bg-gradient-to-r from-secondary to-secondary-dark">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl font-bold text-white">Restez informé de nos offres</h3>
              <p className="text-white/80 mt-1">Recevez nos promotions et nouveautés par email</p>
            </div>
            <button
              onClick={() => { setAuthMode('register'); setPage('account'); }}
              className="w-full md:w-auto bg-green-500 hover:bg-green-600 text-white px-8 py-3.5 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-green-500/20 transition-all hover:scale-[1.02]"
            >
              Créer votre compte <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {/* About */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              {c.logo ? (
                <img src={c.logo} alt={c.name} className="w-10 h-10 rounded-xl object-contain" />
              ) : (
                <div className="w-10 h-10 bg-gradient-to-br from-secondary to-accent rounded-xl flex items-center justify-center text-white font-bold text-lg">{c.name[0]}</div>
              )}
              <div>
                <h3 className="text-lg font-bold">{c.name}</h3>
                <p className="text-xs text-gray-400">{c.slogan}</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">{c.description}</p>
            {socials.length > 0 && (
              <div className="flex gap-3">
                {socials.map((s, i) => (
                  <a key={i} href={s.link} target="_blank" rel="noopener noreferrer" className="w-9 h-9 bg-white/10 hover:bg-secondary rounded-lg flex items-center justify-center text-lg">{s.icon}</a>
                ))}
              </div>
            )}
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-semibold mb-4 text-white">Catégories</h4>
            <ul className="space-y-2">
              {['Construction', 'Plomberie', 'Électricité', 'Quincaillerie', 'Outillage', 'Peinture'].map(cat => (
                <li key={cat}><button onClick={() => { setSelectedCategory(cat.toLowerCase()); setPage('catalog'); }} className="text-gray-400 hover:text-secondary text-sm">{cat}</button></li>
              ))}
            </ul>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold mb-4 text-white">Informations</h4>
            <ul className="space-y-2">
              {['À propos', 'Livraison', 'Retours', 'CGV', 'Confidentialité', 'FAQ'].map(link => (
                <li key={link}><a href="#" className="text-gray-400 hover:text-secondary text-sm">{link}</a></li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4 text-white">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-gray-400"><MapPin size={16} className="shrink-0 mt-0.5" /> {c.address}, {c.city}, {c.country}</li>
              <li className="flex items-center gap-2 text-sm text-gray-400"><Phone size={16} className="shrink-0" /> {c.phone}</li>
              <li className="flex items-center gap-2 text-sm text-gray-400"><Mail size={16} className="shrink-0" /> {c.email}</li>
              <li className="flex items-center gap-2 text-sm text-gray-400"><Clock size={16} className="shrink-0" /> {c.hours}</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className={`border-t ${darkMode ? 'border-gray-700' : 'border-white/10'}`}>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 flex-wrap justify-center">
            <span className="text-sm text-gray-400">Paiements acceptés :</span>
            {enabledPayments.map(m => (
              <span key={m.id} className="text-xs bg-white/10 px-3 py-1.5 rounded-full text-gray-300">{m.icon} {m.name}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className={`border-t ${darkMode ? 'border-gray-700' : 'border-white/10'} py-4`}>
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} {c.name}. Tous droits réservés. {c.country && `Fait avec ❤️ au ${c.country}`} {c.country === 'Gabon' ? '🇬🇦' : c.country === "Côte d'Ivoire" ? '🇨🇮' : '🌍'}
        </div>
      </div>
    </footer>
  );
};
