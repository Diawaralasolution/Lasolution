import React, { useState } from 'react';
import { ShoppingCart, Search, Menu, X, User, Moon, Sun, Phone, MapPin, Clock } from 'lucide-react';
import { useStore } from '../store/useStore';
import { PWAInstallButton } from './PWAInstall';

export const Header: React.FC = () => {
  const {
    currentPage, setPage, getCartCount, searchQuery, setSearchQuery,
    darkMode, toggleDarkMode, showMobileMenu, setShowMobileMenu, setShowCart,
    isLoggedIn, user, setSelectedCategory, companyInfo: c, isAdmin
  } = useStore();
  const [showSearch, setShowSearch] = useState(false);
  const cartCount = getCartCount();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) { setSelectedCategory('all'); setPage('catalog'); }
  };

  const navItems = [
    { label: 'Accueil', page: 'home' as const },
    { label: 'Catalogue', page: 'catalog' as const },
    { label: 'Promotions', page: 'catalog' as const, action: () => setSelectedCategory('promo') },
    { label: 'Technicien', page: 'technicians' as const },
    { label: 'Documents', page: 'documents' as const },
    { label: 'Contact', page: 'home' as const },
  ];

  return (
    <header className={`sticky top-0 z-50 ${darkMode ? 'bg-gray-900/95' : 'bg-white/95'} backdrop-blur-xl shadow-[0_8px_30px_rgba(15,45,82,0.08)]`}>
      {/* Top Bar — hidden on mobile */}
      <div className="bg-primary text-white text-xs hidden md:block">
        <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Phone size={12} /> {c.phone}</span>
            <span className="flex items-center gap-1"><MapPin size={12} /> {c.city}, {c.country}</span>
            <span className="flex items-center gap-1"><Clock size={12} /> {c.hours}</span>
          </div>
          <span>{c.topBarText || 'Livraison gratuite dès 150 000 FCFA'} {c.country === 'Gabon' ? '🇬🇦' : c.country === "Côte d'Ivoire" ? '🇨🇮' : '🌍'}</span>
        </div>
      </div>

      {/* Main Header — taller on mobile */}
      <div className={`${darkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100'} border-b`}>
        <div className="max-w-7xl mx-auto px-3 md:px-5 h-[74px] md:h-[82px] flex items-center justify-between gap-3 md:gap-5">
          {/* Logo */}
          <button onClick={() => setPage('home')} className="flex items-center gap-2.5 shrink-0">
            {c.logo ? (
              <img src={c.logo} alt={c.name} className="w-[52px] h-[52px] md:w-14 md:h-14 rounded-2xl object-contain shadow-lg" />
            ) : (
              <div className="w-[52px] h-[52px] md:w-14 md:h-14 bg-gradient-to-br from-primary to-primary-light rounded-2xl flex items-center justify-center text-white font-bold text-2xl md:text-xl shadow-lg">
                {c.name[0]}
              </div>
            )}
            <div className="hidden sm:block">
              <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-primary'} leading-none`}>
                {c.name}
              </h1>
              <p className={`text-[10px] ${darkMode ? 'text-gray-400' : 'text-gray-500'} leading-none`}>{c.slogan}</p>
            </div>
          </button>

          {/* Search Bar — Desktop only */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-2xl mx-auto">
            <div className="relative w-full">
              <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher des produits..."
                className={`w-full pl-5 pr-14 py-3.5 rounded-2xl border-2 shadow-inner ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder:text-gray-400' : 'bg-gray-50 border-gray-100 text-gray-900 placeholder:text-gray-400'} focus:border-secondary focus:bg-white focus:outline-none transition-all`} />
              <button type="submit" className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-secondary hover:bg-secondary-dark text-white p-3 rounded-xl shadow-lg shadow-orange-500/20 transition-all hover:scale-105">
                <Search size={18} />
              </button>
            </div>
          </form>

          {/* Action Icons — bigger on mobile */}
          <div className="flex items-center gap-1 md:gap-2">
            {/* Mobile Search */}
            <button onClick={() => setShowSearch(!showSearch)}
              className={`md:hidden p-2.5 rounded-2xl ${darkMode ? 'text-gray-300 hover:bg-gray-800' : 'text-primary bg-white shadow-sm hover:bg-gray-50'}`}>
              <Search size={28} />
            </button>

            {/* Dark Mode */}
            <button onClick={toggleDarkMode}
              className={`p-2.5 rounded-2xl ${darkMode ? 'text-yellow-400 hover:bg-gray-800' : 'text-primary bg-white shadow-sm hover:bg-gray-50'}`}>
              {darkMode ? <Sun size={26} className="md:w-[22px] md:h-[22px]" /> : <Moon size={26} className="md:w-[22px] md:h-[22px]" />}
            </button>

            {/* Account — desktop */}
            <button onClick={() => setPage('account')}
              className={`hidden sm:flex items-center gap-1.5 p-2.5 rounded-2xl ${darkMode ? 'text-gray-300 hover:bg-gray-800' : 'text-primary bg-white shadow-sm hover:bg-gray-50'}`}>
              <User size={22} />
              <span className="text-sm hidden lg:inline">{isLoggedIn ? user?.name?.split(' ')[0] : 'Compte'}</span>
            </button>

            {/* Cart — prominent */}
            <button onClick={() => setShowCart(true)}
              className={`relative w-12 h-12 md:w-[52px] md:h-[52px] rounded-2xl flex items-center justify-center transition-all hover:scale-105 ${darkMode ? 'bg-gray-800 text-white shadow-md' : 'bg-white text-primary shadow-[0_8px_24px_rgba(15,45,82,0.12)] border border-gray-100'}`}>
              <ShoppingCart size={28} className="md:w-[24px] md:h-[24px]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[11px] font-black min-w-[22px] h-[22px] flex items-center justify-center rounded-full shadow-lg border-2 border-white dark:border-gray-800 animate-bounce-gentle">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu */}
            <button onClick={() => setShowMobileMenu(!showMobileMenu)}
              className={`md:hidden p-2.5 rounded-2xl ${darkMode ? 'text-gray-300 hover:bg-gray-800' : 'text-primary bg-white shadow-sm hover:bg-gray-50'}`}>
              {showMobileMenu ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        {showSearch && (
          <form onSubmit={handleSearch} className="md:hidden px-3 pb-3 animate-fadeIn">
            <div className="relative">
              <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher..." autoFocus
              className={`w-full pl-4 pr-12 py-3 rounded-2xl border-2 text-base ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-100'} focus:border-secondary focus:outline-none`} />
              <button type="submit" className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-secondary text-white p-2.5 rounded-xl">
                <Search size={20} />
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Desktop Nav */}
      <nav className={`hidden md:block ${darkMode ? 'bg-gray-800' : 'bg-primary-dark'}`}>
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-1">
          {navItems.map((item) => (
            <button key={item.label} onClick={() => { if ('action' in item && item.action) item.action(); setPage(item.page); }}
              className={`px-4 py-2.5 text-sm font-medium rounded-t-lg ${currentPage === item.page ? 'text-secondary bg-white/10' : 'text-white/80 hover:text-white hover:bg-white/5'}`}>
              {item.label}
            </button>
          ))}
          {isAdmin() && (
            <button onClick={() => setPage('admin')} className="px-4 py-2.5 text-sm font-medium text-white/80 hover:text-white hover:bg-white/5 rounded-t-lg ml-auto relative">
              🔧 Admin
              {useStore.getState().newOrderCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold min-w-[18px] h-[18px] flex items-center justify-center rounded-full animate-bounce-gentle">
                  {useStore.getState().newOrderCount}
                </span>
              )}
            </button>
          )}
        </div>
      </nav>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className={`md:hidden ${darkMode ? 'bg-gray-800' : 'bg-white'} border-t ${darkMode ? 'border-gray-700' : 'border-gray-100'} animate-fadeIn`}>
          <nav className="px-3 py-2 space-y-1">
            {navItems.map((item) => (
              <button key={item.label} onClick={() => { if ('action' in item && item.action) item.action(); setPage(item.page); setShowMobileMenu(false); }}
                className={`w-full text-left px-4 py-3.5 rounded-xl text-base font-medium ${currentPage === item.page ? (darkMode ? 'bg-gray-700 text-secondary' : 'bg-orange-50 text-secondary') : (darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50')}`}>
                {item.label}
              </button>
            ))}
            <button onClick={() => { setPage('account'); setShowMobileMenu(false); }}
              className={`w-full text-left px-4 py-3.5 rounded-xl text-base font-medium ${darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'}`}>
              👤 {isLoggedIn ? 'Mon Compte' : 'Se connecter'}
            </button>
            {isAdmin() && (
              <button onClick={() => { setPage('admin'); setShowMobileMenu(false); }}
                className={`w-full text-left px-4 py-3.5 rounded-xl text-base font-medium ${darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'}`}>
                🔧 Administration
              </button>
            )}
            <PWAInstallButton className={`w-full text-left px-4 py-3.5 rounded-xl text-base font-medium text-secondary ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-orange-50'}`} />
          </nav>
        </div>
      )}
    </header>
  );
};
