import React, { useMemo, useState } from 'react';
import { MessageCircle, Phone, Search, Star, MapPin, Calendar, X } from 'lucide-react';
import { PageHeader } from './PageHeader';
import { useStore, Technician } from '../store/useStore';
import { formatGabonPhone } from '../utils/pdfGenerator';

const tradeForCategory: Record<string, string> = {
  plomberie: 'Plombier',
  electricite: 'Électricien',
  construction: 'Maçon',
  peinture: 'Peintre',
  menuiserie: 'Menuisier',
  carrelage: 'Carreleur',
};

export const TechniciansPage: React.FC = () => {
  const { darkMode: dm, companyInfo, technicians, technicianReviews, addTechnicianReview, addAppointment, incrementTechnicianContact, selectedCategory, user } = useStore();
  const [search, setSearch] = useState('');
  const [trade, setTrade] = useState(selectedCategory && tradeForCategory[selectedCategory] ? tradeForCategory[selectedCategory] : 'all');
  const [city, setCity] = useState('all');
  const [availability, setAvailability] = useState('all');
  const [sort, setSort] = useState('popular');
  const [selected, setSelected] = useState<Technician | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [apptMsg, setApptMsg] = useState('');

  const activeTechs = technicians.filter(t => t.active);
  const trades = Array.from(new Set(activeTechs.map(t => t.trade))).sort();
  const cities = Array.from(new Set(activeTechs.map(t => t.city))).sort();

  const getReviews = (id: string) => technicianReviews.filter(r => r.technicianId === id);
  const avg = (id: string) => {
    const r = getReviews(id);
    return r.length ? r.reduce((s, x) => s + x.rating, 0) / r.length : 4.5;
  };

  const filtered = useMemo(() => {
    let list = [...activeTechs];
    const q = search.toLowerCase();
    if (q) list = list.filter(t => t.name.toLowerCase().includes(q) || t.trade.toLowerCase().includes(q) || t.specialties.join(' ').toLowerCase().includes(q));
    if (trade !== 'all') list = list.filter(t => t.trade === trade);
    if (city !== 'all') list = list.filter(t => t.city === city);
    if (availability !== 'all') list = list.filter(t => t.status === availability);
    if (sort === 'rating') list.sort((a, b) => avg(b.id) - avg(a.id));
    if (sort === 'popular') list.sort((a, b) => (b.contactCount || 0) - (a.contactCount || 0));
    if (sort === 'near') list.sort((a, b) => a.city.localeCompare(b.city));
    return list;
  }, [activeTechs, search, trade, city, availability, sort, technicianReviews]);

  const contact = (tech: Technician, mode: 'call' | 'wa') => {
    incrementTechnicianContact(tech.id);
    if (mode === 'call') window.location.href = `tel:${tech.phone}`;
    else {
      const msg = encodeURIComponent(`Bonjour ${tech.name}, j'ai besoin d'un technicien pour : ${tech.trade}.\nJe viens de ${companyInfo.name || 'la boutique'}.`);
      window.open(`https://api.whatsapp.com/send?phone=${formatGabonPhone(tech.whatsapp || tech.phone)}&text=${msg}`, '_blank');
    }
  };

  const sendGPS = (tech: Technician) => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const msg = encodeURIComponent(`Bonjour ${tech.name}, voici ma localisation pour une intervention :\nhttps://www.google.com/maps?q=${latitude},${longitude}`);
        window.open(`https://api.whatsapp.com/send?phone=${formatGabonPhone(tech.whatsapp || tech.phone)}&text=${msg}`, '_blank');
      },
      (err) => console.error(err),
      { enableHighAccuracy: true }
    );
  };

  const requestAppointment = (tech: Technician) => {
    addAppointment({ id: 'RDV-' + Date.now().toString(36).toUpperCase(), technicianId: tech.id, clientName: user?.name || 'Client', phone: user?.phone || '', message: apptMsg || `Demande de rendez-vous avec ${tech.name}`, date: new Date().toLocaleDateString('fr-FR'), status: 'pending' });
    setApptMsg('');
  };

  const submitReview = (tech: Technician) => {
    if (!comment.trim()) return;
    addTechnicianReview({ id: 'TREV-' + Date.now().toString(36).toUpperCase(), technicianId: tech.id, userName: user?.name || 'Client', rating, comment: comment.trim(), date: new Date().toLocaleDateString('fr-FR') });
    setComment('');
    setRating(5);
  };

  return (
    <div className={`min-h-screen ${dm ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className={`${dm ? 'bg-gray-800' : 'bg-primary'} py-5 px-4`}>
        <div className="max-w-6xl mx-auto"><PageHeader title="Techniciens" subtitle="Trouvez un professionnel pour vos travaux" dark /></div>
      </div>
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className={`${dm ? 'bg-gray-800' : 'bg-white'} rounded-3xl shadow-lg p-4 mb-5`}>
          <div className="grid md:grid-cols-5 gap-3">
            <div className="relative md:col-span-2">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Rechercher nom, métier..." className={`w-full pl-9 pr-3 py-2.5 rounded-xl border ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`} />
            </div>
            <select value={trade} onChange={e => setTrade(e.target.value)} className={`px-3 py-2.5 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`}><option value="all">Tous métiers</option>{trades.map(t => <option key={t}>{t}</option>)}</select>
            <select value={city} onChange={e => setCity(e.target.value)} className={`px-3 py-2.5 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`}><option value="all">Toutes villes</option>{cities.map(c => <option key={c}>{c}</option>)}</select>
            <select value={availability} onChange={e => setAvailability(e.target.value)} className={`px-3 py-2.5 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`}><option value="all">Disponibilité</option><option value="available">Disponible</option><option value="busy">Occupé</option></select>
          </div>
          <div className="flex justify-end mt-3">
            <select value={sort} onChange={e => setSort(e.target.value)} className={`px-3 py-2 rounded-xl border text-xs ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`}><option value="popular">Popularité</option><option value="rating">Note</option><option value="near">Proximité</option></select>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(tech => {
            const r = getReviews(tech.id);
            return (
              <div key={tech.id} className={`${dm ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'} border rounded-3xl p-5 shadow-lg hover:-translate-y-1 transition-all`}>
                <div className="flex items-start gap-4">
                  {tech.photo ? <img src={tech.photo} className="w-16 h-16 rounded-2xl object-cover" /> : <div className="w-16 h-16 rounded-2xl bg-secondary/10 flex items-center justify-center text-3xl">🛠️</div>}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className={`font-bold ${dm ? 'text-white' : 'text-gray-900'} truncate`}>{tech.name}</h3>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${tech.status === 'available' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{tech.status === 'available' ? 'Disponible' : 'Occupé'}</span>
                    </div>
                    <p className="text-secondary text-sm font-semibold">{tech.trade}</p>
                    <p className={`text-xs flex items-center gap-1 ${dm ? 'text-gray-400' : 'text-gray-500'}`}><MapPin size={12} /> {tech.city} · {tech.zone}</p>
                    <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{tech.experience} ans d'expérience</p>
                    <p className="text-xs mt-1"><span className="text-amber-400">★</span> {avg(tech.id).toFixed(1)} ({r.length} avis) · {tech.contactCount || 0} contacts</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <button onClick={() => contact(tech, 'call')} className="py-2 rounded-xl bg-gray-100 text-gray-700 text-xs font-bold flex items-center justify-center gap-1"><Phone size={13} /> Appeler</button>
                  <button onClick={() => contact(tech, 'wa')} className="py-2 rounded-xl bg-[#25D366] text-white text-xs font-bold flex items-center justify-center gap-1"><MessageCircle size={13} /> WA</button>
                  <button onClick={() => setSelected(tech)} className="py-2 rounded-xl bg-secondary text-white text-xs font-bold flex items-center justify-center gap-1"><Calendar size={13} /> RDV</button>
                </div>
                <button onClick={() => setSelected(tech)} className={`w-full mt-2 text-xs font-semibold ${dm ? 'text-gray-400' : 'text-gray-500'}`}>Voir le profil détaillé</button>
              </div>
            );
          })}
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSelected(null)} />
          <div className={`${dm ? 'bg-gray-800' : 'bg-white'} relative rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-fadeIn`}>
            <div className="flex-1 overflow-y-auto p-5">
              <button onClick={() => setSelected(null)} className="absolute right-4 top-4 p-2 rounded-xl bg-gray-100 text-gray-500"><X size={18} /></button>
              <div className="flex items-start gap-4 pr-10">
                {selected.photo ? <img src={selected.photo} className="w-20 h-20 rounded-2xl object-cover" /> : <div className="w-20 h-20 rounded-2xl bg-secondary/10 flex items-center justify-center text-4xl">🛠️</div>}
                <div>
                  <h2 className={`text-xl font-black ${dm ? 'text-white' : 'text-gray-900'}`}>{selected.name}</h2>
                  <p className="text-secondary font-semibold">{selected.trade}</p>
                  <p className={`text-sm ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{selected.description}</p>
                </div>
              </div>
              <div className="mt-5 grid sm:grid-cols-2 gap-3 text-sm">
                <div className={`${dm ? 'bg-gray-700' : 'bg-gray-50'} rounded-2xl p-3`}><b>Zone :</b> {selected.city}, {selected.zone}</div>
                <div className={`${dm ? 'bg-gray-700' : 'bg-gray-50'} rounded-2xl p-3`}><b>Horaires :</b> {selected.hours}</div>
                <div className={`${dm ? 'bg-gray-700' : 'bg-gray-50'} rounded-2xl p-3 sm:col-span-2`}><b>Spécialités :</b> {selected.specialties.join(', ')}</div>
              </div>
              {selected.gallery.length > 0 && <div className="mt-4 grid grid-cols-3 gap-2">{selected.gallery.map((g, i) => <img key={i} src={g} className="h-24 w-full object-cover rounded-xl" />)}</div>}
              <div className="mt-5">
                <h3 className={`font-bold mb-2 ${dm ? 'text-white' : 'text-gray-900'}`}>Avis clients</h3>
                {getReviews(selected.id).map(rv => <div key={rv.id} className={`${dm ? 'bg-gray-700' : 'bg-gray-50'} rounded-xl p-3 mb-2 text-sm`}><div className="text-amber-400">{'★'.repeat(rv.rating)}{'☆'.repeat(5-rv.rating)}</div><p>{rv.comment}</p><p className="text-xs text-gray-400">{rv.userName} · {rv.date}</p></div>)}
                <div className={`${dm ? 'bg-gray-700' : 'bg-orange-50'} rounded-2xl p-3 mt-3`}>
                  <div className="flex gap-1 mb-2">{[1,2,3,4,5].map(n => <button key={n} onClick={() => setRating(n)} className={n <= rating ? 'text-amber-400' : 'text-gray-300'}><Star size={20} fill="currentColor" /></button>)}</div>
                  <textarea value={comment} onChange={e => setComment(e.target.value)} placeholder="Votre avis..." rows={2} className={`w-full px-3 py-2 rounded-xl border text-sm ${dm ? 'bg-gray-800 border-gray-600 text-white' : 'bg-white border-orange-200'}`} />
                  <button onClick={() => submitReview(selected)} disabled={!comment.trim()} className="mt-2 bg-secondary text-white px-4 py-2 rounded-xl text-sm font-bold disabled:bg-gray-300">Noter</button>
                </div>
              </div>
              <textarea value={apptMsg} onChange={e => setApptMsg(e.target.value)} placeholder="Message pour le rendez-vous..." rows={2} className={`w-full mt-3 px-3 py-2 rounded-xl border text-sm ${dm ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-200'}`} />
            </div>
            
            {/* Sticky footer for buttons */}
            <div className="sticky bottom-0 mt-3 pt-3 border-t bg-white dark:bg-gray-800 grid grid-cols-4 gap-2">
              <button onClick={() => contact(selected, 'call')} className="py-2.5 rounded-xl bg-gray-100 text-gray-700 font-bold text-xs">Appeler</button>
              <button onClick={() => contact(selected, 'wa')} className="py-2.5 rounded-xl bg-[#25D366] text-white font-bold text-xs">WhatsApp</button>
              <button onClick={() => sendGPS(selected)} className="py-2.5 rounded-xl bg-blue-500 text-white font-bold text-xs">📍 GPS</button>
              <button onClick={() => requestAppointment(selected)} className="py-2.5 rounded-xl bg-secondary text-white font-bold text-xs">RDV</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};