import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone, Share, Plus } from 'lucide-react';
import { useStore } from '../store/useStore';

export const PWAInstallBanner: React.FC = () => {
  const { darkMode, isLoggedIn, companyInfo } = useStore();
  const dm = darkMode;
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as any).standalone;

  useEffect(() => {
    // Already installed as PWA
    if (isStandalone) { setInstalled(true); return; }

    // Check if dismissed recently
    const dismissedAt = localStorage.getItem('pwa-dismissed');
    if (dismissedAt && Date.now() - Number(dismissedAt) < 24 * 60 * 60 * 1000) { setDismissed(true); }

    // Listen for install prompt (Android/Desktop)
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      if (isLoggedIn && !dismissed) setShowBanner(true);
    };
    window.addEventListener('beforeinstallprompt', handler);

    // Listen for successful install
    window.addEventListener('appinstalled', () => {
      setInstalled(true);
      setShowBanner(false);
      setDeferredPrompt(null);
    });

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, [isLoggedIn, dismissed]);

  // Show banner after login — for all platforms
  useEffect(() => {
    if (isLoggedIn && !installed && !isStandalone && !dismissed) {
      const timer = setTimeout(() => {
        setShowBanner(true);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [isLoggedIn, installed]);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const result = await deferredPrompt.userChoice;
      if (result.outcome === 'accepted') { setInstalled(true); }
      setDeferredPrompt(null);
      setShowBanner(false);
    } else {
      // iOS or browser without prompt — show guide
      setShowIOSGuide(true);
    }
  };

  const handleDismiss = () => {
    setShowBanner(false);
    setDismissed(true);
    localStorage.setItem('pwa-dismissed', String(Date.now()));
  };

  if (installed || isStandalone) return null;

  return (
    <>
      {/* Floating install banner */}
      {showBanner && (
        <div className={`fixed bottom-20 left-4 right-4 z-[55] max-w-md mx-auto animate-fadeIn ${dm ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-2xl shadow-2xl border p-4`}>
          <button onClick={handleDismiss} className={`absolute top-2 right-2 p-1.5 rounded-lg ${dm ? 'text-gray-500 hover:bg-gray-700' : 'text-gray-400 hover:bg-gray-100'}`}>
            <X size={16} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-secondary to-secondary-dark rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg shrink-0 overflow-hidden">
              {companyInfo.logo ? <img src={companyInfo.logo} alt="" className="w-full h-full object-contain p-0.5" /> : companyInfo.name[0]}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>Installer {companyInfo.name}</h3>
              <p className={`text-xs ${dm ? 'text-gray-400' : 'text-gray-500'}`}>
                {isIOS ? 'Ajoutez à votre écran d\'accueil' : 'Accédez rapidement depuis votre écran'}
              </p>
            </div>
          </div>
          <button onClick={handleInstall}
            className="w-full mt-3 bg-gradient-to-r from-secondary to-secondary-dark text-white py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-secondary/20 active:scale-[0.98]">
            <Download size={16} />
            {isIOS ? 'Comment installer' : 'Installer l\'application'}
          </button>
        </div>
      )}

      {/* iOS Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowIOSGuide(false)} />
          <div className={`relative ${dm ? 'bg-gray-800' : 'bg-white'} rounded-t-3xl sm:rounded-3xl shadow-2xl w-full max-w-md p-6 animate-fadeIn max-h-[80vh] overflow-y-auto`}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4 sm:hidden" />
            <button onClick={() => setShowIOSGuide(false)} className={`absolute top-4 right-4 p-1.5 rounded-lg ${dm ? 'text-gray-500 hover:bg-gray-700' : 'text-gray-400 hover:bg-gray-100'}`}>
              <X size={18} />
            </button>

            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-secondary to-secondary-dark rounded-2xl flex items-center justify-center text-white text-2xl font-black mx-auto mb-3 shadow-xl overflow-hidden">
                {companyInfo.logo ? <img src={companyInfo.logo} alt="" className="w-full h-full object-contain p-1" /> : companyInfo.name[0]}
              </div>
              <h2 className={`text-xl font-black ${dm ? 'text-white' : 'text-gray-900'}`}>Installer l'application</h2>
              <p className={`text-sm mt-1 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{isIOS ? 'Suivez ces 3 étapes sur Safari' : 'Ajoutez le raccourci sur votre écran'}</p>
            </div>

            <div className="space-y-4">
              {(isIOS ? [
                { step: '1', icon: <Share size={22} />, title: 'Appuyez sur Partager', desc: 'En bas de Safari, appuyez sur l\'icône □↑ (carré avec flèche)', color: 'bg-blue-500' },
                { step: '2', icon: <Plus size={22} />, title: 'Sur l\'écran d\'accueil', desc: 'Faites défiler et appuyez sur "Sur l\'écran d\'accueil"', color: 'bg-green-500' },
                { step: '3', icon: <Smartphone size={22} />, title: 'Confirmez', desc: 'Appuyez sur "Ajouter" en haut à droite. C\'est fait !', color: 'bg-secondary' },
              ] : [
                { step: '1', icon: <Share size={22} />, title: 'Menu du navigateur', desc: 'Appuyez sur les 3 points ⋮ en haut à droite du navigateur', color: 'bg-blue-500' },
                { step: '2', icon: <Plus size={22} />, title: 'Installer l\'application', desc: 'Appuyez sur "Installer l\'application" ou "Ajouter à l\'écran d\'accueil"', color: 'bg-green-500' },
                { step: '3', icon: <Smartphone size={22} />, title: 'C\'est prêt !', desc: 'L\'icône apparaît sur votre écran. Ouvrez comme une vraie appli !', color: 'bg-secondary' },
              ]).map(s => (
                <div key={s.step} className="flex items-start gap-3">
                  <div className={`${s.color} w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-lg`}>{s.icon}</div>
                  <div>
                    <h4 className={`font-bold text-sm ${dm ? 'text-white' : 'text-gray-900'}`}>Étape {s.step}: {s.title}</h4>
                    <p className={`text-xs mt-0.5 ${dm ? 'text-gray-400' : 'text-gray-500'}`}>{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <button onClick={() => setShowIOSGuide(false)}
              className="w-full mt-6 bg-secondary text-white py-3 rounded-xl font-bold text-sm">
              J'ai compris ✓
            </button>
          </div>
        </div>
      )}
    </>
  );
};

// Install button for menus/pages
export const PWAInstallButton: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [prompt, setPrompt] = useState<any>(null);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (navigator as any).standalone;

  useEffect(() => {
    if (isStandalone) return;
    const handler = (e: any) => { e.preventDefault(); setPrompt(e); };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  // Hide if already installed as PWA
  if (isStandalone) return null;

  const handleClick = async () => {
    if (prompt) {
      prompt.prompt();
      await prompt.userChoice;
    } else {
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      alert(isIOS
        ? 'iPhone/iPad :\n1. Appuyez sur Partager (□↑)\n2. "Sur l\'écran d\'accueil"\n3. Ajouter'
        : 'Appuyez sur les 3 points ⋮ du navigateur → "Installer l\'application" ou "Ajouter à l\'écran d\'accueil"'
      );
    }
  };

  return (
    <button onClick={handleClick} className={`flex items-center gap-2 ${className}`}>
      <Download size={16} /> Installer l'appli
    </button>
  );
};
