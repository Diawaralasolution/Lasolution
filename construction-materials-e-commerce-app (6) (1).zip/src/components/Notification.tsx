import React from 'react';
import { CheckCircle, XCircle, Info, X } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Notification: React.FC = () => {
  const { notification, setNotification } = useStore();

  if (!notification) return null;

  const config = {
    success: { icon: <CheckCircle size={20} />, bg: 'bg-green-500', border: 'border-green-400' },
    error: { icon: <XCircle size={20} />, bg: 'bg-red-500', border: 'border-red-400' },
    info: { icon: <Info size={20} />, bg: 'bg-blue-500', border: 'border-blue-400' },
  };

  const { icon, bg } = config[notification.type];

  return (
    <div className="fixed top-20 right-4 z-[70] animate-slideInRight">
      <div className={`${bg} text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 min-w-[280px]`}>
        {icon}
        <span className="text-sm font-medium flex-1">{notification.message}</span>
        <button
          onClick={() => setNotification(null)}
          className="p-1 hover:bg-white/20 rounded-lg transition-colors"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
};
