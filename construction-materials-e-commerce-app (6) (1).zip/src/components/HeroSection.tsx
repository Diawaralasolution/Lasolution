import React from 'react';
import { ArrowRight, Truck, Shield, CreditCard, Headphones } from 'lucide-react';
import { useStore } from '../store/useStore';

export const HeroSection: React.FC = () => {
  const { setPage, darkMode, setSelectedCategory, companyInfo: c } = useStore();

  const heroImg = c.heroImage || 'https://images.pexels.com/photos/29151932/pexels-photo-29151932.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600';

  return (
    <section className={`relative overflow-hidden ${darkMode ? 'bg-gray-900' : 'bg-gray-50'} pt-5 md:pt-8`}>
      {/* Hero Banner */}
      <div className="max-w-7xl mx-auto px-4">
      <div className="relative bg-gradient-to-br from-primary via-primary-dark to-[#0c1f33] min-h-[255px] md:min-h-[357px] flex items-center rounded-[20px] overflow-hidden shadow-[0_24px_70px_rgba(15,45,82,0.28)]">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 25px 25px, white 1px, transparent 0)',
            backgroundSize: '50px 50px'
          }} />
        </div>

        {/* Floating shapes */}
        <div className="absolute top-20 right-10 w-72 h-72 bg-secondary/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-10 left-10 w-56 h-56 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />

        <div className="px-5 md:px-8 py-5 md:py-9 relative z-10 w-full">
          <div className="grid md:grid-cols-2 gap-8 md:gap-10 items-center">
            <div className="animate-fadeIn">
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white px-3 py-1.5 rounded-full text-xs md:text-sm font-medium mb-2 md:mb-4">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                {c.heroBadge || 'Livraison disponible partout'} en {c.country}
              </div>
              {/* Nom de l'entreprise */}
              <div className="flex items-center gap-3 md:gap-4 mb-2 md:mb-3">
                {c.logo ? (
                  <img src={c.logo} alt={c.name} className="w-[84px] h-[84px] md:w-[120px] md:h-[120px] rounded-2xl object-contain shadow-xl md:shadow-2xl border-2 border-white/20" />
                ) : (
                  <div className="w-[84px] h-[84px] md:w-[120px] md:h-[120px] bg-gradient-to-br from-secondary to-accent rounded-2xl flex items-center justify-center text-white font-black text-4xl md:text-6xl shadow-xl md:shadow-2xl border-2 border-white/20">
                    {c.name[0]}
                  </div>
                )}
                <div>
                  <h2 className="text-xl md:text-4xl font-black text-white tracking-tight leading-tight">{c.name}</h2>
                  <p className="text-xs md:text-lg text-gray-400 font-medium">{c.slogan}</p>
                </div>
              </div>

              <h1 className="text-lg md:text-2xl lg:text-3xl font-black text-white leading-tight mb-2 md:mb-3 max-w-full whitespace-nowrap overflow-hidden text-ellipsis">
                {c.heroTitle1 || 'Vos Matériaux de'} <span className="text-secondary">{c.heroTitle2 || 'Construction'}</span> <span className="text-accent">{c.heroTitle3 || 'en Ligne'}</span>
              </h1>
              <p className="text-sm md:text-base text-gray-300 mb-3 md:mb-4 max-w-lg leading-relaxed whitespace-normal break-words">
                {c.description}
              </p>
              <div className="flex flex-wrap gap-2 md:gap-4">
                <button
                  onClick={() => setPage('catalog')}
                  className="bg-secondary hover:bg-secondary-dark text-white px-5 py-2.5 md:px-6 md:py-3 rounded-2xl font-bold flex items-center gap-2 text-sm md:text-base transition-all hover:scale-105 shadow-lg shadow-secondary/30"
                >
                  {c.heroBtnText1 || 'Voir le Catalogue'}
                  <ArrowRight size={18} />
                </button>
                <button
                  onClick={() => { setSelectedCategory('promo'); setPage('catalog'); }}
                  className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white px-5 py-2.5 md:px-6 md:py-3 rounded-2xl font-bold text-sm md:text-base transition-all border border-white/20"
                >
                  {c.heroBtnText2 || 'Nos Promotions 🔥'}
                </button>
              </div>

              {/* Stats — hidden on very small screens */}
              <div className="hidden sm:flex gap-8 mt-6 md:mt-10">
                {[
                  { value: c.heroStat1Value || '5000+', label: c.heroStat1Label || 'Produits' },
                  { value: c.heroStat2Value || '2500+', label: c.heroStat2Label || 'Clients' },
                  { value: c.heroStat3Value || '98%', label: c.heroStat3Label || 'Satisfaction' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <div className="text-xl md:text-3xl font-bold text-white">{stat.value}</div>
                    <div className="text-xs md:text-sm text-gray-400">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Image */}
            <div className="hidden md:block relative">
              <div className="relative flex justify-center">
                <img src={heroImg} alt={c.name} className="rounded-2xl shadow-2xl w-full max-w-md mx-auto" loading="eager" />
                {/* Floating card */}
                <div className="absolute -bottom-4 -left-4 bg-white rounded-xl p-4 shadow-xl animate-bounce-gentle">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center text-2xl">✅</div>
                    <div>
                      <div className="text-sm font-bold text-gray-900">{c.heroQualityText || 'Qualité Garantie'}</div>
                      <div className="text-xs text-gray-500">{c.heroQualitySub || 'Produits certifiés'}</div>
                    </div>
                  </div>
                </div>
                {/* Price badge */}
                <div className="absolute -top-4 -right-4 bg-secondary text-white rounded-xl p-4 shadow-xl animate-pulse-glow">
                  <div className="text-xs font-medium">{c.heroPromoText || 'Jusqu\'à'}</div>
                  <div className="text-2xl font-black">{c.heroPromoPercent || '-30%'}</div>
                  <div className="text-xs">de réduction</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>

      {/* Trust Badges */}
      <div className={`${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 py-6 md:py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-5">
            {[
              { icon: <Truck size={28} />, title: c.trustBadge1Title || 'Livraison Rapide', desc: c.trustBadge1Desc || 'Partout au pays', color: 'text-blue-500 bg-blue-50' },
              { icon: <Shield size={28} />, title: c.trustBadge2Title || 'Paiement Sécurisé', desc: c.trustBadge2Desc || 'Mobile Money & Carte', color: 'text-green-500 bg-green-50' },
              { icon: <CreditCard size={28} />, title: c.trustBadge3Title || 'Prix Compétitifs', desc: c.trustBadge3Desc || 'Meilleurs prix garantis', color: 'text-orange-500 bg-orange-50' },
              { icon: <Headphones size={28} />, title: c.trustBadge4Title || 'Support 24/7', desc: c.trustBadge4Desc || 'Assistance permanente', color: 'text-purple-500 bg-purple-50' },
            ].map((badge) => (
              <div key={badge.title} className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'} flex items-center gap-3 group rounded-[22px] p-4 shadow-[0_12px_30px_rgba(15,45,82,0.08)] border hover:-translate-y-1 transition-all duration-300`}>
                <div className={`p-3 rounded-2xl ${badge.color} transition-transform group-hover:scale-110 ${darkMode ? 'bg-opacity-20' : ''}`}>
                  {badge.icon}
                </div>
                <div>
                  <div className={`font-semibold text-sm ${darkMode ? 'text-white' : 'text-gray-900'}`}>{badge.title}</div>
                  <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{badge.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
