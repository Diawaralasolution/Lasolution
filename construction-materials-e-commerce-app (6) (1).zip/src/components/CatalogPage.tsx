import React, { useMemo, useState } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { PageHeader } from './PageHeader';
// categories from store
import { ProductCard } from './ProductCard';

export const CatalogPage: React.FC = () => {
  const {
    searchQuery, selectedCategory, setSelectedCategory,
    priceRange, setPriceRange, sortBy, setSortBy, darkMode,
    stockProducts: products, customCategories: categories
  } = useStore();
  const [showFilters, setShowFilters] = useState(false);

  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.subcategory.toLowerCase().includes(q)
      );
    }

    // Promotions
    if (selectedCategory === 'promo') {
      filtered = filtered.filter(p =>
        Boolean(p.oldPrice) ||
        p.badge === 'Promo' ||
        Boolean(p.badge?.startsWith('-'))
      );
    }

    // Category
    if (selectedCategory !== 'all' && selectedCategory !== 'promo') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    // Price range
    filtered = filtered.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    // Sort
    switch (sortBy) {
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'popular':
      default:
        filtered.sort((a, b) => b.reviews - a.reviews);
        break;
    }

    return filtered;
  }, [searchQuery, selectedCategory, priceRange, sortBy]);

  const formatPrice = (price: number) => price.toLocaleString('fr-FR');

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      <div className={`${darkMode ? 'bg-gray-800' : 'bg-primary'} py-5 px-4`}>
        <div className="max-w-7xl mx-auto">
          <PageHeader
            title={selectedCategory === 'promo' ? 'Produits en promotion' : selectedCategory !== 'all' ? categories.find(c => c.id === selectedCategory)?.name || 'Catalogue' : searchQuery ? `Résultats pour "${searchQuery}"` : 'Catalogue Complet'}
            subtitle={`${filteredProducts.length} produit${filteredProducts.length > 1 ? 's' : ''} trouvé${filteredProducts.length > 1 ? 's' : ''}`}
            dark
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className={`hidden lg:block w-64 shrink-0`}>
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-6 shadow-md sticky top-32`}>
              <h3 className={`font-bold text-lg mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Filtres
              </h3>

              {/* Categories */}
              <div className="mb-6">
                <h4 className={`font-semibold mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Catégories</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedCategory === 'all'
                        ? 'bg-secondary text-white font-medium'
                        : darkMode ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    Toutes ({products.length})
                  </button>
                  <button
                    onClick={() => setSelectedCategory('promo')}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex items-center gap-2 ${
                      selectedCategory === 'promo'
                        ? 'bg-secondary text-white font-medium'
                        : darkMode ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <span>🔥</span>
                    Promotions
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex items-center gap-2 ${
                        selectedCategory === cat.id
                          ? 'bg-secondary text-white font-medium'
                          : darkMode ? 'text-gray-400 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className={`font-semibold mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Prix (FCFA)
                </h4>
                <div className="space-y-3">
                  <input
                    type="range"
                    min={0}
                    max={200000}
                    step={5000}
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full accent-secondary"
                  />
                  <div className="flex justify-between text-sm">
                    <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>{formatPrice(priceRange[0])}</span>
                    <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{formatPrice(priceRange[1])}</span>
                  </div>
                </div>
              </div>

              {/* Quick Filters */}
              <div>
                <h4 className={`font-semibold mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Filtres rapides</h4>
                <div className="space-y-2">
                  {['Promo', 'Best-seller', 'Nouveau'].map(badge => (
                    <label key={badge} className={`flex items-center gap-2 text-sm cursor-pointer ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      <input type="checkbox" className="accent-secondary rounded" />
                      {badge}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            {/* Toolbar */}
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl p-4 shadow-md mb-6 flex items-center justify-between flex-wrap gap-4`}>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowFilters(true)}
                  className={`lg:hidden flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium ${
                    darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  <SlidersHorizontal size={16} />
                  Filtres
                </button>
                {selectedCategory !== 'all' && (
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-secondary/10 text-secondary text-sm font-medium"
                  >
                    {selectedCategory === 'promo' ? 'Promotions' : categories.find(c => c.id === selectedCategory)?.name}
                    <X size={14} />
                  </button>
                )}
              </div>
              <div className="flex items-center gap-3">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className={`px-3 py-2 rounded-lg text-sm ${
                    darkMode ? 'bg-gray-700 text-gray-300 border-gray-600' : 'bg-gray-50 text-gray-700 border-gray-200'
                  } border focus:outline-none focus:border-secondary`}
                >
                  <option value="popular">Plus populaires</option>
                  <option value="price-asc">Prix croissant</option>
                  <option value="price-desc">Prix décroissant</option>
                  <option value="rating">Mieux notés</option>
                </select>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className={`text-center py-20 ${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl`}>
                <div className="text-6xl mb-4">🔍</div>
                <h3 className={`text-xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Aucun produit trouvé
                </h3>
                <p className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Essayez de modifier vos critères de recherche
                </p>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {showFilters && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowFilters(false)} />
          <div className={`absolute left-0 top-0 bottom-0 w-80 ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-xl animate-slideInLeft overflow-y-auto`}>
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className={`font-bold text-lg ${darkMode ? 'text-white' : 'text-gray-900'}`}>Filtres</h3>
                <button onClick={() => setShowFilters(false)} className={`p-2 rounded-lg ${darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}>
                  <X size={20} />
                </button>
              </div>

              {/* Categories */}
              <div className="mb-6">
                <h4 className={`font-semibold mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Catégories</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => { setSelectedCategory('all'); setShowFilters(false); }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                      selectedCategory === 'all' ? 'bg-secondary text-white font-medium' : darkMode ? 'text-gray-400' : 'text-gray-600'
                    }`}
                  >
                    Toutes les catégories
                  </button>
                  <button
                    onClick={() => { setSelectedCategory('promo'); setShowFilters(false); }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center gap-2 ${
                      selectedCategory === 'promo' ? 'bg-secondary text-white font-medium' : darkMode ? 'text-gray-400' : 'text-gray-600'
                    }`}
                  >
                    <span>🔥</span>
                    Promotions
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => { setSelectedCategory(cat.id); setShowFilters(false); }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center gap-2 ${
                        selectedCategory === cat.id ? 'bg-secondary text-white font-medium' : darkMode ? 'text-gray-400' : 'text-gray-600'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price */}
              <div>
                <h4 className={`font-semibold mb-3 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Prix (FCFA)</h4>
                <input
                  type="range"
                  min={0}
                  max={200000}
                  step={5000}
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full accent-secondary"
                />
                <div className="flex justify-between text-sm mt-2">
                  <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>0</span>
                  <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{formatPrice(priceRange[1])}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
